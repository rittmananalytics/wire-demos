# Decisions and Discoveries — 01-data-foundation

Append-only log of decisions reached and notable discoveries during this release.

## 2026-10-06 — Requirements synthesis (discovery-analyst)

Source: SOW and call transcripts 01-03. Recorded during requirements_specification.md generation.

Agreed in calls (owning stakeholder confirmed directly in the transcript):
- OQ-6 (refund treatment): MRR is net, refunds netted on a rolling 30-day window. Confirmed by Tom Vickers (call 03 10:08).
- OQ-7 (market scope, build-blocker): four markets in v1 (UK, IE, FR, DE) modelled on country code; finance gets a UK+IE rollup. Confirmed by Becky Hartmann (call 03 10:21).
- OQ-10 (Looker licences): edit for Becky, Steph, Jordan, Tom; ~12 view licences (rest of marketing/ops plus David); others use scheduled exports. Confirmed by Becky (call 03 10:23).
- OQ-11 (backfill depth): 2024-01-01 cutoff. Confirmed by Steph and Mark (call 02 14:16); Becky to ratify as co-owner.
- OQ-12 (Shipstation rate limit): workable with the 2024 cutoff (~60k shipments, chunked, ~2 hours). Confirmed by Priya (call 02 14:18).
- Refresh cadence: daily across all domains for v1; hourly churn refresh deferred to v2. Cathy accepts daily for v1 (relayed by Steph, call 02 14:12).
- DQ-3 dedupe rule: dedupe Shipstation shipments on tracking_number, keep earliest created_at, in the staging model (call 02 14:20).

Proposed, not yet agreed (confirming owner has not confirmed directly):
- OQ-3 (cancellation taxonomy, build-blocker): proposed three top-level reasons (price, delivery, consumption) with the 14 CS reasons as sub-tags. Relayed by Steph as acceptable to Cathy Marsh; Cathy has not confirmed directly. Remains a build-blocker until Cathy signs off (call 01 10:18, call 02 14:22).

Still open:
- OQ-1 (guest checkouts), OQ-2 (state-machine precedence), OQ-4 (GA4-to-Stripe join key), OQ-5 (B2B treatment), OQ-8 (Klaviyo event taxonomy), OQ-9 (pause vs cancel).

Notable discoveries:
- Stripe is the system of record for money; Shopify for orders and customers (call 02 14:02).
- DQ-1: ~800 pre-2023 customer records need manual re-linking; some email mismatches are deliberate (staff accounts) (call 02 14:05).
- Maintenance burden is the engineering lead's main concern after three prior abandoned BI tools; enablement runs from week one (call 01 10:10).
- Goal hierarchy was inferred from the SOW (all five objectives Primary); confirm at requirements review.

## 2026-10-06 — Pipeline design (data-designer)

Source: approved requirements and conceptual model, engagement source DDL (17 tables), seed generator row counts. Recorded during pipeline_architecture.md generation and validation.

Decisions raised (need input):
- PD-1 (production ingestion tool): SOW §3 names Cloud Functions for production, but all five sources land through Fivetran into the raw_ schema today (call 02 14:10). The two conflict. Presented three scenarios (retain Fivetran / Cloud Functions / hybrid) with the trade-off between licence cost (Priya's concern) and maintenance burden (NFR-4, three prior abandoned tools). Not decided here. Recorded pipeline_tool: custom to match the stated SOW direction, pending PD-1. Owners: Priya Sharma, Becky Hartmann.
- PD-2 (Klaviyo and GA4 source path): read from the existing raw_ schema per NFR-3. Downstream of PD-1: if Fivetran is retired, the raw_ population path for these two sources must be replaced. Needs Priya to confirm raw_ stays populated. 
- PD-3 (GA4 late-arrival window, DQ-4): recommended a 3-day rolling lookback reprocess on each daily GA4 build, dedupe on event id. Consultant default; needs data-team confirmation at review.

Settled in the design:
- Demo ingestion is dbt seeds (Fivetran-equivalent), independent of the PD-1 outcome.
- Transformation is Wire 3-layer dbt: 16 staging models (one per in-scope raw table), integration models for the cross-source work, 20 warehouse facts/dims and aggregate marts.
- DQ-3 dedupe applied in stg_shipstation__shipments; DQ-4 late-arrival in the two GA4 staging models.
- Shipstation backfill: ~60k shipments from the 2024 cutoff, paced under 40 req/min, restartable (OQ-12, confirmed by Priya).
- Daily refresh for all domains in v1; GA4 lands hourly at source but is built daily; hourly churn deferred to v2 (NFR-1).
- Storage: BigQuery, EU dataset location recommended (no stated compliance regime); confirm at review.

Data gaps flagged (do not block design, must resolve before the affected models build):
- Address: no dedicated address source table; only shopify_customers.country_code and shopify_orders.market exist.
- No key links a Stripe charge to an invoice, which affects MRR refund netting.
- GA4-to-Stripe join key unresolved; user_id NULL for ~12% pre-2024 (OQ-4, DQ-2).
- No single Campaign key across Klaviyo and GA4 (GA4 campaign is free text).
- Cancellation taxonomy proposed, not confirmed by Cathy (OQ-3, build-blocker).
- Subscription state precedence unresolved (OQ-2).

Discoveries:
- Fivetran connectors were not verified against live tooling: no Fivetran MCP tools are available in this session. Connectors that would need confirming before build: Shopify, Stripe, Shipstation (connector existence and config fields), and the raw_ population path for Klaviyo and GA4. The 17 source tables and their columns were confirmed against ddl.sql at the schema level.
