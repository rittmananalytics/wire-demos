# Conceptual Entity Model: Acme Data Platform, Foundation Build

**Client**: Acme Coffee Roasters Ltd
**Project ID**: 20260531 (release 01-data-foundation)
**Generated**: 2026-10-06
**Version**: 1.0
**Status**: Draft, awaiting business stakeholder review

This model is derived from the approved requirements (`model_source: derived`). It shows the business entities, their high-level attributes, and their relationships. It does not carry column names, data types, or dbt layering. Those come later in the data model.

The six domains follow the SOW scope: Customers, Orders, Subscriptions, Payments, Marketing, Fulfilment.

> Note: No source schema examples were found in `artifacts/`. The engagement source DDL (`.wire/engagement/sources/ddl.sql`) was read and used to confirm entity attributes and the relationship keys below. Entities are otherwise derived from requirements. Placing source schema examples in `artifacts/` before review may reveal further entities or relationship corrections.

## 1. Entity Inventory

Analytical marts and metrics named in the requirements (MRR, gross and net churn, cohort retention, LTV, CAC, the attribution mart, the on-time-delivery mart) are derived aggregates built over the entities below. They are not themselves conceptual entities. Conformed dimensions (date, market, channel) are modelling constructs, not business entities, so they are described in the relationship narrative rather than listed here.

The five source systems (Shopify, Stripe, Klaviyo, Shipstation, GA4) are landed into BigQuery by the five-source ingestion requirement (FR-1: Ingest five source systems into BigQuery). They are data sources, not entities.

### Customers domain

#### Customer
**Description**: A person (or account) who has bought from or subscribed to Acme, with Shopify and Stripe identities resolved to one record.
**Key attributes**: email, first and last name, country or market, marketing consent, signup date, resolved Shopify and Stripe identity.
**Source**: Shopify customers linked to Stripe customers, per the customer and address integration requirement (FR-2: Customer and address integration with identity resolution). Link is on email at signup plus the Shopify customer ID held in Stripe metadata from 2023 onward.
**Approximate volume**: ~22,000 active subscribers, plus a larger base of one-off buyers.

#### Address
**Description**: A postal location associated with a customer, used for delivery and for market assignment.
**Key attributes**: customer, country or market, address lines, postcode.
**Source**: FR-2. See OQ-7: the provided source schemas hold no dedicated address table, only customer country code and order market.
**Approximate volume**: one or more per customer (unconfirmed, see OQ-7).

### Orders domain

#### Order
**Description**: A purchase placed through Shopify, the system of record for orders.
**Grain**: one row per Shopify order.
**Key attributes**: customer, order number, financial status, fulfilment status, total price, currency, market, order date.
**Source**: Shopify orders, per the orders and product requirement (FR-3: Orders and product model). Guest orders carry an email but no customer (see OQ-1).
**Approximate volume**: daily order flow across four markets (UK, Ireland, France, Germany).

#### OrderLine
**Description**: A single product line within an order.
**Grain**: one row per order line.
**Key attributes**: order, product, quantity, line price, line discount.
**Source**: Shopify order lines (FR-3).
**Approximate volume**: several per order.

#### Product
**Description**: A sellable item: coffee, gift box, accessory, or subscription plan.
**Key attributes**: title, product type, vendor, created date.
**Source**: Shopify products (FR-3).
**Approximate volume**: tens to low hundreds of products across three product lines.

### Subscriptions domain

#### Subscription
**Description**: A customer's recurring coffee subscription, reconciled from the Shopify subscription app and Stripe.
**Key attributes**: customer, product, status (active, paused, cancelled, failed), delivery frequency, start date, pause date, cancellation date.
**Source**: Shopify subscriptions reconciled with Stripe subscriptions, per the subscription event and reconciliation requirement (FR-4: Subscription event model and state reconciliation). The two systems disagree on about 3% of subscriptions, concentrated on pauses and free-trial conversions. The precedence rule is not yet agreed (see OQ-2).
**Approximate volume**: ~22,000 active subscriptions.

#### SubscriptionEvent
**Description**: A change of state in a subscription over time: started, paused, resumed, cancelled, or renewed.
**Grain**: one row per subscription state change.
**Key attributes**: subscription, event type, event timestamp, source system.
**Source**: derived from Shopify and Stripe subscription state fields and their change timestamps (FR-4). Feeds the subscription retention marts, per the retention metrics requirement (FR-5: Subscription retention metrics marts).
**Approximate volume**: several per subscription.

#### CancellationReason
**Description**: The canonical reason a subscription was cancelled, as a two-level taxonomy: three top-level reasons (price, delivery, consumption) with the 14 Customer Success reasons as sub-tags.
**Key attributes**: top-level reason, sub-reason, parent reason, source-list mappings (Shopify 8, Stripe 4, CS 14).
**Source**: the canonical cancellation taxonomy requirement (FR-9: Canonical cancellation reason taxonomy). The taxonomy is proposed, not yet confirmed by its owner (see OQ-5). This is a build-blocker for the churn mart.
**Approximate volume**: 3 top-level reasons and 14 sub-tags (17 reference rows).

### Payments domain

#### Payment
**Description**: A Stripe charge against a customer, including its refund state. Stripe is the system of record for money.
**Grain**: one row per Stripe charge.
**Key attributes**: customer, amount, currency, status (succeeded, failed, refunded), refunded flag, amount refunded, charge date.
**Source**: Stripe charges, per the payments and refund reconciliation requirement (FR-6: Payments and refund reconciliation). Refunds are modelled as attributes of the charge, not a separate entity. MRR nets refunds on a rolling 30-day window.
**Approximate volume**: tied to the subscriber base and order flow.

#### Invoice
**Description**: A Stripe invoice: the recurring billing record that links a subscription to the revenue it generates.
**Grain**: one row per Stripe invoice (per subscription, per billing period).
**Key attributes**: customer, subscription, amount paid, status, invoice date.
**Source**: Stripe invoices (FR-6). Invoices carry the subscription link that connects recurring revenue to a subscription, which feeds MRR (FR-5). See OQ-8 on reconciling charges to invoices.
**Approximate volume**: recurring per active subscription per billing cycle.

### Marketing domain

#### MarketingEvent
**Description**: A marketing interaction: a Klaviyo email or SMS event (sent, opened, clicked), or a GA4 web event (page view, add to cart, purchase).
**Grain**: one row per marketing event.
**Key attributes**: customer, event name, campaign, web session (for web events), event timestamp.
**Source**: Klaviyo events and GA4 events unioned, per the marketing event and attribution requirement (FR-7: Marketing event model and attribution mart). The Klaviyo join is clean (Shopify ID as external ID). The GA4-to-Stripe join is not yet agreed (see OQ-4).
**Approximate volume**: high; Klaviyo alone carries 40+ event types.

#### Campaign
**Description**: A marketing send mechanism: a Klaviyo campaign or an automated flow.
**Key attributes**: name, channel (email or SMS), send time, trigger event (for flows).
**Source**: Klaviyo campaigns and flows (FR-7). Supports the campaign slicing dimension required by the semantic layer requirement (FR-12: Looker semantic layer for self-service).
**Approximate volume**: ongoing campaign and flow set.

#### WebSession
**Description**: A GA4 web session, carrying the source, medium, campaign, and device that drive channel attribution.
**Grain**: one row per GA4 session.
**Key attributes**: customer (via user ID), session start, source, medium, campaign, device.
**Source**: GA4 sessions (FR-7). GA4 `user_id` exists only from 2024, so pre-2024 sessions have no customer link (see OQ-4).
**Approximate volume**: high; daily web traffic.

### Fulfilment domain

#### Shipment
**Description**: A Shipstation shipment fulfilling an order, used for on-time-delivery reporting.
**Grain**: one row per shipment, after deduplication on tracking number.
**Key attributes**: order, tracking number, carrier, service level, shipped date, delivered date.
**Source**: Shipstation shipments, per the fulfilment and on-time-delivery requirement (FR-8: Fulfilment model and on-time-delivery mart). Duplicate records (~0.5%) are deduplicated on tracking number, keeping the earliest created timestamp.
**Approximate volume**: ~280,000 all-time; ~60,000 from the 2024-01-01 cutoff.

#### TrackingEvent
**Description**: A carrier scan for a shipment: picked up, in transit, out for delivery, delivered.
**Grain**: one row per tracking scan.
**Key attributes**: shipment, event type, event timestamp.
**Source**: Shipstation tracking events (FR-8).
**Approximate volume**: several per shipment.

## 2. Entity Relationship Diagram

```mermaid
erDiagram
    CUSTOMER ||--o{ ADDRESS : "has"
    CUSTOMER ||--o{ ORDER : "places"
    CUSTOMER ||--o{ SUBSCRIPTION : "holds"
    CUSTOMER ||--o{ PAYMENT : "makes"
    CUSTOMER ||--o{ INVOICE : "is billed on"
    CUSTOMER ||--o{ WEB_SESSION : "generates"
    CUSTOMER ||--o{ MARKETING_EVENT : "is target of"
    ORDER ||--|{ ORDER_LINE : "contains"
    ORDER ||--o{ SHIPMENT : "is fulfilled by"
    PRODUCT ||--o{ ORDER_LINE : "appears on"
    PRODUCT ||--o{ SUBSCRIPTION : "supplies"
    SUBSCRIPTION ||--o{ SUBSCRIPTION_EVENT : "undergoes"
    SUBSCRIPTION ||--o{ INVOICE : "is billed through"
    CANCELLATION_REASON ||--o{ SUBSCRIPTION : "classifies"
    CANCELLATION_REASON ||--o{ CANCELLATION_REASON : "parent of"
    SHIPMENT ||--o{ TRACKING_EVENT : "is tracked by"
    CAMPAIGN ||--o{ MARKETING_EVENT : "drives"
    WEB_SESSION ||--o{ MARKETING_EVENT : "contains"
```

**How to read this diagram**:
- `||` = exactly one
- `o{` = zero or more
- `|{` = one or more
- Labels describe the relationship from the left entity's perspective.

## 3. Relationship Narrative

### Customers

**Customer → Address** ("has"): A customer has zero or more postal addresses used for delivery and market assignment. No dedicated address source exists in the provided schemas (see OQ-7).

**Customer → Order** ("places"): A customer places zero or more orders. Guest orders carry an email but no customer record, so some orders have no customer; how guest revenue is counted is open (see OQ-1).

**Customer → Subscription** ("holds"): A customer holds zero or more subscriptions. Reconciling Shopify and Stripe to one customer is what makes the active-subscription count trustworthy, the headline board concern.

**Customer → Payment** ("makes"): A customer makes zero or more Stripe charges. This is the money record Finance reconciles.

**Customer → Invoice** ("is billed on"): A customer is billed on zero or more Stripe invoices. Invoices carry the recurring amount that feeds MRR.

**Customer → WebSession** ("generates"): A customer generates zero or more GA4 web sessions, linked by GA4 user ID. The link exists only from 2024 (~12% historical gap, DQ-2: Klaviyo events missing user_id pre-2024 (~12%) and the matching GA4 gap), which bounds attribution (see OQ-4).

**Customer → MarketingEvent** ("is target of"): A customer is the target of zero or more marketing events. The Klaviyo link is clean because every Shopify customer is pushed to Klaviyo with the Shopify ID as the external ID.

### Orders

**Order → OrderLine** ("contains"): An order contains one or more product lines. Order line is the grain of the orders fact.

**Order → Shipment** ("is fulfilled by"): An order is fulfilled by zero or more shipments. Duplicate shipment records are deduplicated before this link is used (DQ-3: Shipstation duplicate shipment records (~0.5%)).

**Product → OrderLine** ("appears on"): A product appears on zero or more order lines. This connects product to order revenue and to the top-products view on the executive dashboard.

**Product → Subscription** ("supplies"): A product supplies zero or more subscriptions. Each subscription is for one product plan.

### Subscriptions

**Subscription → SubscriptionEvent** ("undergoes"): A subscription undergoes zero or more state changes over time. These events drive churn and cohort retention.

**Subscription → Invoice** ("is billed through"): A subscription is billed through zero or more invoices. This link carries recurring revenue to the subscription and is the basis for MRR.

**CancellationReason → Subscription** ("classifies"): A cancellation reason classifies zero or more cancelled subscriptions. Only cancelled subscriptions carry a reason. The canonical reason list is proposed, not confirmed (see OQ-5), and blocks the churn mart.

**CancellationReason → CancellationReason** ("parent of"): A top-level reason is the parent of zero or more sub-reasons. This models the two-level taxonomy (3 top-level, 14 sub-tags).

### Payments

The Payment and Invoice entities both hang off Customer, and Invoice also hangs off Subscription. The provided Stripe schema carries no key linking a charge to an invoice, so no direct Invoice-to-Payment relationship is drawn here (see OQ-8). This matters for netting refunds (on charges) against recurring revenue (on invoices) for MRR.

### Marketing

**Campaign → MarketingEvent** ("drives"): A campaign or flow drives zero or more marketing events, linked by Klaviyo campaign or flow ID. GA4 web events carry a free-text campaign that is not reconciled to this entity (see OQ-9).

**WebSession → MarketingEvent** ("contains"): A web session contains zero or more GA4 web events. Email and SMS events have no session, so that side is optional.

### Fulfilment

**Shipment → TrackingEvent** ("is tracked by"): A shipment is tracked by zero or more carrier scan events. The shipment's own shipped and delivered timestamps drive the on-time-delivery metric; tracking events give the intermediate milestones.

## 4. Entities Considered But Out of Scope

| Entity | Reason excluded |
|--------|----------------|
| Finance ERP records (Xero) | Out of scope per SOW §4; covered by the client's existing reporting. |
| Support tickets (Zendesk) | Deferred to a future engagement per SOW §4. |
| Web personalisation, A/B test, recommendation records | Out of scope per SOW §4. |
| Klaviyo audience lists and list membership | Not needed for the attribution mart; audience membership is not a reporting subject in this release. Klaviyo event taxonomy scope is itself open (per the requirements open question on keeping or consolidating the 40+ event types). |
| Stripe invoice line items | Not required; the invoice-level amount paid is sufficient for MRR in this release. |

## 5. Open Questions

These questions affect entity boundaries or relationships and should be resolved before the data model is finalised. They are reworded from the requirements open questions and from gaps found against the provided source schemas. Numbering is local to this document.

| # | Question | Impact |
|---|----------|--------|
| OQ-1 | Are guest checkouts (orders with no customer record) in scope for revenue reporting, and how is their revenue attributed? | Whether Order allows an optional customer, and how guest revenue is counted in the marts. |
| OQ-2 | When Shopify and Stripe disagree on subscription state (~3%, mostly pauses and trial conversions), which system takes precedence? | The state carried on Subscription, the events recorded on SubscriptionEvent, and the headline active-subscription count. |
| OQ-3 | Is a subscription pause treated as churn or not? | How SubscriptionEvent classifies pause versus cancel, and how the churn mart counts paused subscriptions. |
| OQ-4 | What is the canonical join key linking a WebSession to a Customer and on to Stripe revenue, given GA4 user ID exists only from 2024? | The Customer-to-WebSession link and the attribution path from MarketingEvent to revenue. |
| OQ-5 | Is the proposed cancellation taxonomy (3 top-level reasons, 14 sub-tags) confirmed by its owner? | The CancellationReason entity and its hierarchy, and the churn mart. This is a build-blocker. |
| OQ-6 | How are wholesale (B2B) orders treated in the subscription marts, and do they need a separate account entity? | Whether Customer, Order, and Subscription need a B2B segmentation or a separate account entity. |
| OQ-7 | Where does the Address entity source from? The provided schemas hold no address table, only customer country code and order market. | Whether Address can be built, and at what grain. |
| OQ-8 | How are Stripe charges reconciled to invoices? The provided Stripe schema has no key linking a charge to an invoice. | Whether an Invoice-to-Payment relationship can be built, and how refunds net against recurring revenue for MRR. |
| OQ-9 | How are Klaviyo campaign IDs and the free-text GA4 campaign reconciled into one Campaign? | Whether Campaign spans both email and web events or stays Klaviyo-only, affecting the attribution mart. |

## Reference key

Codes used in this document that are defined in other artifacts:

| Code | Meaning | Defined in |
|------|---------|------------|
| FR-1 | Ingest five source systems into BigQuery | requirements/requirements_specification.md |
| FR-2 | Customer and address integration with identity resolution | requirements/requirements_specification.md |
| FR-3 | Orders and product model | requirements/requirements_specification.md |
| FR-4 | Subscription event model and state reconciliation | requirements/requirements_specification.md |
| FR-5 | Subscription retention metrics marts | requirements/requirements_specification.md |
| FR-6 | Payments and refund reconciliation | requirements/requirements_specification.md |
| FR-7 | Marketing event model and attribution mart | requirements/requirements_specification.md |
| FR-8 | Fulfilment model and on-time-delivery mart | requirements/requirements_specification.md |
| FR-9 | Canonical cancellation reason taxonomy | requirements/requirements_specification.md |
| FR-12 | Looker semantic layer for self-service | requirements/requirements_specification.md |
| DQ-2 | Klaviyo events missing user_id pre-2024 (~12%) | requirements/requirements_specification.md |
| DQ-3 | Shipstation duplicate shipment records (~0.5%) | requirements/requirements_specification.md |
