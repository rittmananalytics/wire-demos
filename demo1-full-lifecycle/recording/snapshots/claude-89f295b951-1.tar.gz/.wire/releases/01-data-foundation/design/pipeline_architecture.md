# Pipeline Architecture: Acme Data Platform, Foundation Build

**Client**: Acme Coffee Roasters Ltd
**Project ID**: 20260531 (release 01-data-foundation)
**Generated**: 2026-10-06
**Version**: 1.0

This document maps the five source systems to the approved conceptual entities and specifies how data moves from source to the Looker BI layer. It is derived from the approved requirements specification and the approved conceptual model.

Open-question references in this document follow the requirements numbering (OQ-1 to OQ-12, defined in the Statement of Work). The conceptual model numbers its own open questions locally, and those numbers do not match the requirements numbers. Where a gap maps only to a conceptual-model open question, it is cited as `conceptual_model.md §5` rather than by an OQ number, to avoid a number collision.

## Reference key

Codes used in this document that are defined in other artifacts.

| Code | Meaning | Defined in |
|------|---------|------------|
| FR-1 | Ingest five source systems into BigQuery | requirements/requirements_specification.md |
| FR-2 | Customer and address integration with identity resolution | requirements/requirements_specification.md |
| FR-4 | Subscription event model and state reconciliation | requirements/requirements_specification.md |
| FR-7 | Marketing event model and attribution mart | requirements/requirements_specification.md |
| FR-8 | Fulfilment model and on-time-delivery mart | requirements/requirements_specification.md |
| FR-9 | Canonical cancellation reason taxonomy | requirements/requirements_specification.md |
| FR-12 | Looker semantic layer for self-service | requirements/requirements_specification.md |
| FR-14 | Historical backfill from 2024 | requirements/requirements_specification.md |
| NFR-1 | Refresh cadence and operational SLA | requirements/requirements_specification.md |
| NFR-2 | Data quality and test coverage | requirements/requirements_specification.md |
| NFR-3 | Access and security | requirements/requirements_specification.md |
| NFR-4 | Maintainability | requirements/requirements_specification.md |
| NFR-5 | Backfill performance and late-arrival handling | requirements/requirements_specification.md |
| DQ-1 | Stripe/Shopify customer email mismatch (~4%) | requirements/requirements_specification.md |
| DQ-2 | Klaviyo events missing user_id pre-2024 (~12%) | requirements/requirements_specification.md |
| DQ-3 | Shipstation duplicate shipment records (~0.5%) | requirements/requirements_specification.md |
| DQ-4 | GA4 out-of-order timestamps | requirements/requirements_specification.md |
| OQ-2 | Which subscription state machine takes precedence, Shopify or Stripe | requirements/requirements_specification.md (from SOW) |
| OQ-3 | Cancellation reason taxonomy: one canonical list (build-blocker) | requirements/requirements_specification.md (from SOW) |
| OQ-4 | GA4 to Stripe identity resolution join key | requirements/requirements_specification.md (from SOW) |
| OQ-8 | Klaviyo event taxonomy: keep all or consolidate | requirements/requirements_specification.md (from SOW) |
| OQ-11 | Historical backfill depth (2024-01-01 cutoff) | requirements/requirements_specification.md (from SOW) |
| OQ-12 | Shipstation API rate limit on backfill | requirements/requirements_specification.md (from SOW) |
| AC-2 | dbt builds green on the full pipeline | requirements/requirements_specification.md |
| AC-3 | Wire dbt-validate produces a PASS report | requirements/requirements_specification.md |
| D1 | Ingestion pipelines deliverable | requirements/requirements_specification.md |
| D2 | BigQuery warehouse (3-layer dbt) deliverable | requirements/requirements_specification.md |
| D3 | Looker semantic layer deliverable | requirements/requirements_specification.md |

## 1. Source Systems

Five source systems feed the warehouse (FR-1). The in-scope tables are read from the engagement source DDL (`.wire/engagement/sources/ddl.sql`), which holds 17 tables. The seed row counts come from the seed generator (`.wire/engagement/sources/generate.py`).

| System | Technology | In-scope tables | Replication method | Refresh cadence |
|--------|-----------|-----------------|--------------------|-----------------|
| Shopify | SaaS REST Admin API (orders and customers system of record) | shopify_customers, shopify_orders, shopify_order_lines, shopify_products, shopify_subscriptions | Incremental by `updated_at`, full refresh for small reference tables (products) | Daily |
| Stripe | SaaS REST API (money system of record) | stripe_customers, stripe_charges, stripe_subscriptions, stripe_invoices | Incremental by `created` / `updated` | Daily |
| Klaviyo | Read from the existing BigQuery `raw_` schema (NFR-3) | klaviyo_events, klaviyo_campaigns, klaviyo_flows | Read existing `raw_` tables (populated upstream); klaviyo_lists lands but is out of scope | Daily |
| Shipstation | SaaS REST API, rate-limited to 40 requests per minute | shipstation_shipments, shipstation_tracking_events | Incremental by `created_at` plus a bounded one-pass backfill (~60,000 shipments from the 2024 cutoff) | Daily |
| GA4 | Read from the existing BigQuery `raw_` schema (NFR-3); hourly at source | ga4_sessions, ga4_events | Read existing `raw_` tables, with a late-arrival reprocess window (DQ-4) | Daily build (source lands hourly) |

### 1.1 Current state

All five sources land in a BigQuery `raw_` schema today through Fivetran, with no transformation layer; each team queries the raw schema and writes its own SQL (call 02 14:10). This release adds the staging, integration, and warehouse layers above that raw schema and does not change how the raw data lands until the production ingestion decision (PD-1) is settled.

For the demo, ingestion is Fivetran-equivalent via dbt seeds loaded into `raw_` tables that match the source DDL. In production the Statement of Work names Cloud Functions as the ingestion mechanism (SOW §3). The current Fivetran setup and the Cloud Functions target are in tension; this is recorded as decision PD-1 in Section 5.

### 1.2 Volumes (demo seed)

| Source | Tables (rows, demo seed) |
|--------|--------------------------|
| Shopify | customers 3,000; orders 10,000; order_lines 25,000; products 40; subscriptions 4,500 |
| Stripe | customers 3,000; charges 12,000; subscriptions 4,500; invoices 18,000 |
| Klaviyo | events 30,000; campaigns 120; flows 8; lists 6 (out of scope) |
| Shipstation | shipments 10,000; tracking_events 35,000 |
| GA4 | sessions 50,000; events 200,000 |

Production volumes are larger (about 22,000 active subscribers and about 60,000 Shipstation shipments from the 2024 cutoff), but the ordering of magnitude per source is the same.

### 1.3 Source-to-entity coverage and data gaps

Every in-scope conceptual entity maps to at least one source table, with the exceptions listed below. These gaps do not block the design but must be resolved before the affected models are built. They are flagged here rather than skipped.

| Gap | Entities or marts affected | Evidence in source DDL | Link |
|-----|----------------------------|------------------------|------|
| No dedicated address source table | Address | `ddl.sql` has no address table; only `shopify_customers.country_code` and `shopify_orders.market` | conceptual_model.md §5 (local open question on Address sourcing); market modelling per requirements assumption 4 |
| No key linking a Stripe charge to an invoice | Payment to Invoice link, MRR refund netting | `stripe_charges` and `stripe_invoices` share no join key | conceptual_model.md §5 (local open question on charge-to-invoice reconciliation) |
| GA4-to-Stripe join key unresolved; `user_id` NULL before 2024 | WebSession, MarketingEvent, attribution mart | `ga4_sessions.user_id` and `ga4_events.user_id` NULL for ~12% pre-2024 | OQ-4, DQ-2 |
| No single Campaign key across Klaviyo and GA4 | Campaign, attribution mart | `ga4_sessions.campaign` is free text, not keyed to `klaviyo_campaigns.id` | conceptual_model.md §5 (local open question on campaign reconciliation); OQ-8 |
| Canonical cancellation taxonomy proposed, not confirmed | CancellationReason, churn mart | `shopify_subscriptions` carries `cancellation_reason_top` and `cancellation_reason_sub`; Stripe carries none | OQ-3, FR-9 (build-blocker) |
| Subscription state precedence unresolved | Subscription, SubscriptionEvent, active-subscription count | Shopify and Stripe subscription status fields disagree on ~3% | OQ-2, FR-4 |

## 2. Replication Strategy

The replication tool for production is the open decision PD-1 (Section 5). The three viable scenarios are set out below. The demo does not depend on the outcome: it uses dbt seeds for all five sources regardless.

**Scenario A: Retain Fivetran for all SaaS sources.** Keep the existing Fivetran connectors for Shopify, Stripe, and Shipstation, and keep reading Klaviyo and GA4 from the `raw_` schema (which Fivetran also populates). Managed connectors, log-based or incremental sync, no ingestion code to maintain. Cost is Monthly Active Rows (MAR) based. Lowest maintenance burden, which is the dominant stated risk (NFR-4, three prior BI tools abandoned for lack of maintainability).

**Scenario B: Cloud Functions for every source.** Replace Fivetran with per-source Cloud Functions, the production mechanism named in SOW §3. Full control and no connector licence cost, which addresses the engineering lead's cost concern. Higher engineering build and maintenance burden, which runs against NFR-4.

**Scenario C: Hybrid.** Cloud Functions where MAR cost or control matters, managed connectors where maintenance risk dominates. More moving parts, two operating models to run.

Recommendation and trade-off: see PD-1. The stated client position (SOW §3) is Cloud Functions in production (Scenario B). That position conflicts with the working Fivetran setup and with NFR-4. The decision needs the engineering lead and sponsor to weigh licence cost against maintenance burden before build.

### 2.1 Backfill strategy

Backfill runs from the 2024-01-01 cutoff across all sources (FR-14, OQ-11). Shopify history reaches 2018 and GA4 reaches 2023, but only 2024 onward is in scope (call 02 14:16).

Shipstation is the only rate-constrained backfill. The API allows 40 requests per minute. Bounded by the 2024 cutoff, the backfill is about 60,000 shipments, pulled in chunks over roughly two hours (NFR-5, OQ-12, confirmed by Priya). The backfill job paces requests to stay under the limit and is restartable from the last committed page.

### 2.2 Per-source replication notes

| Source | Incremental key | Notes |
|--------|-----------------|-------|
| Shopify | `updated_at` | Products is small and slowly-changing; full refresh is acceptable there |
| Stripe | `created` (charges, invoices), `canceled_at` / period fields (subscriptions) | Stripe is the money system of record; refunds are attributes of the charge |
| Klaviyo | event `timestamp` | Read from `raw_`; no direct API pull in this release (NFR-3) |
| Shipstation | `created_at` | DQ-3 duplicate records resolved in staging, not at ingestion |
| GA4 | `event_timestamp` / `session_start` | Read from `raw_`; late-arriving events reprocessed on a lookback window (DQ-4, PD-3) |

## 3. Pipeline Architecture

Transformation follows the Wire 3-layer dbt convention: staging, integration, warehouse (SOW §3, NFR-4). The layers sit above the `raw_` schema that ingestion populates.

### 3.1 Landing / Raw Layer

Replicated data lands in per-source BigQuery datasets using the `raw_<source>` convention:

- `raw_shopify`, `raw_stripe`, `raw_klaviyo`, `raw_shipstation`, `raw_ga4`

Each raw table is a one-to-one copy of the source table in the DDL. For the demo, dbt seeds load CSV files into these raw tables. `klaviyo_lists` lands in `raw_klaviyo` but has no downstream model (audience lists are out of scope per the conceptual model).

### 3.2 Staging Layer

Staging models are BigQuery views, one per in-scope raw table, named `stg_<source>__<entity>`. They rename columns, cast types, and apply row-level cleaning. No business logic or joins across sources happen here.

| Raw table | Staging model | Conceptual entity | Staging notes |
|-----------|---------------|-------------------|---------------|
| raw_shopify.shopify_customers | stg_shopify__customers | Customer | Standardise email, country code |
| raw_shopify.shopify_orders | stg_shopify__orders | Order | Guest orders keep email, NULL customer |
| raw_shopify.shopify_order_lines | stg_shopify__order_lines | OrderLine | Line grain |
| raw_shopify.shopify_products | stg_shopify__products | Product | |
| raw_shopify.shopify_subscriptions | stg_shopify__subscriptions | Subscription, CancellationReason | Carries `cancellation_reason_top` / `_sub` |
| raw_stripe.stripe_customers | stg_stripe__customers | Customer | Carries `shopify_customer_id` metadata link |
| raw_stripe.stripe_charges | stg_stripe__charges | Payment | Refund fields on the charge |
| raw_stripe.stripe_subscriptions | stg_stripe__subscriptions | Subscription | Stripe state machine |
| raw_stripe.stripe_invoices | stg_stripe__invoices | Invoice | Carries `subscription_id` link |
| raw_klaviyo.klaviyo_events | stg_klaviyo__events | MarketingEvent | `user_id` maps to Shopify customer id |
| raw_klaviyo.klaviyo_campaigns | stg_klaviyo__campaigns | Campaign | |
| raw_klaviyo.klaviyo_flows | stg_klaviyo__flows | Campaign (flows) | |
| raw_shipstation.shipstation_shipments | stg_shipstation__shipments | Shipment | DQ-3 dedupe on `tracking_number`, keep earliest `created_at` |
| raw_shipstation.shipstation_tracking_events | stg_shipstation__tracking_events | TrackingEvent | |
| raw_ga4.ga4_sessions | stg_ga4__sessions | WebSession | DQ-4 late-arrival reprocess |
| raw_ga4.ga4_events | stg_ga4__events | MarketingEvent (web) | DQ-4 late-arrival reprocess |

Sixteen staging models in total. DQ-3 deduplication is applied in `stg_shipstation__shipments` (call 02 14:20). DQ-4 late-arrival handling is applied in the two GA4 staging models (Section 3.4, PD-3).

### 3.3 Integration Layer

Integration models are BigQuery tables that do the cross-source work: identity resolution, state reconciliation, and union. They are named `int_<group>__<subject>`.

| Integration model | Purpose | Key inputs | Open item |
|-------------------|---------|-----------|-----------|
| int_customers__identity_resolved | Resolve Shopify and Stripe customers to one record | stg_shopify__customers, stg_stripe__customers | DQ-1 (~800 pre-2023 records re-linked by rule) |
| int_orders__order_enriched | Join order lines to orders and products | stg_shopify__orders, stg_shopify__order_lines, stg_shopify__products | OQ guest-order treatment |
| int_subscriptions__state_reconciled | Reconcile the two subscription state machines | stg_shopify__subscriptions, stg_stripe__subscriptions | OQ-2 precedence rule |
| int_payments__charge_invoice | Associate charges and invoices for MRR refund netting | stg_stripe__charges, stg_stripe__invoices | No charge-to-invoice key (conceptual_model.md §5) |
| int_marketing__event_stream | Union Klaviyo and GA4 events, attach customer and campaign | stg_klaviyo__events, stg_ga4__events, stg_ga4__sessions | OQ-4 GA4-to-Stripe key |
| int_fulfilment__shipment_delivery | Join shipments to tracking for delivery timing | stg_shipstation__shipments, stg_shipstation__tracking_events | |

### 3.4 Warehouse Layer

Warehouse models are BigQuery tables: dimensions, facts, and aggregate marts. Dimensions and facts follow `wh_<group>__<entity>_dim` and `wh_<group>__<entity>_fact`. Aggregate marts are modelled as aggregate facts and carry the `_fact` suffix. Detailed column design is in the data model specification (generated separately).

Entity-backed models:

| Conceptual entity | Warehouse model | Type |
|-------------------|-----------------|------|
| Customer | wh_customers__customer_dim | Dimension |
| Address | wh_customers__address_dim | Dimension (see Address gap, Section 1.3) |
| Order, OrderLine | wh_orders__order_line_fact | Fact (line grain, order carried as header context) |
| Product | wh_orders__product_dim | Dimension |
| Subscription | wh_subscriptions__subscription_dim | Dimension |
| SubscriptionEvent | wh_subscriptions__subscription_event_fact | Fact |
| CancellationReason | wh_subscriptions__cancellation_reason_dim | Dimension (pending OQ-3) |
| Payment | wh_payments__payment_fact | Fact |
| Invoice | wh_payments__invoice_fact | Fact |
| MarketingEvent | wh_marketing__marketing_event_fact | Fact |
| Campaign | wh_marketing__campaign_dim | Dimension |
| WebSession | wh_marketing__web_session_fact | Fact |
| Shipment | wh_fulfilment__shipment_fact | Fact |
| TrackingEvent | wh_fulfilment__tracking_event_fact | Fact |

Aggregate marts (built over the models above; these are derived aggregates, not conceptual entities):

| Mart | Warehouse model | Feeds |
|------|-----------------|-------|
| MRR (net, rolling 30-day refund window) | wh_subscriptions__mrr_fact | Executive, Subscriptions dashboards |
| Gross and net churn | wh_subscriptions__churn_fact | Subscriptions dashboard |
| Cohort retention | wh_subscriptions__cohort_retention_fact | Subscriptions dashboard |
| LTV (full by cohort; first-month to Marketing) | wh_subscriptions__ltv_fact | Subscriptions, Marketing dashboards |
| Marketing attribution | wh_marketing__attribution_fact | Marketing dashboard |
| On-time delivery | wh_fulfilment__on_time_delivery_fact | Fulfilment dashboard |

### 3.5 Error Handling

**Detection.** Managed connector sync failures surface in the connector dashboard and raise an alert. Cloud Functions ingestion logs to Cloud Logging and raises errors to Error Reporting. dbt Cloud job failures raise a job alert.

**Retry.** Managed connectors retry on their own schedule. Cloud Functions retry with exponential backoff and route unrecoverable records to a dead-letter path. The Shipstation backfill backs off when it approaches the 40 requests-per-minute limit and resumes from the last committed page.

**Late arrival (DQ-4).** GA4 events can arrive out of order by several hours. Each daily GA4 build reprocesses a rolling lookback window (PD-3) so late events are picked up without being dropped or double-counted.

**Alerting.** Pipeline and dbt job failures alert the engineering lead (Priya) by the team's chosen channel (Slack or email). A failed daily build is visible before the dashboards are read the next morning.

### 3.6 Scheduling

**Cadence.** All domains refresh daily in v1 (NFR-1). GA4 lands hourly at source but is built once daily in v1. Cathy's request for hourly churn refresh is deferred to v2 (call 02 14:12).

**Order of runs.** Ingestion lands `raw_` first. The dbt Cloud daily job then runs in dependency order: staging, integration, warehouse, marts. Looker rebuilds any persistent derived tables after the warehouse job succeeds.

**Dependencies.** The dbt job starts only after the day's ingestion has landed for all five sources. A source that fails to land holds its downstream models rather than building on stale data, and raises the alert in Section 3.5.

## 4. Data Flow Diagram

```mermaid
graph LR
    subgraph src["Source Systems"]
        SRC_SHOP["Shopify<br/>SaaS API, orders/customers SoR"]
        SRC_STR["Stripe<br/>SaaS API, money SoR"]
        SRC_KLA["Klaviyo<br/>Email/SMS events"]
        SRC_SHIP["Shipstation<br/>Fulfilment, 40 req/min"]
        SRC_GA4["GA4<br/>Web analytics, hourly"]
    end

    subgraph ingest["Data Ingestion<br/>(demo: dbt seeds; prod: Cloud Functions / Fivetran, PD-1)"]
        ING_SHOP["ingest shopify<br/>5 tables to raw_shopify"]
        ING_STR["ingest stripe<br/>4 tables to raw_stripe"]
        ING_KLA["raw_klaviyo read<br/>events, campaigns, flows"]
        ING_SHIP["ingest shipstation<br/>shipments, tracking_events"]
        ING_GA4["raw_ga4 read<br/>sessions, events"]
    end

    subgraph staging["Staging Layer<br/>(BigQuery views, dbt)"]
        STG_SHOP["stg_shopify__customers<br/>stg_shopify__orders<br/>stg_shopify__order_lines<br/>stg_shopify__products<br/>stg_shopify__subscriptions"]
        STG_STR["stg_stripe__customers<br/>stg_stripe__charges<br/>stg_stripe__subscriptions<br/>stg_stripe__invoices"]
        STG_KLA["stg_klaviyo__events<br/>stg_klaviyo__campaigns<br/>stg_klaviyo__flows"]
        STG_SHIP["stg_shipstation__shipments (DQ-3 dedupe)<br/>stg_shipstation__tracking_events"]
        STG_GA4["stg_ga4__sessions (DQ-4)<br/>stg_ga4__events (DQ-4)"]
    end

    subgraph integration["Integration Layer<br/>(BigQuery tables, dbt)"]
        INT_CUST["int_customers__identity_resolved<br/>(DQ-1)"]
        INT_ORD["int_orders__order_enriched"]
        INT_SUB["int_subscriptions__state_reconciled<br/>(OQ-2)"]
        INT_PAY["int_payments__charge_invoice"]
        INT_MKT["int_marketing__event_stream<br/>(OQ-4)"]
        INT_FUL["int_fulfilment__shipment_delivery"]
    end

    subgraph warehouse["Warehouse Layer<br/>(BigQuery tables, dbt)"]
        WH_CUST["wh_customers__customer_dim<br/>wh_customers__address_dim"]
        WH_ORD["wh_orders__order_line_fact<br/>wh_orders__product_dim"]
        WH_SUB["wh_subscriptions__subscription_dim<br/>wh_subscriptions__subscription_event_fact<br/>wh_subscriptions__cancellation_reason_dim"]
        WH_PAY["wh_payments__payment_fact<br/>wh_payments__invoice_fact"]
        WH_MKT["wh_marketing__marketing_event_fact<br/>wh_marketing__campaign_dim<br/>wh_marketing__web_session_fact"]
        WH_FUL["wh_fulfilment__shipment_fact<br/>wh_fulfilment__tracking_event_fact"]
        AGG["Aggregate marts<br/>wh_subscriptions__mrr_fact<br/>wh_subscriptions__churn_fact<br/>wh_subscriptions__cohort_retention_fact<br/>wh_subscriptions__ltv_fact<br/>wh_marketing__attribution_fact<br/>wh_fulfilment__on_time_delivery_fact"]
    end

    subgraph bi["BI Layer<br/>(Looker)"]
        EX["Explores<br/>subscription_retention, marketing_attribution,<br/>orders, payments, customers, fulfilment"]
        DB_EXEC["Executive Dashboard"]
        DB_SUB["Subscriptions Dashboard"]
        DB_MKT["Marketing Dashboard"]
        DB_FUL["Fulfilment Dashboard"]
    end

    SRC_SHOP --> ING_SHOP
    SRC_STR --> ING_STR
    SRC_KLA --> ING_KLA
    SRC_SHIP --> ING_SHIP
    SRC_GA4 --> ING_GA4

    ING_SHOP --> STG_SHOP
    ING_STR --> STG_STR
    ING_KLA --> STG_KLA
    ING_SHIP --> STG_SHIP
    ING_GA4 --> STG_GA4

    STG_SHOP --> INT_CUST
    STG_STR --> INT_CUST
    STG_SHOP --> INT_ORD
    STG_SHOP --> INT_SUB
    STG_STR --> INT_SUB
    STG_STR --> INT_PAY
    STG_KLA --> INT_MKT
    STG_GA4 --> INT_MKT
    STG_SHIP --> INT_FUL

    INT_CUST --> WH_CUST
    INT_ORD --> WH_ORD
    INT_SUB --> WH_SUB
    INT_PAY --> WH_PAY
    INT_MKT --> WH_MKT
    INT_FUL --> WH_FUL

    WH_CUST --> AGG
    WH_ORD --> AGG
    WH_SUB --> AGG
    WH_PAY --> AGG
    WH_MKT --> AGG
    WH_FUL --> AGG

    WH_CUST --> EX
    WH_ORD --> EX
    WH_SUB --> EX
    WH_PAY --> EX
    WH_MKT --> EX
    WH_FUL --> EX
    AGG --> EX

    EX --> DB_EXEC
    EX --> DB_SUB
    EX --> DB_MKT
    EX --> DB_FUL
```

## 5. Design Decisions

**PD-1: Production ingestion tool**

Context: The demo uses dbt seeds as a Fivetran-equivalent, which is settled. Production is the open question. The Statement of Work names Cloud Functions as the production ingestion mechanism (SOW §3), but the sources land through Fivetran into the `raw_` schema today (call 02 14:10). The two positions conflict, and the choice affects connector coverage, licence cost, infrastructure, and the maintenance burden the engineering lead is most concerned about (NFR-4).

Options:
- Option A (retain Fivetran): managed connectors for Shopify, Stripe, Shipstation; keep reading Klaviyo and GA4 from `raw_`. Lowest maintenance burden. Cost is MAR-based. Keeps the working setup.
- Option B (Cloud Functions, the SOW position): per-source Cloud Functions, no connector licence, full control, higher build and maintenance burden.
- Option C (hybrid): Cloud Functions where cost or control matters, managed connectors elsewhere. Two operating models to run.

Recommendation: confirm the SOW's Cloud Functions position (Option B) only if the engineering team commits to owning custom ingestion long-term; this aligns with the stated cost concern. If the maintenance burden is judged to outweigh Fivetran's licence cost at Acme's volumes, Option A is the lower-risk path given NFR-4 and the three prior abandoned tools. The decision is not made here; it is presented for the client. The recorded `pipeline_tool` is `custom` (Cloud Functions), matching the stated SOW direction, pending this decision.

Input required from: Priya Sharma (Engineering Lead) and Becky Hartmann (Head of Data, sponsor).

**PD-2: Klaviyo and GA4 source path**

Context: NFR-3 says Klaviyo and GA4 are read from the existing BigQuery `raw_` schema rather than pulled by a new connector. That schema is populated upstream, currently by Fivetran. If PD-1 retires Fivetran, the `raw_` population path for these two sources must be replaced too.

Options:
- Option A: keep reading Klaviyo and GA4 from `raw_`, and keep whatever populates `raw_` for them under PD-1.
- Option B: add dedicated Cloud Functions for Klaviyo and GA4 if Fivetran is retired.

Recommendation: Option A, read from `raw_` per NFR-3 for this release. Confirm that the `raw_` schema stays populated for Klaviyo and GA4 under whichever PD-1 outcome is chosen. This decision is downstream of PD-1.

Input required from: Priya Sharma (Engineering Lead).

**PD-3: GA4 late-arrival reprocessing window (DQ-4)**

Context: GA4 events arrive out of order by several hours (DQ-4, NFR-5). The daily GA4 build must reprocess recent data so late events are captured without double-counting. The window length trades reprocessing cost against completeness.

Options:
- Option A: 3-day rolling lookback (recommended default).
- Option B: longer window (for example 7 days) for higher completeness at more build cost.

Recommendation: a 3-day rolling lookback on each daily GA4 build, deduplicating on event id. This covers the stated several-hours lateness with margin at low cost. This is a consultant default rather than a client decision; it needs the data team's confirmation at review.

Input required from: Acme data team (Steph / Priya).

## 6. Technology Stack

| Layer | Technology | Version / tier |
|-------|-----------|----------------|
| Replication (demo) | dbt seeds (Fivetran-equivalent) | dbt seeds into `raw_` |
| Replication (production) | Cloud Functions (recommended, pending PD-1); Fivetran is the current state | Per-source, pending PD-1 |
| Transformation | dbt (Wire 3-layer: staging / integration / warehouse) | dbt Cloud |
| Warehouse | BigQuery | EU dataset location (see Section 7) |
| BI | Looker | 1 model file, ~20 views, 6 explores (FR-12) |
| Orchestration | dbt Cloud scheduled jobs, daily | Triggered after ingestion lands |

## 7. Security and Data Governance

**Access.** Source access is read-only. Shopify, Stripe, and Shipstation use read-only service accounts; Klaviyo and GA4 are read from the BigQuery `raw_` schema (NFR-3). Looker licences follow OQ-10: edit for Becky, Steph, Jordan, and Tom; about 12 view licences for the rest of marketing and ops plus David; everyone else uses scheduled exports.

**PII.** Customer email and name are PII and flow through the Customer models. No field-level masking is required by the requirements. Email is used as a join key for identity resolution (FR-2, DQ-1); it is carried in staging and integration and is not exposed in dashboards beyond what the explores need. Some email mismatches are deliberate (staff accounts) and are not errors (DQ-1).

**Row-level access.** Markets are modelled on country code; finance gets a UK and Ireland rollup (requirements assumption 4). Access is granted by role in v1. Row-level security beyond market and role is not in scope for v1.

**Data residency.** Acme's customers are in the UK, Ireland, France, and Germany. No specific compliance regime is stated in the requirements (data governance, requirements §6.3). The recommended default is an EU BigQuery dataset location (for example `europe-west2`, London) to keep customer data in region; confirm at review. US-region datasets are ruled out absent a stated need.

**Administration.** Infrastructure and service accounts are administered by Priya (Engineering Lead); Looker licence allocation by Becky (Head of Data).

## Section A: Target Platform Architecture

This section records what the platform is proposed to be, one subsection per layer. Each carries a `Constrained by` line naming the requirement that constrains it and a `Ruled out` line naming what the choice forecloses. There is no current-state appraisal in this release, so constraints cite requirements rather than appraisal findings (CS-n).

### A.1 Ingestion

Proposed: demo ingestion via dbt seeds (settled); production ingestion via Cloud Functions as named in the SOW, pending PD-1. Klaviyo and GA4 are read from the existing `raw_` schema rather than re-ingested (PD-2).
Reason: SOW §3 names Cloud Functions for production; NFR-3 fixes the `raw_` read path for Klaviyo and GA4; NFR-5 and FR-14 set the backfill and rate-limit constraints.
Constrained by: SOW §3, FR-1, FR-14, NFR-3, NFR-5.
Ruled out: a second managed ingestion tool beyond the existing Fivetran; real-time streaming ingestion in v1.

### A.2 Storage

Proposed: BigQuery as the single analytical warehouse, EU dataset location.
Reason: BigQuery is committed in the SOW; an EU location keeps UK and EU customer data in region as a sensible default.
Constrained by: SOW §3 (BigQuery committed); requirements §6.3 (no stated compliance regime).
Ruled out: a lakehouse or any non-BigQuery warehouse; US-region datasets absent a stated need.

### A.3 Transformation

Proposed: dbt following the Wire 3-layer convention (staging, integration, warehouse).
Reason: committed in the SOW and required for maintainability; Acme engineers must read and maintain the models without RA in the loop (NFR-4).
Constrained by: SOW §3, NFR-4.
Ruled out: ad-hoc SQL written directly against the `raw_` schema (the current state); any non-dbt transformation tool.

### A.4 Orchestration

Proposed: dbt Cloud scheduled jobs running daily, triggered after the day's ingestion lands, building staging, integration, warehouse, then marts in dependency order.
Reason: daily refresh across all domains in v1; GA4 lands hourly at source but is built daily in v1 (NFR-1).
Constrained by: NFR-1, NFR-5.
Ruled out: per-source bespoke schedulers; sub-daily marts in v1 (hourly churn refresh deferred to v2).

### A.5 Semantic layer

Proposed: metrics defined once in Looker (LookML), 1 model file, about 20 views, 6 explores, with the five slicing dimensions on the marketing fact (FR-12). Owned by Becky's data team after handover.
Reason: the SOW commits to Looker for self-service; marketing must answer the five named questions without engineering help.
Constrained by: SOW §3, FR-12, OQ-10.
Ruled out: defining metrics twice (dbt Semantic Layer or Cube in parallel); BI-tool-only metrics with no governed model.

### A.6 Agentic analytics

Proposed: not in scope for this release. What would have to be true first: a governed, trusted semantic layer live in Looker, and metrics certified by the data team.
Reason: the SOW does not name conversational or agent access; trust in the numbers is the precondition, and that is what this release builds first.
Constrained by: SOW §2 and §3 (not named in scope).
Ruled out: conversational or agent access to the warehouse in v1.

### A.7 Access and governance

Proposed: access granted by role. Source access read-only (service accounts for Shopify, Stripe, Shipstation; `raw_` reads for Klaviyo, GA4). Looker licences per OQ-10. Markets modelled on country code with a finance UK and Ireland rollup.
Reason: NFR-3 and OQ-10 fix the access model; requirements assumption 4 fixes market handling.
Constrained by: NFR-3, OQ-10, requirements assumption 4.
Ruled out: write access to the `raw_` schema for analysts; row-level security beyond market and role in v1.
