# Data Model Specification: Acme Data Platform, Foundation Build

**Client**: Acme Coffee Roasters Ltd
**Project ID**: 20260531 (release 01-data-foundation)
**Generated**: 2026-10-06
**Version**: 1.0

This specification defines every dbt model for the foundation build: source
definitions, 16 staging models, 7 integration models, 20 warehouse models, 4
configuration seeds, the cross-system join keys, the physical ERD, and the test
coverage plan. It is derived from the approved requirements, conceptual model,
and pipeline architecture (`model_source: derived`). It is the primary input for
`/wire:dbt-generate`: every model name, column name, surrogate key, join path,
and test is fixed here.

## How to read the codes

This document cites codes minted in other artifacts. OQ numbering needs care.
The requirements and SOW number open questions OQ-1 to OQ-12. The conceptual
model numbers its own open questions locally, and those numbers do not match.
This document uses the SOW/requirements OQ numbers. Three gaps exist only as
conceptual-model local open questions (Address sourcing, charge-to-invoice
reconciliation, Klaviyo/GA4 campaign reconciliation); those are cited as
`conceptual_model.md §5` to avoid a number collision. See the Reference key at
the end.

## Canonical data model registry

This model was built against the Wire data model registry
(`~/.wire/data-model-registry/`).

- **Vertical (confident match)**: `subscription-commerce`, schema
  `subscription_lifecycle`. Acme is a DTC subscription-box business; the
  schema's entities (subscriber, subscription, subscription_event,
  monthly_retention, subscription_revenue) map onto Acme's MRR, churn, cohort
  retention, and subscription models. Taken as `adapt`: kept, dropped, renamed,
  and re-grained per Section 10.
- **Cross-vertical patterns (adjacent, used loosely)**: `crm_identity_resolution`
  (informs customer identity resolution and its manual merge-list seed),
  `ga4_ecommerce` (informs the web-session fact), `multi_touch_attribution`
  (informs the attribution fact).
- **Considered, not adopted**: `subscription-commerce/fulfillment_and_delivery`
  (curated-box line/component grain Acme does not have),
  `event_tracking_and_sessionization` (Acme's GA4 arrives pre-sessionized),
  `finance_revenue_recognition` (PSA/ASC-606 shape, out of scope),
  `product_analytics` (software-product usage, not applicable).

Section 10 records the grain decisions where the registry and the approved
conceptual model or pipeline design differ. Per-model canonical pointers appear
on each mapped model. Treat every `reference` pointer as a worked example to
read and adapt, not SQL to copy; the registry README is explicit that a specific
`.sql` file is not reusable across clients, only the pattern it demonstrates.

---

## 1. Source Definitions

Five source systems feed the warehouse (FR-1: ingest five source systems into
BigQuery). The 17 source tables and their columns are read from the engagement
source DDL (`.wire/engagement/sources/ddl.sql`). `klaviyo_lists` lands but has
no downstream model (audience lists are out of scope).

**Environment note.** Production target is BigQuery, EU dataset location. For the
demo the raw tables are produced by dbt seeds (DuckDB), so `database` and
`schema` resolve per the dbt target/profile. Freshness thresholds are calibrated
to the daily replication cadence (NFR-1: refresh cadence and operational SLA) and
apply once live ingestion lands (PD-1: production ingestion tool). The demo seed
load has no live feed, so freshness is not actively enforced there.

```yaml
version: 2

sources:
  - name: shopify
    database: acme_analytics      # resolves per dbt target; BigQuery project in production
    schema: raw_shopify
    freshness:
      warn_after: {count: 25, period: hour}
      error_after: {count: 49, period: hour}
    tables:
      - name: shopify_customers
        description: "Shopify customers. System of record for customers."
        loaded_at_field: updated_at
        columns:
          - name: id
            description: "Shopify customer id (BIGINT). Primary key."
            tests: [not_null, unique]
          - name: email
            description: "Customer email. PII. Identity-resolution key (FR-2)."
          - name: country_code
            description: "ISO-2 country code. Drives market assignment."
      - name: shopify_orders
        description: "Shopify orders. System of record for orders. Guest orders carry email with NULL customer_id."
        loaded_at_field: updated_at
        columns:
          - name: id
            tests: [not_null, unique]
          - name: customer_id
            description: "Shopify customer id. NULL for guest orders (OQ-1)."
          - name: market
            description: "uk | ie | fr | de."
      - name: shopify_order_lines
        description: "Order lines. One row per product line on an order."
        # No load timestamp in the source; freshness inherited from shopify_orders.
        columns:
          - name: id
            tests: [not_null, unique]
          - name: order_id
            tests: [not_null]
      - name: shopify_products
        description: "Sellable products: coffee, gift box, accessory, subscription plan."
        loaded_at_field: created_at
        columns:
          - name: id
            tests: [not_null, unique]
      - name: shopify_subscriptions
        description: "Shopify subscription-app records. Carries cancellation_reason_top / _sub."
        # No single load timestamp; freshness checked via started_at at the source level.
        columns:
          - name: id
            tests: [not_null, unique]
          - name: customer_id
            tests: [not_null]

  - name: stripe
    database: acme_analytics
    schema: raw_stripe
    freshness:
      warn_after: {count: 25, period: hour}
      error_after: {count: 49, period: hour}
    tables:
      - name: stripe_customers
        description: "Stripe customers. System of record for money. Carries shopify_customer_id metadata link (NULL pre-2023)."
        loaded_at_field: created
        columns:
          - name: id
            tests: [not_null, unique]
          - name: shopify_customer_id
            description: "Metadata link to Shopify customer. NULL pre-2023 (DQ-1)."
      - name: stripe_charges
        description: "Stripe charges. Refunds are attributes of the charge."
        loaded_at_field: created
        columns:
          - name: id
            tests: [not_null, unique]
      - name: stripe_subscriptions
        description: "Stripe subscription state machine."
        loaded_at_field: current_period_start
        columns:
          - name: id
            tests: [not_null, unique]
      - name: stripe_invoices
        description: "Stripe invoices. Carries subscription_id — the recurring-revenue link for MRR."
        loaded_at_field: created
        columns:
          - name: id
            tests: [not_null, unique]
          - name: subscription_id
            description: "Link from invoice to subscription."

  - name: klaviyo
    database: acme_analytics
    schema: raw_klaviyo           # read from the existing raw_ schema (NFR-3, PD-2)
    freshness:
      warn_after: {count: 25, period: hour}
      error_after: {count: 49, period: hour}
    tables:
      - name: klaviyo_events
        description: "Klaviyo email/SMS events. user_id maps to shopify_customers.id; NULL ~12% pre-2024 (DQ-2)."
        loaded_at_field: timestamp
        columns:
          - name: id
            tests: [not_null, unique]
      - name: klaviyo_campaigns
        description: "Klaviyo campaigns."
        loaded_at_field: send_time
        columns:
          - name: id
            tests: [not_null, unique]
      - name: klaviyo_flows
        description: "Klaviyo automated flows."
        # No load timestamp; freshness checked at source level.
        columns:
          - name: id
            tests: [not_null, unique]
      # klaviyo_lists lands in raw_klaviyo but is out of scope — no staging model.

  - name: shipstation
    database: acme_analytics
    schema: raw_shipstation
    freshness:
      warn_after: {count: 25, period: hour}
      error_after: {count: 49, period: hour}
    tables:
      - name: shipstation_shipments
        description: "Shipstation shipments. Duplicate records exist (~0.5%, DQ-3); dedupe on tracking_number, keep earliest created_at."
        loaded_at_field: created_at
        columns:
          - name: id
            tests: [not_null, unique]
          - name: order_id
            description: "Maps to shopify_orders.id."
          - name: tracking_number
            description: "Dedupe key (DQ-3)."
      - name: shipstation_tracking_events
        description: "Carrier scans for a shipment."
        loaded_at_field: event_at
        columns:
          - name: id
            tests: [not_null, unique]
          - name: shipment_id
            tests: [not_null]

  - name: ga4
    database: acme_analytics
    schema: raw_ga4               # read from the existing raw_ schema (NFR-3, PD-2)
    freshness:
      warn_after: {count: 25, period: hour}    # source lands hourly; built daily in v1 (NFR-1)
      error_after: {count: 49, period: hour}
    tables:
      - name: ga4_sessions
        description: "GA4 web sessions. user_id NULL pre-2024 (DQ-2, OQ-4). Late arrivals reprocessed (DQ-4, PD-3)."
        loaded_at_field: session_start
        columns:
          - name: session_id
            tests: [not_null, unique]
      - name: ga4_events
        description: "GA4 web events. Out-of-order timestamps reprocessed on a 3-day lookback (DQ-4, PD-3)."
        loaded_at_field: event_timestamp
        columns:
          - name: event_id
            tests: [not_null, unique]
          - name: session_id
            tests: [not_null]
```

**Governance exclusions.** No field-level masking is required by the
requirements. Customer email and name are PII; email is carried through staging
and integration as the identity-resolution join key (FR-2, DQ-1) and is not
exposed in dashboards beyond what the explores need. `klaviyo_lists` is excluded
(out of scope). No free-text fields are excluded for safeguarding in this
engagement.

---

## 2. Staging Models

Sixteen staging models, one per in-scope raw table. Materialisation: `view`.
Tags: `['staging', '<source>']`. Staging renames columns, casts types, and
applies row-level cleaning only — no cross-source joins or business logic.

### stg_shopify__customers
**Source**: `shopify.shopify_customers`
**Grain**: One row per Shopify customer.
**Surrogate key**: `generate_surrogate_key(['id'])` → `customer_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | shopify_customer_id | int | Business key |
| email | email | string | Lowercased, trimmed. PII |
| first_name | first_name | string | PII |
| last_name | last_name | string | PII |
| country_code | country_code | string | ISO-2, uppercased |
| accepts_marketing | has_marketing_consent | bool | |
| created_at | created_at | timestamp | |
| updated_at | updated_at | timestamp | |

**Derived columns**: none.
**Tests**: `not_null(customer_pk)`, `unique(customer_pk)`, `not_null(shopify_customer_id)`.
**Canonical entity**: `subscription-commerce/subscriber` — constraints: tag name/email/phone/address columns `contains_pii: true`; do not strip PII columns to avoid tagging. Multi-source union and email dedupe are applied in `int_customers__identity__resolved`, not here. Reference: `verticals/subscription-commerce/reference-implementation/subscription-lifecycle-and-churn/models/marts/dim_subscriber.sql`.

### stg_shopify__orders
**Source**: `shopify.shopify_orders`
**Grain**: One row per Shopify order.
**Surrogate key**: `generate_surrogate_key(['id'])` → `order_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | shopify_order_id | int | Business key |
| customer_id | shopify_customer_id | int | NULL for guest orders (OQ-1) |
| email | email | string | Present on guest orders. PII |
| order_number | order_number | string | |
| financial_status | financial_status | string | |
| fulfillment_status | fulfillment_status | string | |
| total_price | total_price | float | |
| currency | currency | string | |
| market | market | string | uk / ie / fr / de |
| created_at | ordered_at | timestamp | |
| updated_at | updated_at | timestamp | |

**Derived columns**: `is_guest_order`: `shopify_customer_id IS NULL`.
**Tests**: `not_null(order_pk)`, `unique(order_pk)`.

### stg_shopify__order_lines
**Source**: `shopify.shopify_order_lines`
**Grain**: One row per order line.
**Surrogate key**: `generate_surrogate_key(['id'])` → `order_line_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | shopify_order_line_id | int | Business key |
| order_id | shopify_order_id | int | FK to order |
| product_id | shopify_product_id | int | FK to product |
| variant_id | shopify_variant_id | int | |
| quantity | quantity | int | |
| price | line_price | float | |
| total_discount | line_discount | float | |

**Derived columns**: `net_line_revenue`: `(line_price * quantity) - line_discount`.
**Tests**: `not_null(order_line_pk)`, `unique(order_line_pk)`, `not_null(shopify_order_id)`.

### stg_shopify__products
**Source**: `shopify.shopify_products`
**Grain**: One row per product.
**Surrogate key**: `generate_surrogate_key(['id'])` → `product_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | shopify_product_id | int | Business key |
| title | product_title | string | |
| product_type | product_type | string | coffee / gift_box / accessory / subscription |
| vendor | vendor | string | |
| created_at | created_at | timestamp | |

**Tests**: `not_null(product_pk)`, `unique(product_pk)`.

### stg_shopify__subscriptions
**Source**: `shopify.shopify_subscriptions`
**Grain**: One row per Shopify subscription record.
**Surrogate key**: `generate_surrogate_key(['id'])` → `shopify_subscription_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | shopify_subscription_id | int | Business key |
| customer_id | shopify_customer_id | int | FK to customer |
| product_id | shopify_product_id | int | FK to product (the plan) |
| status | shopify_status | string | active / paused / cancelled / failed |
| frequency_weeks | frequency_weeks | int | 2 / 4 / 8 |
| started_at | started_at | timestamp | |
| paused_at | paused_at | timestamp | |
| cancelled_at | cancelled_at | timestamp | |
| cancellation_reason_top | cancellation_reason_top | string | price / delivery / consumption |
| cancellation_reason_sub | cancellation_reason_sub | string | CS sub-reason |

**Tests**: `not_null(shopify_subscription_pk)`, `unique(shopify_subscription_pk)`, `not_null(shopify_customer_id)`.

### stg_stripe__customers
**Source**: `stripe.stripe_customers`
**Grain**: One row per Stripe customer.
**Surrogate key**: `generate_surrogate_key(['id'])` → `stripe_customer_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | stripe_customer_id | string | Business key |
| email | email | string | Lowercased, trimmed. PII |
| shopify_customer_id | shopify_customer_id | int | Metadata link; NULL pre-2023 (DQ-1) |
| created | created_at | timestamp | |

**Tests**: `not_null(stripe_customer_pk)`, `unique(stripe_customer_pk)`.

### stg_stripe__charges
**Source**: `stripe.stripe_charges`
**Grain**: One row per Stripe charge.
**Surrogate key**: `generate_surrogate_key(['id'])` → `payment_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | stripe_charge_id | string | Business key |
| customer_id | stripe_customer_id | string | FK to Stripe customer |
| amount | amount | float | |
| currency | currency | string | |
| status | status | string | succeeded / failed / refunded |
| refunded | is_refunded_flag | bool | |
| amount_refunded | amount_refunded | float | |
| created | charged_at | timestamp | |

**Derived columns**: `is_refunded`: `is_refunded_flag OR amount_refunded > 0`; `net_amount`: `amount - amount_refunded`; `is_succeeded`: `status = 'succeeded'`.
**Tests**: `not_null(payment_pk)`, `unique(payment_pk)`.

### stg_stripe__subscriptions
**Source**: `stripe.stripe_subscriptions`
**Grain**: One row per Stripe subscription record.
**Surrogate key**: `generate_surrogate_key(['id'])` → `stripe_subscription_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | stripe_subscription_id | string | Business key |
| customer_id | stripe_customer_id | string | FK to Stripe customer |
| status | stripe_status | string | active / past_due / canceled / unpaid |
| current_period_start | current_period_start | timestamp | |
| current_period_end | current_period_end | timestamp | |
| cancel_at_period_end | cancel_at_period_end | bool | |
| canceled_at | canceled_at | timestamp | |

**Tests**: `not_null(stripe_subscription_pk)`, `unique(stripe_subscription_pk)`.

### stg_stripe__invoices
**Source**: `stripe.stripe_invoices`
**Grain**: One row per Stripe invoice.
**Surrogate key**: `generate_surrogate_key(['id'])` → `invoice_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | stripe_invoice_id | string | Business key |
| customer_id | stripe_customer_id | string | FK to Stripe customer |
| subscription_id | stripe_subscription_id | string | FK to Stripe subscription (recurring-revenue link) |
| amount_paid | amount_paid | float | |
| status | status | string | |
| created | invoiced_at | timestamp | |

**Tests**: `not_null(invoice_pk)`, `unique(invoice_pk)`.

### stg_klaviyo__events
**Source**: `klaviyo.klaviyo_events`
**Grain**: One row per Klaviyo event.
**Surrogate key**: `generate_surrogate_key(['id'])` → `klaviyo_event_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | klaviyo_event_id | string | Business key |
| user_id | shopify_customer_id | int | Maps to Shopify id; NULL ~12% pre-2024 (DQ-2) |
| event_name | event_name | string | 40+ event types (OQ-8) |
| campaign_id | klaviyo_campaign_id | string | FK to campaign |
| flow_id | klaviyo_flow_id | string | FK to flow |
| timestamp | event_at | timestamp | |

**Derived columns**: `event_source`: `'klaviyo'`; `source_event_id`: `klaviyo_event_id`.
**Tests**: `not_null(klaviyo_event_pk)`, `unique(klaviyo_event_pk)`.

### stg_klaviyo__campaigns
**Source**: `klaviyo.klaviyo_campaigns`
**Grain**: One row per Klaviyo campaign.
**Surrogate key**: `generate_surrogate_key(['id'])` → `klaviyo_campaign_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | klaviyo_campaign_id | string | Business key |
| name | campaign_name | string | |
| send_time | send_time | timestamp | |
| channel | channel | string | email / sms |

**Tests**: `not_null(klaviyo_campaign_pk)`, `unique(klaviyo_campaign_pk)`.

### stg_klaviyo__flows
**Source**: `klaviyo.klaviyo_flows`
**Grain**: One row per Klaviyo flow.
**Surrogate key**: `generate_surrogate_key(['id'])` → `klaviyo_flow_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | klaviyo_flow_id | string | Business key |
| name | flow_name | string | |
| trigger_event | trigger_event | string | |

**Derived columns**: `channel`: `'email'` (flows are email automations in this dataset).
**Tests**: `not_null(klaviyo_flow_pk)`, `unique(klaviyo_flow_pk)`.

### stg_shipstation__shipments
**Source**: `shipstation.shipstation_shipments`
**Grain**: One row per shipment, after deduplication on `tracking_number`.
**Surrogate key**: `generate_surrogate_key(['tracking_number'])` → `shipment_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | shipstation_shipment_id | int | Raw shipment id (pre-dedupe) |
| order_id | shopify_order_id | int | FK to order |
| tracking_number | tracking_number | string | Dedupe/grain key |
| carrier | carrier | string | royal_mail / dpd / dhl / parcelforce |
| service_level | service_level | string | standard / next_day / express |
| shipped_at | shipped_at | timestamp | |
| delivered_at | delivered_at | timestamp | |
| created_at | created_at | timestamp | |

**Derived columns**: `delivery_days`: `datediff('day', shipped_at, delivered_at)`.
**Filters**: `QUALIFY ROW_NUMBER() OVER (PARTITION BY tracking_number ORDER BY created_at ASC) = 1` — DQ-3 dedupe, keep earliest `created_at`.
**Tests**: `not_null(shipment_pk)`, `unique(shipment_pk)`, `not_null(tracking_number)`.

### stg_shipstation__tracking_events
**Source**: `shipstation.shipstation_tracking_events`
**Grain**: One row per carrier scan.
**Surrogate key**: `generate_surrogate_key(['id'])` → `tracking_event_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| id | shipstation_tracking_event_id | int | Business key |
| shipment_id | shipstation_shipment_id | int | Raw shipment id; resolved to shipment_pk in integration |
| event_type | event_type | string | picked_up / in_transit / out_for_delivery / delivered |
| event_at | event_at | timestamp | |

**Tests**: `not_null(tracking_event_pk)`, `unique(tracking_event_pk)`, `not_null(shipstation_shipment_id)`.

### stg_ga4__sessions
**Source**: `ga4.ga4_sessions`
**Grain**: One row per GA4 session.
**Surrogate key**: `generate_surrogate_key(['session_id'])` → `web_session_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| session_id | ga4_session_id | string | Business key |
| user_id | shopify_customer_id | int | NULL pre-2024 (DQ-2, OQ-4) |
| session_start | session_start | timestamp | |
| source | source | string | google / meta / klaviyo / direct / referral |
| medium | medium | string | cpc / organic / email / paid_social |
| campaign | ga4_campaign_text | string | Free text, not keyed to Klaviyo (conceptual_model.md §5) |
| device | device | string | mobile / desktop / tablet |

**Derived columns**: DQ-4 late-arrival handled by an incremental build with a 3-day lookback window (PD-3), deduplicating on `session_id`.
**Tests**: `not_null(web_session_pk)`, `unique(web_session_pk)`.
**Canonical entity**: `cross-vertical/ga4_ecommerce/web_session` — used loosely. Acme's GA4 arrives already sessionized on `session_id`, so the registry's nested-export unnesting marts do not apply; only the session-grain web-session concept is carried. Reference: `cross-vertical/schemas/ga4_ecommerce/` (adjacent).

### stg_ga4__events
**Source**: `ga4.ga4_events`
**Grain**: One row per GA4 event.
**Surrogate key**: `generate_surrogate_key(['event_id'])` → `ga4_event_pk`

| Source column | Staged column | Type | Notes |
|--------------|---------------|------|-------|
| event_id | ga4_event_id | string | Business key |
| session_id | ga4_session_id | string | FK to session |
| user_id | shopify_customer_id | int | NULL pre-2024 (DQ-2) |
| event_name | event_name | string | page_view / add_to_cart / purchase |
| event_timestamp | event_at | timestamp | |
| page_path | page_path | string | |

**Derived columns**: `event_source`: `'ga4'`; `source_event_id`: `ga4_event_id`. DQ-4 late-arrival handled by the 3-day lookback incremental (PD-3), deduplicating on `event_id`.
**Tests**: `not_null(ga4_event_pk)`, `unique(ga4_event_pk)`, `not_null(ga4_session_id)`.

---

## 3. Integration Models

Seven integration models do the cross-source work: identity resolution, state
reconciliation, union, and the retention classification. Materialisation:
`view` (or `table` where the downstream marts read the result repeatedly).
Tags: `['integration', '<group>']`.

**Naming note.** The `data_model-validate` convention is
`int_<group>__<subject>__<description>` (three segments). The approved pipeline
architecture listed these models in the two-segment `int_<group>__<subject>`
form. Names below adopt the three-segment form for convention compliance; each
is a one-token split of its pipeline-design name, so the mapping is direct:

| Pipeline architecture name | Data model name |
|----------------------------|-----------------|
| int_customers__identity_resolved | int_customers__identity__resolved |
| int_orders__order_enriched | int_orders__order__enriched |
| int_subscriptions__state_reconciled | int_subscriptions__state__reconciled |
| int_payments__charge_invoice | int_payments__charge__invoice |
| int_marketing__event_stream | int_marketing__event__stream |
| int_fulfilment__shipment_delivery | int_fulfilment__shipment__delivery |
| (added — registry-informed, DM-1) | int_subscriptions__retention__monthly |

### int_customers__identity__resolved
**Purpose**: Resolve Shopify and Stripe customers to one canonical customer (FR-2).
**Grain**: One row per resolved customer.
**Surrogate key**: `generate_surrogate_key(['resolved_customer_natural_key'])` → `customer_pk`
**Inputs**: `stg_shopify__customers`, `stg_stripe__customers`, seed `customer_identity_overrides`.
**Logic**: Union Shopify and Stripe customer records. Resolve Stripe to Shopify first on `shopify_customer_id` (metadata link, 2023+), then fall back to `lower(email)` match. Apply the manual override seed for the ~800 pre-2023 records the first two rules miss (DQ-1). Some email mismatches are deliberate (staff accounts) and are not errors. Shopify is the source of record for customer identity; Stripe attributes fill where Shopify is absent. Record the source-of-record priority explicitly.
**Open item**: DQ-1 — the ~800 pre-2023 re-links depend on the override seed being populated.
**Canonical entities**: `subscription-commerce/subscriber` (constraints: union identity records from every system; dedupe on email keeping the highest-priority source; make the priority order explicit; tag PII) and `cross-vertical/crm_identity_resolution` used loosely (the manual merge-list seed tier maps to the DQ-1 override seed). References: `verticals/subscription-commerce/reference-implementation/subscription-lifecycle-and-churn/models/marts/dim_subscriber.sql`; `cross-vertical/schemas/crm_identity_resolution/` (adjacent).

### int_orders__order__enriched
**Purpose**: Join order lines to orders and products (FR-3).
**Grain**: One row per order line.
**Surrogate key**: `order_line_pk` (carried from `stg_shopify__order_lines`).
**Inputs**: `stg_shopify__orders`, `stg_shopify__order_lines`, `stg_shopify__products`, `int_customers__identity__resolved`.
**Logic**: Attach order header (financial status, market, ordered_at), product attributes, and the resolved `customer_pk` (NULL for guest orders) to each order line. Carry `market` for market assignment.
**Open item**: OQ-1 — guest-order revenue treatment (NULL customer).

### int_subscriptions__state__reconciled
**Purpose**: Reconcile the Shopify and Stripe subscription state machines to one subscription (FR-4).
**Grain**: One row per reconciled subscription.
**Surrogate key**: `generate_surrogate_key(['resolved_subscription_natural_key'])` → `subscription_pk`
**Inputs**: `stg_shopify__subscriptions`, `stg_stripe__subscriptions`, `int_customers__identity__resolved`.
**Logic**: Match Shopify and Stripe subscriptions via the resolved customer and overlapping active period (no direct subscription key exists across the two systems). Resolve one canonical status from the two state machines, which disagree on ~3%, concentrated on pauses and trial conversions. Carry the cancellation reasons from Shopify.
**Open item**: OQ-2 — the precedence rule (which system wins) is not agreed. Until it is, the reconciliation applies a documented default (Stripe wins on billing state, Shopify wins on pause state) flagged for confirmation.
**Canonical entity**: `subscription-commerce/subscription`, adapted. The registry's migration-safe `retention_subscription_natural_key` (recursive migration chain) is **dropped** — Acme runs one subscription app plus Stripe, with no billing-platform migration. The registry's "union subscriptions across every billing platform, one CTE per platform" constraint is **kept** and reused as the Shopify/Stripe reconciliation. Reference: `verticals/subscription-commerce/reference-implementation/subscription-lifecycle-and-churn/models/intermediate/int_subscription.sql`.

### int_payments__charge__invoice
**Purpose**: Associate Stripe charges with invoices for MRR refund netting (FR-6).
**Grain**: One row per Stripe charge.
**Surrogate key**: `payment_pk` (carried from `stg_stripe__charges`).
**Inputs**: `stg_stripe__charges`, `stg_stripe__invoices`, `int_customers__identity__resolved`.
**Logic**: Attach the resolved `customer_pk` to each charge. Best-effort associate a charge to an invoice on `stripe_customer_id` plus nearest billing period, because the source carries no key linking a charge to an invoice.
**Open item**: conceptual_model.md §5 (charge-to-invoice reconciliation) — no direct key. The association is approximate and bounds how exactly refunds net against recurring revenue for MRR.

### int_marketing__event__stream
**Purpose**: Union Klaviyo and GA4 events; attach customer, campaign, and canonical channel (FR-7).
**Grain**: One row per marketing event.
**Surrogate key**: `generate_surrogate_key(['event_source', 'source_event_id'])` → `marketing_event_pk`
**Inputs**: `stg_klaviyo__events`, `stg_ga4__events`, `stg_ga4__sessions`, `stg_klaviyo__campaigns`, `stg_klaviyo__flows`, `int_customers__identity__resolved`, seed `channel_mapping`.
**Logic**: Union Klaviyo events (clean customer link on `shopify_customer_id`) and GA4 events (customer link via `shopify_customer_id`, NULL pre-2024). Map GA4 `source`/`medium` and Klaviyo `channel` to one canonical channel through the `channel_mapping` seed. Attach the Klaviyo campaign/flow where present; GA4 free-text campaign is kept as a degenerate attribute, not keyed.
**Open items**: OQ-4 (GA4-to-Stripe identity key); DQ-2 (~12% GA4 events with no customer pre-2024); conceptual_model.md §5 (campaign reconciliation).
**Canonical entities**: `cross-vertical/multi_touch_attribution` and `cross-vertical/event_tracking_and_sessionization`, used loosely. The per-conversion attribution-window concept informs the downstream attribution mart; Acme v1 needs channel attribution, not the registry's eight simultaneous models. References: `cross-vertical/schemas/multi_touch_attribution/`, `cross-vertical/schemas/event_tracking_and_sessionization/` (adjacent).

### int_fulfilment__shipment__delivery
**Purpose**: Join shipments to tracking events for delivery timing (FR-8).
**Grain**: One row per deduplicated shipment.
**Surrogate key**: `shipment_pk` (carried from `stg_shipstation__shipments`).
**Inputs**: `stg_shipstation__shipments`, `stg_shipstation__tracking_events`, `int_orders__order__enriched`.
**Logic**: Resolve each tracking event's raw `shipstation_shipment_id` to the surviving deduplicated `shipment_pk` (via the shipment's `tracking_number`), then roll up delivery milestones. Attach the order's resolved `customer_pk` and `market` via `shopify_order_id`. Derive on-time delivery against the shipped/delivered timestamps.

### int_subscriptions__retention__monthly
**Purpose**: Classify each subscription-month as new, true_retained, reactivated, or churn — the shared input for the churn, cohort-retention, MRR, and LTV marts (FR-5). **Added model (DM-1), registry-informed.**
**Grain**: One row per (reconciled subscription, subscription month).
**Surrogate key**: `generate_surrogate_key(['subscription_pk', 'subscription_month'])` → `monthly_retention_pk`
**Inputs**: `int_subscriptions__state__reconciled`, `int_payments__charge__invoice`, `stg_stripe__invoices`, dbt var `subscription_retention_config`.
**Logic**: Build a monthly retention timeline per subscription by unioning actual billed months, scheduled-but-unconfirmed months in the current open period, and months stuck in payment retry; classify each month with window functions keyed on the subscription; synthesize a churn record only once the month has fully closed, so a daily re-run does not flag active subscribers as false churn. Source the reactivation-gap and churn-confirmation-lag thresholds from the `subscription_retention_config` dbt var, not hardcoded.
**Why it was added (DM-1)**: the churn mart and the cohort-retention mart both need this classification, and so do MRR (active months only) and LTV. Computing it once in one integration model avoids duplicating the most load-bearing piece of subscription logic across four marts. The pipeline architecture did not list it; it is a design-level addition, recorded in Section 10 and `decisions.md`.
**Open items**: OQ-2 (state precedence feeds the classification); OQ-9 (whether a pause counts as churn).
**Canonical entity**: `subscription-commerce/monthly_retention`, adapted — see Section 10 for the grain decision. Constraints kept: three-CTE timeline union; window classification on the subscription key; look-ahead-gated churn synthesis; config-driven thresholds. Reference: `verticals/subscription-commerce/reference-implementation/subscription-lifecycle-and-churn/models/intermediate/int_monthly_subscription_retention.sql` and `.../models/marts/fct_monthly_subscription_retention.sql`.

---

## 4. Warehouse Models

Twenty warehouse models: 6 dimensions, 8 facts, 6 aggregate marts.
Materialisation: `table`. Every warehouse model carries
`dbt_updated_at: current_timestamp()`. Tags: `['warehouse', 'dimension' | 'fact' | 'aggregate']`.

Model names are kept exactly as the approved pipeline architecture lists them.

### Dimensions

#### wh_customers__customer_dim
**Grain**: One row per resolved customer.
**Surrogate key**: `customer_pk`
**Foreign keys**: `address_fk → wh_customers__address_dim.address_pk` (by `country_code`).
**Source**: `int_customers__identity__resolved`.
**Attributes**: email (PII), first_name (PII), last_name (PII), country_code, has_marketing_consent, shopify_customer_id, stripe_customer_id, signup_date, source_system.
**Audit**: `dbt_updated_at`.
**Canonical entity**: `subscription-commerce/subscriber` (kept, renamed from `dim_subscriber` to Acme convention).

#### wh_customers__address_dim
**Grain**: One row per country/market. (See the Address gap, Section 9 — no street-address source exists.)
**Surrogate key**: `generate_surrogate_key(['country_code'])` → `address_pk`
**Source**: seed `market_rollup`, distinct `country_code` from `wh_customers__customer_dim`.
**Attributes**: country_code, market_name, finance_rollup (UK and Ireland grouped; France and Germany separate — requirements assumption 4), region_label.
**Audit**: `dbt_updated_at`.
**Note**: Serves as the conformed market/geography dimension. Absent an address source (conceptual_model.md §5, OQ-7 closed market scope), this is built at country grain, not postal grain. Decision DM-2, Section 10.

#### wh_orders__product_dim
**Grain**: One row per product.
**Surrogate key**: `product_pk`
**Source**: `stg_shopify__products`.
**Attributes**: shopify_product_id, product_title, product_type, vendor, created_at.
**Audit**: `dbt_updated_at`.

#### wh_subscriptions__subscription_dim
**Grain**: One row per reconciled subscription.
**Surrogate key**: `subscription_pk`
**Foreign keys**: `customer_fk → wh_customers__customer_dim.customer_pk`; `product_fk → wh_orders__product_dim.product_pk`; `cancellation_reason_fk → wh_subscriptions__cancellation_reason_dim.cancellation_reason_pk` (NULL unless cancelled).
**Source**: `int_subscriptions__state__reconciled`.
**Attributes**: canonical status, frequency_weeks, started_at, paused_at, cancelled_at, shopify_subscription_id, stripe_subscription_id, source_system.
**Audit**: `dbt_updated_at`.
**Canonical entity**: `subscription-commerce/subscription` (adapted, Section 10).

#### wh_subscriptions__cancellation_reason_dim
**Grain**: One row per canonical cancellation reason (3 top-level + 14 sub-tags = 17 rows).
**Surrogate key**: `generate_surrogate_key(['canonical_reason_code'])` → `cancellation_reason_pk`
**Foreign keys**: `parent_reason_fk → wh_subscriptions__cancellation_reason_dim.cancellation_reason_pk` (self-reference; NULL for top-level reasons).
**Source**: seed `cancellation_reason_taxonomy`.
**Attributes**: canonical_reason_code, reason_label, reason_level (top / sub), source_shopify_value, source_stripe_value, source_cs_value.
**Audit**: `dbt_updated_at`.
**Open item**: OQ-3 — the taxonomy is proposed, not confirmed by Cathy. This dimension and the churn mart are a build-blocker until she signs off (FR-9).

#### wh_marketing__campaign_dim
**Grain**: One row per Klaviyo campaign or flow.
**Surrogate key**: `campaign_pk`
**Source**: `stg_klaviyo__campaigns` unioned with `stg_klaviyo__flows`.
**Attributes**: klaviyo_campaign_id, klaviyo_flow_id, campaign_name, campaign_type (campaign / flow), channel (email / sms), send_time, trigger_event.
**Audit**: `dbt_updated_at`.
**Note**: Klaviyo-only. GA4 free-text campaigns are not reconciled into this dimension (conceptual_model.md §5).

### Facts

#### wh_orders__order_line_fact
**Grain**: One row per order line (order carried as header context).
**Surrogate key**: `order_line_pk`
**Foreign keys**: `customer_fk → wh_customers__customer_dim.customer_pk` (NULL for guest orders); `product_fk → wh_orders__product_dim.product_pk`; `address_fk → wh_customers__address_dim.address_pk`.
**Source**: `int_orders__order__enriched`.
**Degenerate dimensions**: shopify_order_id, order_number, financial_status, fulfillment_status, market, ordered_at.
**Measures**: quantity, line_price, line_discount, net_line_revenue.
**Flags**: is_guest_order.
**Audit**: `dbt_updated_at`.

#### wh_subscriptions__subscription_event_fact
**Grain**: One row per subscription state change.
**Surrogate key**: `generate_surrogate_key(['subscription_pk', 'event_type', 'event_at'])` → `subscription_event_pk`
**Foreign keys**: `subscription_fk → wh_subscriptions__subscription_dim.subscription_pk`; `customer_fk → wh_customers__customer_dim.customer_pk`.
**Source**: `int_subscriptions__state__reconciled` (state fields and their change timestamps unpivoted to events).
**Attributes**: event_type (started / paused / resumed / cancelled / renewed), event_at, source_system.
**Measures**: event_count (1 per row, for additive rollups).
**Audit**: `dbt_updated_at`.
**Canonical entity**: `subscription-commerce/subscription_event`, adapted. The registry's typed-mutation derivation (event type from presence/absence of timestamps, not a free-text field) is kept. The registry's richer attributes (before/after values, dunning, winback, competitor) are dropped — Acme's sources carry only status plus started/paused/cancelled timestamps. Reference: `verticals/subscription-commerce/reference-implementation/subscription-lifecycle-and-churn/models/marts/fct_subscription_version.sql`.

#### wh_payments__payment_fact
**Grain**: One row per Stripe charge.
**Surrogate key**: `payment_pk`
**Foreign keys**: `customer_fk → wh_customers__customer_dim.customer_pk`.
**Source**: `int_payments__charge__invoice`.
**Degenerate dimensions**: stripe_charge_id, currency, status, charged_at.
**Measures**: amount, amount_refunded, net_amount.
**Flags**: is_refunded, is_succeeded.
**Audit**: `dbt_updated_at`.

#### wh_payments__invoice_fact
**Grain**: One row per Stripe invoice.
**Surrogate key**: `invoice_pk`
**Foreign keys**: `customer_fk → wh_customers__customer_dim.customer_pk`; `subscription_fk → wh_subscriptions__subscription_dim.subscription_pk`.
**Source**: `stg_stripe__invoices` joined to `int_customers__identity__resolved` and `int_subscriptions__state__reconciled`.
**Degenerate dimensions**: stripe_invoice_id, status, invoiced_at.
**Measures**: amount_paid.
**Audit**: `dbt_updated_at`.

#### wh_marketing__marketing_event_fact
**Grain**: One row per marketing event (Klaviyo and GA4 unioned).
**Surrogate key**: `marketing_event_pk`
**Foreign keys**: `customer_fk → wh_customers__customer_dim.customer_pk` (NULL where unresolved); `campaign_fk → wh_marketing__campaign_dim.campaign_pk` (NULL for GA4 events); `web_session_fk → wh_marketing__web_session_fact.web_session_pk` (NULL for email/SMS events).
**Source**: `int_marketing__event__stream`.
**Degenerate dimensions**: event_source (klaviyo / ga4), event_name, channel, event_at.
**Measures**: event_count (1 per row).
**Audit**: `dbt_updated_at`.

#### wh_marketing__web_session_fact
**Grain**: One row per GA4 session.
**Surrogate key**: `web_session_pk`
**Foreign keys**: `customer_fk → wh_customers__customer_dim.customer_pk` (NULL pre-2024).
**Source**: `stg_ga4__sessions` joined to `int_customers__identity__resolved`.
**Degenerate dimensions**: ga4_session_id, source, medium, ga4_campaign_text, device, session_start.
**Measures**: session_count (1 per row).
**Audit**: `dbt_updated_at`.
**Canonical entity**: `cross-vertical/ga4_ecommerce/web_session` (loosely).

#### wh_fulfilment__shipment_fact
**Grain**: One row per deduplicated shipment.
**Surrogate key**: `shipment_pk`
**Foreign keys**: `customer_fk → wh_customers__customer_dim.customer_pk` (via order); `address_fk → wh_customers__address_dim.address_pk` (via order market).
**Source**: `int_fulfilment__shipment__delivery`.
**Degenerate dimensions**: shopify_order_id, tracking_number, carrier, service_level, shipped_at, delivered_at.
**Measures**: delivery_days.
**Flags**: is_on_time, is_delivered.
**Audit**: `dbt_updated_at`.

#### wh_fulfilment__tracking_event_fact
**Grain**: One row per carrier scan.
**Surrogate key**: `tracking_event_pk`
**Foreign keys**: `shipment_fk → wh_fulfilment__shipment_fact.shipment_pk`.
**Source**: `int_fulfilment__shipment__delivery` (tracking-event grain).
**Degenerate dimensions**: event_type, event_at.
**Measures**: event_count (1 per row).
**Audit**: `dbt_updated_at`.

### Aggregate marts

Built over the models above. Aggregate marts carry the `_fact` suffix per the
pipeline architecture. These are derived aggregates, not conceptual entities.

#### wh_subscriptions__mrr_fact
**Grain**: One row per (revenue month, market).
**Surrogate key**: `generate_surrogate_key(['revenue_month', 'address_pk'])` → `mrr_pk`
**Foreign keys**: `address_fk → wh_customers__address_dim.address_pk`.
**Source**: `int_subscriptions__retention__monthly`, `int_payments__charge__invoice`, `wh_subscriptions__subscription_dim`.
**Measures**: committed_mrr, refunds_30d (rolling 30-day), net_mrr (committed_mrr less refunds_30d), active_subscriptions.
**Audit**: `dbt_updated_at`.
**Canonical entity**: `subscription-commerce/subscription_revenue`, used loosely. The cadence-amortization pattern (convert billing frequency to a monthly basis) is kept. Net-of-refunds on a rolling 30-day window is Acme-specific and beyond the registry entity's scope, which the registry notes is committed revenue only. Reference: `verticals/subscription-commerce/reference-implementation/subscription-lifecycle-and-churn/models/marts/fct_subscription_revenue.sql`.

#### wh_subscriptions__churn_fact
**Grain**: One row per (churn month, canonical cancellation reason).
**Surrogate key**: `generate_surrogate_key(['churn_month', 'cancellation_reason_pk'])` → `churn_pk`
**Foreign keys**: `cancellation_reason_fk → wh_subscriptions__cancellation_reason_dim.cancellation_reason_pk`.
**Source**: `int_subscriptions__retention__monthly`, `wh_subscriptions__cancellation_reason_dim`.
**Measures**: gross_churn_count, net_churn_count, prior_month_active, gross_churn_rate, net_churn_rate.
**Audit**: `dbt_updated_at`.
**Open items**: OQ-3 (cancellation taxonomy, build-blocker); OQ-9 (pause vs cancel treatment).
**Canonical entity**: `subscription-commerce/monthly_retention` (classification logic).

#### wh_subscriptions__cohort_retention_fact
**Grain**: One row per (cohort month, period number since join).
**Surrogate key**: `generate_surrogate_key(['cohort_month', 'period_number'])` → `cohort_retention_pk`
**Foreign keys**: none (cohort month and period number are degenerate dates).
**Source**: `int_subscriptions__retention__monthly`.
**Measures**: cohort_size, retained_count, retention_rate.
**Audit**: `dbt_updated_at`.
**Canonical entity**: `subscription-commerce/monthly_retention` (loosely; the cohort pivot is Acme-specific).

#### wh_subscriptions__ltv_fact
**Grain**: One row per (cohort month, market).
**Surrogate key**: `generate_surrogate_key(['cohort_month', 'address_pk'])` → `ltv_pk`
**Foreign keys**: `address_fk → wh_customers__address_dim.address_pk`.
**Source**: `int_subscriptions__retention__monthly`, `int_payments__charge__invoice`, `wh_customers__customer_dim`.
**Measures**: cohort_size, first_month_ltv, full_ltv.
**Audit**: `dbt_updated_at`.
**Note**: Full LTV by cohort feeds the Subscriptions dashboard; first-month LTV feeds the Marketing dashboard (FR-5, FR-11). No registry entity — the registry notes LTV is an acknowledged gap in `subscription_lifecycle`. This model is Acme-specific.

#### wh_marketing__attribution_fact
**Grain**: One row per (acquisition month, first-touch channel, market).
**Surrogate key**: `generate_surrogate_key(['acquisition_month', 'first_touch_channel', 'address_pk'])` → `attribution_pk`
**Foreign keys**: `campaign_fk → wh_marketing__campaign_dim.campaign_pk` (NULL where first touch is GA4-only); `product_fk → wh_orders__product_dim.product_pk` (first acquiring order's product); `address_fk → wh_customers__address_dim.address_pk`.
**Source**: `int_marketing__event__stream`, `wh_customers__customer_dim`, `int_payments__charge__invoice`, `wh_orders__order_line_fact`.
**Degenerate dimensions**: first_touch_channel, acquisition_date.
**Measures**: customers_acquired, first_month_ltv. CAC is left as a semantic-layer calculation — see the CAC spend gap, Section 9.
**Audit**: `dbt_updated_at`.
**Open item**: OQ-4 (GA4-to-Stripe identity key bounds attribution to 2024+).
**Semantic-layer note**: carries the five self-serve slicing keys the Looker marketing fact needs (FR-12) — campaign_fk, first_touch_channel, product_fk, address_fk (market), acquisition_date.
**Canonical entity**: `cross-vertical/multi_touch_attribution` (loosely).

#### wh_fulfilment__on_time_delivery_fact
**Grain**: One row per (ship month, carrier, service level).
**Surrogate key**: `generate_surrogate_key(['ship_month', 'carrier', 'service_level'])` → `on_time_delivery_pk`
**Foreign keys**: `address_fk → wh_customers__address_dim.address_pk` (by order market).
**Source**: `int_fulfilment__shipment__delivery`.
**Degenerate dimensions**: carrier, service_level, ship_month.
**Measures**: shipments, on_time_count, on_time_rate, avg_delivery_days.
**Audit**: `dbt_updated_at`.

---

## 5. Seed Files

Four configuration seeds encode business logic that must be editable without a
code change. Raw-source demo seeds (the 17 CSVs that load the `raw_` tables for
the demo) are an ingestion concern, covered by `/wire:seed_data-generate`, and
are not listed here.

### seeds/cancellation_reason_taxonomy.csv
**Purpose**: The canonical cancellation reason list (FR-9) — 3 top-level reasons with 14 CS sub-tags — and the mapping from the three source lists (Shopify 8, Stripe 4, CS 14) to the canonical reasons.
**Columns**: `canonical_reason_code` (string), `reason_label` (string), `reason_level` (top / sub), `parent_reason_code` (string, NULL for top-level), `source_shopify_value` (string), `source_stripe_value` (string), `source_cs_value` (string).
**Sample rows**:
```
canonical_reason_code,reason_label,reason_level,parent_reason_code,source_shopify_value,source_stripe_value,source_cs_value
price,Price,top,,too_expensive,price,
price_budget,Budget / cost,sub,price,too_expensive,price,budget
delivery,Delivery,top,,delivery_issue,,
delivery_late,Late or missed delivery,sub,delivery,delivery_issue,,late_delivery
consumption,Consumption,top,,too_much_coffee,,
consumption_too_much,Too much coffee,sub,consumption,too_much_coffee,,too_much
```
**Used by**: `wh_subscriptions__cancellation_reason_dim`, `wh_subscriptions__churn_fact`.
**Open item**: OQ-3 — proposed, pending Cathy's sign-off. Build-blocker.

### seeds/channel_mapping.csv
**Purpose**: Map GA4 `source`/`medium` and Klaviyo `channel` to one canonical marketing channel, for the attribution mart and the Marketing dashboard's five slicing dimensions (FR-7, FR-12).
**Columns**: `source` (string), `medium` (string), `canonical_channel` (string), `is_paid` (bool).
**Sample rows**:
```
source,medium,canonical_channel,is_paid
google,cpc,paid_search,true
meta,paid_social,paid_social,true
klaviyo,email,email,false
direct,,direct,false
referral,referral,referral,false
```
**Used by**: `int_marketing__event__stream`, `wh_marketing__attribution_fact`.

### seeds/market_rollup.csv
**Purpose**: Map `country_code` to a market name and the finance rollup (UK and Ireland grouped; France and Germany separate — requirements assumption 4, OQ-7).
**Columns**: `country_code` (string), `market_name` (string), `finance_rollup` (string).
**Sample rows**:
```
country_code,market_name,finance_rollup
GB,United Kingdom,UK & Ireland
IE,Ireland,UK & Ireland
FR,France,France
DE,Germany,Germany
```
**Used by**: `wh_customers__address_dim`.

### seeds/customer_identity_overrides.csv
**Purpose**: Manual re-link overrides for the ~800 pre-2023 customer records where the automatic email-plus-metadata rule fails (DQ-1). This is the manual merge-list tier of the `crm_identity_resolution` pattern.
**Columns**: `stripe_customer_id` (string), `shopify_customer_id` (int), `note` (string).
**Sample rows**:
```
stripe_customer_id,shopify_customer_id,note
cus_000142,80231,pre-2023 email changed; confirmed same customer
cus_000318,80559,staff account re-link
cus_000774,81004,duplicate Stripe record merged
```
**Used by**: `int_customers__identity__resolved`.

**Configuration not held as a seed.** The subscription retention thresholds
(reactivation gap, churn confirmation lag) are supplied through the
`subscription_retention_config` dbt var consumed by
`int_subscriptions__retention__monthly`, per the registry pattern, rather than a
seed.

---

## 6. Cross-System Join Keys

Eight cross-system joins. The high-risk ones (no shared key, or an unresolved
open question) are flagged; these are the joins most likely to misstate a
headline number.

| Left model | Column | Right model | Column | Notes |
|-----------|--------|------------|--------|-------|
| stg_stripe__customers | shopify_customer_id | stg_shopify__customers | shopify_customer_id | Primary link (2023+ metadata). int. type both sides |
| stg_stripe__customers | lower(email) | stg_shopify__customers | lower(email) | Fallback link. string both sides. DQ-1 (~800 pre-2023 re-linked via override seed). **High risk** |
| stg_klaviyo__events | shopify_customer_id | stg_shopify__customers | shopify_customer_id | Clean (Shopify id as Klaviyo external id). int. ~12% NULL pre-2024 (DQ-2) |
| stg_ga4__sessions | shopify_customer_id | stg_shopify__customers | shopify_customer_id | user_id → customer. int. NULL pre-2024; no key to Stripe revenue (OQ-4). **High risk** |
| stg_stripe__charges | stripe_customer_id + period | stg_stripe__invoices | stripe_customer_id + period | No charge-to-invoice key; best-effort by customer and billing period (conceptual_model.md §5). **High risk** |
| stg_shipstation__shipments | shopify_order_id | stg_shopify__orders | shopify_order_id | Clean. int both sides |
| stg_shipstation__tracking_events | shipstation_shipment_id | stg_shipstation__shipments | shipstation_shipment_id → shipment_pk | Raw shipment id maps to the deduplicated shipment via tracking_number (DQ-3). Cross-grain |
| (no reconciled subscription key) | resolved customer + period | stg_stripe__subscriptions / stg_shopify__subscriptions | resolved customer + period | Shopify and Stripe share no subscription key; match via resolved customer and overlapping active period (OQ-2). **High risk** |
| stg_ga4__sessions | ga4_campaign_text (free text) | stg_klaviyo__campaigns | campaign_name | No reliable key; GA4 campaign is free text (conceptual_model.md §5). Not joined; GA4 campaign kept as degenerate text. **High risk** |

---

## 7. Physical Data Model

```mermaid
erDiagram
    CUSTOMER_DIM {
        string customer_pk PK
        string address_fk FK
        string email
        string first_name
        string last_name
        string country_code
        bool has_marketing_consent
        int shopify_customer_id
        string stripe_customer_id
        date signup_date
        string source_system
        timestamp dbt_updated_at
    }
    ADDRESS_DIM {
        string address_pk PK
        string country_code
        string market_name
        string finance_rollup
        string region_label
        timestamp dbt_updated_at
    }
    PRODUCT_DIM {
        string product_pk PK
        int shopify_product_id
        string product_title
        string product_type
        string vendor
        timestamp created_at
        timestamp dbt_updated_at
    }
    SUBSCRIPTION_DIM {
        string subscription_pk PK
        string customer_fk FK
        string product_fk FK
        string cancellation_reason_fk FK
        string status
        int frequency_weeks
        timestamp started_at
        timestamp paused_at
        timestamp cancelled_at
        string source_system
        timestamp dbt_updated_at
    }
    CANCELLATION_REASON_DIM {
        string cancellation_reason_pk PK
        string parent_reason_fk FK
        string canonical_reason_code
        string reason_label
        string reason_level
        timestamp dbt_updated_at
    }
    CAMPAIGN_DIM {
        string campaign_pk PK
        string klaviyo_campaign_id
        string campaign_name
        string campaign_type
        string channel
        timestamp send_time
        timestamp dbt_updated_at
    }
    ORDER_LINE_FACT {
        string order_line_pk PK
        string customer_fk FK
        string product_fk FK
        string address_fk FK
        int shopify_order_id
        string financial_status
        string market
        int quantity
        float line_price
        float line_discount
        float net_line_revenue
        bool is_guest_order
        timestamp ordered_at
        timestamp dbt_updated_at
    }
    SUBSCRIPTION_EVENT_FACT {
        string subscription_event_pk PK
        string subscription_fk FK
        string customer_fk FK
        string event_type
        timestamp event_at
        string source_system
        int event_count
        timestamp dbt_updated_at
    }
    PAYMENT_FACT {
        string payment_pk PK
        string customer_fk FK
        string stripe_charge_id
        string currency
        string status
        float amount
        float amount_refunded
        float net_amount
        bool is_refunded
        bool is_succeeded
        timestamp charged_at
        timestamp dbt_updated_at
    }
    INVOICE_FACT {
        string invoice_pk PK
        string customer_fk FK
        string subscription_fk FK
        string stripe_invoice_id
        string status
        float amount_paid
        timestamp invoiced_at
        timestamp dbt_updated_at
    }
    MARKETING_EVENT_FACT {
        string marketing_event_pk PK
        string customer_fk FK
        string campaign_fk FK
        string web_session_fk FK
        string event_source
        string event_name
        string channel
        int event_count
        timestamp event_at
        timestamp dbt_updated_at
    }
    WEB_SESSION_FACT {
        string web_session_pk PK
        string customer_fk FK
        string ga4_session_id
        string source
        string medium
        string ga4_campaign_text
        string device
        int session_count
        timestamp session_start
        timestamp dbt_updated_at
    }
    SHIPMENT_FACT {
        string shipment_pk PK
        string customer_fk FK
        string address_fk FK
        int shopify_order_id
        string tracking_number
        string carrier
        string service_level
        int delivery_days
        bool is_on_time
        bool is_delivered
        timestamp shipped_at
        timestamp delivered_at
        timestamp dbt_updated_at
    }
    TRACKING_EVENT_FACT {
        string tracking_event_pk PK
        string shipment_fk FK
        string event_type
        int event_count
        timestamp event_at
        timestamp dbt_updated_at
    }
    MRR_FACT {
        string mrr_pk PK
        string address_fk FK
        date revenue_month
        float committed_mrr
        float refunds_30d
        float net_mrr
        int active_subscriptions
        timestamp dbt_updated_at
    }
    CHURN_FACT {
        string churn_pk PK
        string cancellation_reason_fk FK
        date churn_month
        int gross_churn_count
        int net_churn_count
        int prior_month_active
        float gross_churn_rate
        float net_churn_rate
        timestamp dbt_updated_at
    }
    COHORT_RETENTION_FACT {
        string cohort_retention_pk PK
        date cohort_month
        int period_number
        int cohort_size
        int retained_count
        float retention_rate
        timestamp dbt_updated_at
    }
    LTV_FACT {
        string ltv_pk PK
        string address_fk FK
        date cohort_month
        int cohort_size
        float first_month_ltv
        float full_ltv
        timestamp dbt_updated_at
    }
    ATTRIBUTION_FACT {
        string attribution_pk PK
        string campaign_fk FK
        string product_fk FK
        string address_fk FK
        string first_touch_channel
        date acquisition_date
        int customers_acquired
        float first_month_ltv
        timestamp dbt_updated_at
    }
    ON_TIME_DELIVERY_FACT {
        string on_time_delivery_pk PK
        string address_fk FK
        date ship_month
        string carrier
        string service_level
        int shipments
        int on_time_count
        float on_time_rate
        float avg_delivery_days
        timestamp dbt_updated_at
    }

    CUSTOMER_DIM }o--|| ADDRESS_DIM : "address_fk"
    SUBSCRIPTION_DIM }o--|| CUSTOMER_DIM : "customer_fk"
    SUBSCRIPTION_DIM }o--|| PRODUCT_DIM : "product_fk"
    SUBSCRIPTION_DIM }o--o| CANCELLATION_REASON_DIM : "cancellation_reason_fk"
    CANCELLATION_REASON_DIM }o--o| CANCELLATION_REASON_DIM : "parent_reason_fk"
    ORDER_LINE_FACT }o--o| CUSTOMER_DIM : "customer_fk"
    ORDER_LINE_FACT }o--|| PRODUCT_DIM : "product_fk"
    ORDER_LINE_FACT }o--|| ADDRESS_DIM : "address_fk"
    SUBSCRIPTION_EVENT_FACT }o--|| SUBSCRIPTION_DIM : "subscription_fk"
    SUBSCRIPTION_EVENT_FACT }o--|| CUSTOMER_DIM : "customer_fk"
    PAYMENT_FACT }o--|| CUSTOMER_DIM : "customer_fk"
    INVOICE_FACT }o--|| CUSTOMER_DIM : "customer_fk"
    INVOICE_FACT }o--|| SUBSCRIPTION_DIM : "subscription_fk"
    MARKETING_EVENT_FACT }o--o| CUSTOMER_DIM : "customer_fk"
    MARKETING_EVENT_FACT }o--o| CAMPAIGN_DIM : "campaign_fk"
    MARKETING_EVENT_FACT }o--o| WEB_SESSION_FACT : "web_session_fk"
    WEB_SESSION_FACT }o--o| CUSTOMER_DIM : "customer_fk"
    SHIPMENT_FACT }o--|| CUSTOMER_DIM : "customer_fk"
    SHIPMENT_FACT }o--|| ADDRESS_DIM : "address_fk"
    TRACKING_EVENT_FACT }o--|| SHIPMENT_FACT : "shipment_fk"
    MRR_FACT }o--|| ADDRESS_DIM : "address_fk"
    CHURN_FACT }o--|| CANCELLATION_REASON_DIM : "cancellation_reason_fk"
    LTV_FACT }o--|| ADDRESS_DIM : "address_fk"
    ATTRIBUTION_FACT }o--o| CAMPAIGN_DIM : "campaign_fk"
    ATTRIBUTION_FACT }o--|| PRODUCT_DIM : "product_fk"
    ATTRIBUTION_FACT }o--|| ADDRESS_DIM : "address_fk"
    ON_TIME_DELIVERY_FACT }o--|| ADDRESS_DIM : "address_fk"
```

ERD: 20 entities, 27 relationships. Every relationship line corresponds to a
foreign key defined in Section 4. `cohort_retention_fact` has no foreign key (its
cohort month and period number are degenerate dates) and so has no relationship
line.

---

## 8. dbt Test Coverage Plan

Every model carries `not_null` and `unique` on its primary key. Warehouse facts
and dimensions add `relationships` tests on every foreign key, plus the custom
tests below for the named data quality rules (NFR-2, each of DQ-1 to DQ-4 has a
test).

| Model | PK test | FK relationship tests | Custom / column tests |
|-------|---------|-----------------------|-----------------------|
| stg_shopify__customers | not_null, unique (customer_pk) | — | not_null(shopify_customer_id) |
| stg_shopify__orders | not_null, unique (order_pk) | — | — |
| stg_shopify__order_lines | not_null, unique (order_line_pk) | — | not_null(shopify_order_id) |
| stg_shopify__products | not_null, unique (product_pk) | — | — |
| stg_shopify__subscriptions | not_null, unique (shopify_subscription_pk) | — | not_null(shopify_customer_id) |
| stg_stripe__customers | not_null, unique (stripe_customer_pk) | — | — |
| stg_stripe__charges | not_null, unique (payment_pk) | — | — |
| stg_stripe__subscriptions | not_null, unique (stripe_subscription_pk) | — | — |
| stg_stripe__invoices | not_null, unique (invoice_pk) | — | — |
| stg_klaviyo__events | not_null, unique (klaviyo_event_pk) | — | — |
| stg_klaviyo__campaigns | not_null, unique (klaviyo_campaign_pk) | — | — |
| stg_klaviyo__flows | not_null, unique (klaviyo_flow_pk) | — | — |
| stg_shipstation__shipments | not_null, unique (shipment_pk) | — | unique(tracking_number) — proves DQ-3 dedupe |
| stg_shipstation__tracking_events | not_null, unique (tracking_event_pk) | — | not_null(shipstation_shipment_id) |
| stg_ga4__sessions | not_null, unique (web_session_pk) | — | — |
| stg_ga4__events | not_null, unique (ga4_event_pk) | — | not_null(ga4_session_id) |
| int_customers__identity__resolved | not_null, unique (customer_pk) | — | DQ-1: measure unresolved rate; expect ≤ documented threshold |
| int_subscriptions__retention__monthly | not_null, unique (monthly_retention_pk) | relationships(subscription_pk) | accepted_values(retention_type) |
| wh_customers__customer_dim | not_null, unique (customer_pk) | relationships(address_fk) | — |
| wh_customers__address_dim | not_null, unique (address_pk) | — | accepted_values(country_code) |
| wh_orders__product_dim | not_null, unique (product_pk) | — | — |
| wh_subscriptions__subscription_dim | not_null, unique (subscription_pk) | relationships(customer_fk, product_fk, cancellation_reason_fk) | — |
| wh_subscriptions__cancellation_reason_dim | not_null, unique (cancellation_reason_pk) | relationships(parent_reason_fk) | — |
| wh_marketing__campaign_dim | not_null, unique (campaign_pk) | — | — |
| wh_orders__order_line_fact | not_null, unique (order_line_pk) | relationships(customer_fk, product_fk, address_fk) | — |
| wh_subscriptions__subscription_event_fact | not_null, unique (subscription_event_pk) | relationships(subscription_fk, customer_fk) | accepted_values(event_type) |
| wh_payments__payment_fact | not_null, unique (payment_pk) | relationships(customer_fk) | — |
| wh_payments__invoice_fact | not_null, unique (invoice_pk) | relationships(customer_fk, subscription_fk) | — |
| wh_marketing__marketing_event_fact | not_null, unique (marketing_event_pk) | relationships(customer_fk, campaign_fk, web_session_fk) | DQ-2: count NULL customer_fk; expect ~12% pre-2024 |
| wh_marketing__web_session_fact | not_null, unique (web_session_pk) | relationships(customer_fk) | DQ-4: no duplicate ga4_session_id after lookback |
| wh_fulfilment__shipment_fact | not_null, unique (shipment_pk) | relationships(customer_fk, address_fk) | — |
| wh_fulfilment__tracking_event_fact | not_null, unique (tracking_event_pk) | relationships(shipment_fk) | — |
| wh_subscriptions__mrr_fact | not_null, unique (mrr_pk) | relationships(address_fk) | net_mrr ≤ committed_mrr |
| wh_subscriptions__churn_fact | not_null, unique (churn_pk) | relationships(cancellation_reason_fk) | churn_rate between 0 and 1 |
| wh_subscriptions__cohort_retention_fact | not_null, unique (cohort_retention_pk) | — | retention_rate between 0 and 1 |
| wh_subscriptions__ltv_fact | not_null, unique (ltv_pk) | relationships(address_fk) | — |
| wh_marketing__attribution_fact | not_null, unique (attribution_pk) | relationships(campaign_fk, product_fk, address_fk) | — |
| wh_fulfilment__on_time_delivery_fact | not_null, unique (on_time_delivery_pk) | relationships(address_fk) | on_time_rate between 0 and 1 |

---

## 9. Data Gaps and Design Decisions

Gaps that do not block this design but must be resolved before the affected
models are trusted. They are flagged here, not skipped.

| # | Gap | Models affected | Evidence | Link |
|---|-----|-----------------|----------|------|
| G1 | No street-address source | wh_customers__address_dim | DDL has only `shopify_customers.country_code` and `shopify_orders.market` | conceptual_model.md §5 (Address sourcing); OQ-7 (market scope, closed) |
| G2 | No charge-to-invoice key | int_payments__charge__invoice, wh_subscriptions__mrr_fact | `stripe_charges` and `stripe_invoices` share no key | conceptual_model.md §5 (charge-to-invoice reconciliation) |
| G3 | GA4-to-Stripe identity unresolved; user_id NULL pre-2024 | wh_marketing__web_session_fact, wh_marketing__marketing_event_fact, wh_marketing__attribution_fact | `ga4_sessions.user_id` NULL ~12% pre-2024 | OQ-4, DQ-2 |
| G4 | No single campaign key across Klaviyo and GA4 | wh_marketing__campaign_dim, wh_marketing__attribution_fact | `ga4_sessions.campaign` is free text | conceptual_model.md §5 (campaign reconciliation); OQ-8 |
| G5 | Cancellation taxonomy proposed, not confirmed | wh_subscriptions__cancellation_reason_dim, wh_subscriptions__churn_fact | Shopify 8, Stripe 4, CS 14 reasons | OQ-3, FR-9 (build-blocker) |
| G6 | Subscription state precedence unresolved | int_subscriptions__state__reconciled, wh_subscriptions__subscription_dim | Shopify and Stripe disagree on ~3% | OQ-2, FR-4 |
| G7 | No ad-spend / cost source | wh_marketing__attribution_fact (CAC) | None of the five sources carries marketing spend | New — flagged by this spec |
| G8 | Pause vs churn treatment undecided | int_subscriptions__retention__monthly, wh_subscriptions__churn_fact | — | OQ-9 |
| G9 | Guest-order revenue treatment | wh_orders__order_line_fact | Guest orders carry email, NULL customer | OQ-1 |
| G10 | B2B / wholesale segmentation | wh_customers__customer_dim, wh_subscriptions__subscription_dim | No account entity in v1 | OQ-5 |

**G7 is the one new gap this spec surfaces.** The Marketing dashboard and FR-11
call for CAC by channel. CAC needs marketing spend as its numerator. None of the
five in-scope sources (Shopify, Stripe, Klaviyo, Shipstation, GA4) carries
ad-spend or cost data. `wh_marketing__attribution_fact` can produce customers
acquired and first-month LTV by channel, but CAC cannot be computed from the
in-scope sources. A spend feed (for example Meta Ads, Google Ads) is needed, or
CAC must be dropped from v1. This needs a decision before the Marketing dashboard
is built.

---

## 10. Canonical Registry Adaptation and Grain Decisions

Taken as `adapt` on the confident `subscription-commerce` match, with
cross-vertical patterns used loosely. What was kept, dropped, renamed, and
re-grained:

**Kept (entity shape and technique):**
- `subscriber` → `wh_customers__customer_dim` (via `int_customers__identity__resolved`): multi-source union, email dedupe, explicit source-of-record priority, PII tagging.
- `subscription` → `wh_subscriptions__subscription_dim` (via `int_subscriptions__state__reconciled`): the multi-platform union-and-reconcile pattern, reused for Shopify/Stripe reconciliation.
- `subscription_event` → `wh_subscriptions__subscription_event_fact`: typed events derived from timestamps, not a free-text type field.
- `monthly_retention` → `int_subscriptions__retention__monthly`: three-CTE timeline, window classification, look-ahead-gated churn synthesis, config-driven thresholds.
- `subscription_revenue` → `wh_subscriptions__mrr_fact`: cadence-to-monthly amortization.

**Dropped:**
- The `subscription` entity's migration-safe `retention_subscription_natural_key` and recursive migration chain — Acme has no billing-platform migration (one Shopify app plus Stripe), so the key is not needed.
- The `subscription_event` entity's richer attributes (before/after values, dunning, winback, competitor fields) — Acme's sources carry only status plus started/paused/cancelled timestamps.
- `fct_customer_rfm_segmentation` (RFM mart) — not required by the dashboards.
- The `fulfillment_and_delivery` schema's three-level delivery/line/component grain — Acme's Shipstation fulfilment is shipment plus tracking scan only.

**Renamed** to Acme's `wh_<group>__<entity>_<fact|dim>` convention: `dim_subscriber` → `wh_customers__customer_dim`; `fct_subscription_version` → `wh_subscriptions__subscription_event_fact`; and so on. Pipeline-architecture integration names given the three-segment form (Section 3).

**Grain decisions where the registry and the approved design differ:**

| Area | Registry grain | Taken grain | Why |
|------|----------------|-------------|-----|
| Subscription (DM-3) | One row per `subscription_natural_key`, with a migration-safe retention key | One row per reconciled Shopify/Stripe subscription | No billing-platform migration at Acme; the cross-system reconciliation (OQ-2) is the equivalent concern |
| Retention (DM-1) | One `fct_monthly_subscription_retention` at (subscription, month, order) grain | Shared `int_subscriptions__retention__monthly` at (subscription, month) grain, feeding separate churn, cohort, MRR, and LTV marts | The approved pipeline design splits churn and cohort into separate marts and the dashboards need them separate; the shared integration model computes the classification once rather than four times. Added model, flagged |
| Address (DM-2) | n/a (registry `subscriber` carries postal address as PII attributes) | `wh_customers__address_dim` at country/market grain | No street-address source (G1); built at the grain the data supports; doubles as the conformed market dimension |
| MRR (DM-4) | One row per (subscription, month), committed revenue only | `wh_subscriptions__mrr_fact` at (month, market), net of refunds on a rolling 30-day window | Acme's MRR definition nets refunds (FR-5, OQ-6), beyond the registry entity's committed-only scope |
| Fulfilment (DM-5) | Three-level delivery / line / component | `wh_fulfilment__shipment_fact` (shipment) and `wh_fulfilment__tracking_event_fact` (scan) | Shipstation source has shipment and tracking only, no line/component structure |

---

## Reference key

Codes used in this document that are defined in other artifacts.

| Code | Meaning | Defined in |
|------|---------|------------|
| FR-1 | Ingest five source systems into BigQuery | requirements/requirements_specification.md |
| FR-2 | Customer and address integration with identity resolution | requirements/requirements_specification.md |
| FR-3 | Orders and product model | requirements/requirements_specification.md |
| FR-4 | Subscription event model and state reconciliation | requirements/requirements_specification.md |
| FR-5 | Subscription retention metrics marts | requirements/requirements_specification.md |
| FR-6 | Payments and refund reconciliation | requirements/requirements_specification.md |
| FR-7 | Marketing event model and attribution mart | requirements/requirements_specification.md |
| FR-8 | Fulfilment model and on-time-delivery mart | requirements/requirements_specification.md |
| FR-9 | Canonical cancellation reason taxonomy | requirements/requirements_specification.md |
| FR-11 | Subscriptions, Marketing, and Fulfilment dashboards | requirements/requirements_specification.md |
| FR-12 | Looker semantic layer for self-service | requirements/requirements_specification.md |
| NFR-1 | Refresh cadence and operational SLA | requirements/requirements_specification.md |
| NFR-2 | Data quality and test coverage | requirements/requirements_specification.md |
| NFR-3 | Access and security | requirements/requirements_specification.md |
| DQ-1 | Stripe/Shopify customer email mismatch (~4%) | requirements/requirements_specification.md |
| DQ-2 | Klaviyo events missing user_id pre-2024 (~12%) | requirements/requirements_specification.md |
| DQ-3 | Shipstation duplicate shipment records (~0.5%) | requirements/requirements_specification.md |
| DQ-4 | GA4 out-of-order timestamps | requirements/requirements_specification.md |
| OQ-1 | Guest checkouts in scope for revenue reporting | requirements/requirements_specification.md (from SOW) |
| OQ-2 | Subscription state-machine precedence (Shopify vs Stripe) | requirements/requirements_specification.md (from SOW) |
| OQ-3 | Cancellation reason taxonomy: one canonical list (build-blocker) | requirements/requirements_specification.md (from SOW) |
| OQ-4 | GA4-to-Stripe identity resolution join key | requirements/requirements_specification.md (from SOW) |
| OQ-5 | Treatment of wholesale (B2B) orders | requirements/requirements_specification.md (from SOW) |
| OQ-6 | Refund treatment in MRR (net on rolling 30-day window) | requirements/requirements_specification.md (from SOW) |
| OQ-7 | Market scope for v1 (closed) | requirements/requirements_specification.md (from SOW) |
| OQ-8 | Klaviyo event taxonomy: keep all or consolidate | requirements/requirements_specification.md (from SOW) |
| OQ-9 | Subscription pause vs cancel: same churn or different | requirements/requirements_specification.md (from SOW) |
| PD-1 | Production ingestion tool | design/pipeline_architecture.md |
| PD-3 | GA4 late-arrival reprocessing window | design/pipeline_architecture.md |

The `DM-<n>` codes (DM-1 to DM-5) are design decisions minted in this document
(Sections 3 and 9) and so are not listed here. `conceptual_model.md §5` refers to
the Open Questions section of the conceptual model, whose local numbering differs
from the SOW OQ numbers.
