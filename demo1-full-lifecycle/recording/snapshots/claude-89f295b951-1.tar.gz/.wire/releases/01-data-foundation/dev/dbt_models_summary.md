# dbt Models Summary

**Generated**: 2026-10-06
**Project**: Acme Coffee Roasters, 01-data-foundation
**Scope of this run**: staging layer only, Shopify source only
**Conventions**: Wire embedded conventions (no project convention file found)
**Target**: DuckDB (profile `acme`). Casts use DuckDB types.

## Models Created

### Staging Layer

| Model | Grain | Input | Primary key |
|-------|-------|-------|-------------|
| `stg_shopify__customers` | One row per Shopify customer | seed `shopify_customers` | `customer_pk` |
| `stg_shopify__orders` | One row per Shopify order | seed `shopify_orders` | `order_pk` |

Files in `dbt/models/staging/shopify/`:

- `stg_shopify__customers.sql`
- `stg_shopify__orders.sql`
- `stg_shopify.yml` (model and column docs, tests)

Both models read the seeds with `ref()` instead of `source()`, because the
demo source data is loaded as dbt seeds.

### Integration Layer

Not generated in this run.

### Warehouse Layer

Not generated in this run.

## Differences from data_model_specification.md

| Item | Specification | Generated | Reason |
|------|---------------|-----------|--------|
| Business keys | `shopify_customer_id`, `shopify_order_id` | `shopify_customer_natural_key`, `shopify_order_natural_key` | Wire natural-key naming |
| Timestamps | `created_at`, `updated_at`, `ordered_at` | `customer_created_ts`, `customer_updated_ts`, `order_placed_ts`, `order_updated_ts` | Wire `_ts` naming |
| Order total | `total_price` (float) | `order_total_amount` (DOUBLE) | Wire `_amount` naming; DuckDB type |
| Common fields | `email`, `first_name`, `country_code`, `currency`, ... | prefixed with `customer_` or `order_` | Wire `<entity>_<field>` naming |
| Customer link on orders | not specified | `customer_fk` added | Wire `_fk` naming; null for guest orders |
| `fulfillment_status` | in specification | left out | Column is not in the `shopify_orders` seed |

Integration models written later must use the generated names above.

## Testing Strategy

| Test type | Count | Columns |
|-----------|-------|---------|
| unique | 4 | `customer_pk`, `shopify_customer_natural_key`, `order_pk`, `shopify_order_natural_key` |
| not_null | 6 | the 4 above, `has_marketing_consent`, `is_guest_order` |
| relationships | 1 | `stg_shopify__orders.customer_fk` to `stg_shopify__customers.customer_pk` |
| **Total** | **11** | |

Nullable columns have no `not_null` test.

## Next Steps

1. Install packages and build: `dbt deps && dbt build` (or `/wire:utils-run-dbt releases/01-data-foundation`)
2. Validate models: `/wire:dbt-validate releases/01-data-foundation`
3. Generate the integration and warehouse layers
4. Review with team: `/wire:dbt-review releases/01-data-foundation`
