# Requirements Specification: Acme Data Platform, Foundation Build

**Client**: Acme Coffee Roasters Ltd
**Project ID**: 20260531 (release 01-data-foundation)
**Release type**: full_platform
**Date**: 2026-10-06
**Version**: 1.0

## Source references

Every requirement below carries a source tag. The tags resolve as follows.

| Tag | Source | Path |
|-----|--------|------|
| SOW §n | Statement of Work, section n | `.wire/engagement/sow.md` |
| call 01 hh:mm | Kick-off, 20 Jan 2026 | `.wire/engagement/calls/01_kickoff_20260120.txt` |
| call 02 hh:mm | Current-state deep dive, 27 Jan 2026 | `.wire/engagement/calls/02_current_state_20260127.txt` |
| call 03 hh:mm | BI workshop, 3 Feb 2026 | `.wire/engagement/calls/03_bi_workshop_20260203.txt` |
| stakeholders | Stakeholder register | `.wire/engagement/org/stakeholders.md` |
| context | Engagement context | `.wire/engagement/context.md` |

## 0. Goal Hierarchy

This hierarchy was inferred from the SOW, not from a captured brief. No `brief.md` exists and `goal_hierarchy_captured` is not set. Confirm it at requirements review before design starts.

All five SOW objectives (SOW §2) map to in-scope deliverables in SOW §3, so all five are tagged Primary.

| Goal | Priority | Scope in this engagement |
|------|----------|--------------------------|
| G1: Unified analytics warehouse covering Shopify, Stripe, Klaviyo, Shipstation, GA4 | Primary | Full requirements, design, and delivery |
| G2: Subscription metrics the board can trust (MRR, gross and net churn, cohort retention, LTV) | Primary | Full requirements, design, and delivery |
| G3: Marketing attribution joining Klaviyo and GA4 events to Stripe revenue | Primary | Full requirements, design, and delivery |
| G4: Daily-refreshed executive dashboard for the CEO and head of finance | Primary | Full requirements, design, and delivery |
| G5: Looker semantic layer for marketing self-service | Primary | Full requirements, design, and delivery |

**Primary analytical focus**: trusted subscription retention metrics (MRR, churn, cohort retention) for the board. Subscription retention is the single biggest driver of revenue (SOW §1), and the current Shopify/Stripe split makes cohort and churn analysis unreliable. This focus should be confirmed at review.

## 1. Executive Summary

Acme Coffee Roasters is a direct-to-consumer subscription coffee business based in Hove. It has grown from £400k revenue in 2019 to £8M annual recurring revenue in 2025, across three product lines (subscriptions, gift boxes, wholesale) and four markets (UK, Ireland, France, Germany) (SOW §1). Data sits in five source systems with no central reporting. Decisions come from platform-native dashboards, weekly CSV exports, and judgement (SOW §1).

This release builds a unified BigQuery warehouse, Wire 3-layer dbt models, a Looker semantic layer, and four dashboards, so the board can trust subscription retention and revenue figures (context). The headline problem is that Stripe and Shopify disagree on active subscription counts by a couple of hundred on any given day, which makes churn and cohort analysis unreliable (call 01 10:03).

The build runs 12 weeks, 27 January 2026 to 17 April 2026 (SOW §9). Two open questions block the build and must close before code: OQ-3 (cancellation reason taxonomy) and OQ-7 (market scope) (SOW §5, call 01 10:16). OQ-7 closed in the BI workshop. OQ-3 has a proposed taxonomy but is not yet confirmed by its owning stakeholder, so it remains a build-blocker (see Section 11.7).

## 2. Business Context

### 2.1 Background

Acme runs orders and customers through Shopify, with a custom subscription app built on Shopify's Subscriptions API. Payments run through Stripe. Stripe is the system of record for money; Shopify is the system of record for orders and customers (call 02 14:02). Marketing events sit in Klaviyo and GA4. Fulfilment sits in Shipstation. All five sources land in a BigQuery `raw_` schema through Fivetran, with no transformation layer; each team queries the raw schema and writes its own SQL (call 02 14:10).

Acme has had three BI tools in three years. Each was abandoned because nobody could maintain it (call 01 10:10). The engineering lead's main concern is the cost of keeping the platform running after handover, not the build itself (call 01 10:10, stakeholders).

### 2.2 Business Problem

The board wants weekly numbers it can trust and cannot get them today (call 01 10:03). Two reporting gaps drive this:

1. Subscription counts disagree between Stripe and Shopify by a couple of hundred on any given day. The largest source of mismatch is paused subscriptions and free-trial conversions: Shopify treats a pause as active, Stripe does not (call 01 10:06).
2. Marketing attribution cannot be done reliably. Klaviyo opens and clicks, GA4 sessions, and Stripe revenue cannot be joined in any dependable way (call 01 10:08).

### 2.3 Strategic Goals

The five SOW objectives (SOW §2), all Primary, are listed in Section 0.

### 2.4 Success Criteria

The engagement is judged against the five SOW acceptance criteria (SOW §8):

| # | Acceptance criterion | Source |
|---|----------------------|--------|
| AC-1 | Every named dashboard renders with non-empty data on the bundled seed dataset | SOW §8.1 |
| AC-2 | dbt builds green on the full pipeline (`dbt build`, zero failures) | SOW §8.2 |
| AC-3 | Wire's `dbt-validate` produces a PASS report against the warehouse models | SOW §8.3 |
| AC-4 | Semantic layer LookML compiles syntactically (validated by the demo's LookML check) | SOW §8.4 |
| AC-5 | The marketing team can answer five named questions from the Looker explores without engineering help | SOW §8.5 |

The CEO will judge the project on the executive dashboard, which is the contractual exit deliverable (stakeholders).

## 3. Stakeholders

Combined from SOW §7 and the stakeholder register (stakeholders).

| Name | Role | Org | Domain | Priority | Notes |
|------|------|-----|--------|----------|-------|
| Becky Hartmann | Head of Data (sponsor) | Acme | All | P0 | Actively advocating; owns OQ-3 and OQ-7 resolution |
| Steph Owens | Senior Analyst | Acme | Subscriptions, Orders | P1 | Owns full LTV by cohort; cautious after a prior abandoned BI project |
| Cathy Marsh | Customer Success Lead | Acme | Subscriptions, churn taxonomy | P1 | Confirming owner for the cancellation taxonomy (OQ-3) |
| Jordan Park | Head of Marketing | Acme | Marketing, attribution | P1 | Owns marketing self-serve requirements |
| Priya Sharma | Engineering Lead | Acme | Pipelines, infra | P1 | Runs the platform in production; concerned about maintenance burden |
| Tom Vickers | Finance Director | Acme | Revenue, MRR | P2 | Needs net MRR clarity |
| Anya Petrov | Ops Coordinator | Acme | Fulfilment, Shipstation | P2 | Fulfilment reporting |
| David Wu | CEO | Acme | Exec dashboard | P0 (steering) | Wants a weekly view; trusts Becky on tooling |
| Mark Rittman | Engagement Lead | RA | All | n/a | RA delivery lead |
| Lydia Blackley | Head of Delivery | RA | All | n/a | Discovery sprint calendar and sessions |
| Lewis Baker | CRO / commercial | RA | Commercial | n/a | Commercial owner |

## 4. Functional Requirements

Each requirement is tagged with its parent goal priority. All are Primary (Section 0).

### FR-1: Ingest five source systems into BigQuery
**Goal**: G1. **Priority**: High.
**Description**: Land Shopify, Stripe, Klaviyo, Shipstation, and GA4 into BigQuery. For the demo, ingestion is Fivetran-equivalent via dbt seeds; in production it is Cloud Functions (SOW §3). Today all five land in a `raw_` schema through Fivetran (call 02 14:10).
**Source**: SOW §2.1, SOW §3, call 02 14:10.
**Acceptance criteria**:
- [ ] All five sources present in BigQuery with the domains listed in SOW §3.
- [ ] Historical data loaded from the 2024-01-01 cutoff agreed in OQ-11 (Section 11.6).

### FR-2: Customer and address integration with identity resolution
**Goal**: G1. **Priority**: High.
**Description**: Build `dim_customer` and `dim_address` from Shopify and Stripe (SOW §3). Link Stripe and Shopify customers on email at signup; Stripe's customer object carries the Shopify customer ID in metadata for records created from 2023 onward (call 02 14:04). Pre-2023 records without the metadata link need manual re-linking (see DQ-1, Section 6.2).
**Source**: SOW §3 (Customers), call 02 14:04.
**Acceptance criteria**:
- [ ] `dim_customer` resolves Shopify and Stripe identities with a documented join key.
- [ ] The DQ-1 mismatch rate (~4%) is measured and the ~800 pre-2023 records are handled by a documented rule.

### FR-3: Orders and product model
**Goal**: G1. **Priority**: High.
**Description**: Build `fct_order_line` and `dim_product` from Shopify, the system of record for orders (SOW §3, call 02 14:02).
**Source**: SOW §3 (Orders).
**Acceptance criteria**:
- [ ] `fct_order_line` and `dim_product` build and reconcile to Shopify order counts.

### FR-4: Subscription event model and state reconciliation
**Goal**: G2. **Priority**: High.
**Description**: Build `fct_subscription_event` and `dim_subscription` from Stripe and Shopify (SOW §3). Reconcile the two subscription state machines, which disagree on about 3% of subscriptions, concentrated on paused subscriptions and free-trial conversions (SOW §5 OQ-2, call 01 10:06). The precedence rule (which system wins) is not yet agreed (OQ-2, Section 11.7).
**Source**: SOW §3 (Subscriptions), SOW §5 OQ-2, call 01 10:06.
**Acceptance criteria**:
- [ ] `fct_subscription_event` and `dim_subscription` build.
- [ ] A documented precedence rule resolves the Shopify/Stripe state disagreement (pending OQ-2).

### FR-5: Subscription retention metrics marts
**Goal**: G2. **Priority**: High.
**Description**: Build the MRR and churn marts the board can trust: MRR, gross and net churn, cohort retention, and LTV (SOW §2.2, SOW §3). MRR is net: refunds are netted on a rolling 30-day window (call 03 10:08, OQ-6). Full LTV by cohort is owned by Steph and lands on the Subscriptions dashboard, not the Marketing one (call 03 10:12). This is the primary analytical focus (Section 0).
**Source**: SOW §2.2, SOW §3, call 03 10:08, call 03 10:12.
**Acceptance criteria**:
- [ ] MRR mart applies net refund treatment on a rolling 30-day window.
- [ ] Gross churn, net churn, cohort retention, and LTV are each produced with a stated definition.
- [ ] Full LTV by cohort is available on the Subscriptions dashboard.

### FR-6: Payments and refund reconciliation
**Goal**: G1. **Priority**: High.
**Description**: Build `fct_payment` and refund reconciliation from Stripe, the system of record for money (SOW §3, call 02 14:02).
**Source**: SOW §3 (Payments).
**Acceptance criteria**:
- [ ] `fct_payment` builds and refund reconciliation ties out to Stripe totals.

### FR-7: Marketing event model and attribution mart
**Goal**: G3. **Priority**: High.
**Description**: Build `fct_marketing_event` and an attribution mart joining Klaviyo and GA4 events to Stripe revenue (SOW §2.3, SOW §3). The Klaviyo join is clean: every Shopify customer is pushed to Klaviyo with the Shopify ID as the external ID (call 02 14:08). The GA4-to-Stripe join key is not yet agreed; GA4 captured `user_id` only from 2024 (OQ-4, DQ-2, call 02 14:08).
**Source**: SOW §2.3, SOW §3 (Marketing), call 02 14:08.
**Acceptance criteria**:
- [ ] `fct_marketing_event` builds from Klaviyo and GA4.
- [ ] Attribution mart joins marketing events to Stripe revenue using a documented identity-resolution key (pending OQ-4).

### FR-8: Fulfilment model and on-time-delivery mart
**Goal**: G1. **Priority**: Medium.
**Description**: Build `fct_shipment` and an on-time-delivery mart from Shipstation (SOW §3). Apply the DQ-3 deduplication rule: where the same `tracking_number` appears with different `created_at`, keep the earliest `created_at` (call 02 14:20).
**Source**: SOW §3 (Fulfilment), call 02 14:20.
**Acceptance criteria**:
- [ ] `fct_shipment` builds with the DQ-3 dedupe rule applied in the staging model.
- [ ] On-time-delivery mart produces a delivery metric.

### FR-9: Canonical cancellation reason taxonomy
**Goal**: G2. **Priority**: High (build-blocker).
**Description**: Agree one canonical cancellation reason list before the churn mart is built. Shopify has 8 reasons, Stripe has 4, and Acme's CS team uses 14 (SOW §5 OQ-3). The proposed structure is three top-level reasons (price, delivery, consumption) with the 14 CS reasons as sub-tags (call 01 10:18, call 02 14:22). This is proposed, not agreed: the confirming owner (Cathy) relayed support through Steph but has not confirmed it directly (Section 11.7).
**Source**: SOW §5 OQ-3, call 01 10:18, call 02 14:22.
**Acceptance criteria**:
- [ ] A single canonical cancellation taxonomy is confirmed by Cathy before the churn mart is built.
- [ ] The taxonomy maps all three source lists (Shopify 8, Stripe 4, CS 14) to the canonical reasons.

### FR-10: Executive dashboard
**Goal**: G4. **Priority**: High.
**Description**: A single-page executive dashboard for the CEO and head of finance (SOW §2.4). Four KPIs: MRR, net new customers this week, churn rate, and CAC. Four charts: MRR over time, new vs returning revenue split, channel mix, and a top-5 products table (call 03 10:04). The default time range is the last 13 weeks and is changeable by the user (call 03 10:06). The dashboard refreshes daily (SOW §2.4).
**Source**: SOW §2.4, call 03 10:04, call 03 10:06.
**Acceptance criteria**:
- [ ] One page with four KPIs and four visuals as listed.
- [ ] Default range last 13 weeks, user-changeable.
- [ ] Refreshes daily.

### FR-11: Subscriptions, Marketing, and Fulfilment dashboards
**Goal**: G2, G3. **Priority**: High.
**Description**: Three further dashboards beyond the executive one, for four dashboards in total (SOW §3, call 03 10:14). The Subscriptions dashboard carries full LTV by cohort (call 03 10:13). The Marketing dashboard carries channel breakdown by spend, customers acquired, CAC, and first-month LTV (call 03 10:10). The Fulfilment dashboard carries on-time-delivery reporting (SOW §3).
**Source**: SOW §3, call 03 10:10, call 03 10:13, call 03 10:14.
**Acceptance criteria**:
- [ ] Subscriptions, Marketing, and Fulfilment dashboards each render with non-empty data.
- [ ] Marketing dashboard shows spend, customers acquired, CAC, and first-month LTV by channel.

### FR-12: Looker semantic layer for self-service
**Goal**: G5. **Priority**: High.
**Description**: A Looker semantic layer that lets the marketing team self-serve without engineering help (SOW §2.5). Scope: 1 model file, about 20 view files, and 6 explores (SOW §3). The marketing fact must carry five slicing dimensions: campaign, channel, product, market, and date (call 03 10:15). The five named SOW questions are representative; the real requirement is that these five dimensions are present so the questions answer themselves (call 03 10:15).
**Source**: SOW §2.5, SOW §3, call 03 10:15.
**Acceptance criteria**:
- [ ] LookML compiles syntactically (AC-4).
- [ ] The five dimensions (campaign, channel, product, market, date) are present on the marketing fact.
- [ ] The marketing team answers the five named questions without engineering help (AC-5).

### FR-13: Enablement, training and handover
**Goal**: G1. **Priority**: Medium.
**Description**: Two training sessions for the marketing team plus technical handover documentation (SOW §3). Enablement runs from week one; the team is trained on the conventions, not just shown the output (call 01 10:11).
**Source**: SOW §3 (Enablement), call 01 10:11.
**Acceptance criteria**:
- [ ] Two marketing training sessions delivered.
- [ ] Technical handover documentation delivered that lets a reader maintain the dbt models without RA in the loop.

### FR-14: Historical backfill from 2024
**Goal**: G1. **Priority**: Medium.
**Description**: Backfill history from 2024-01-01 across sources (OQ-11). Shopify goes back to 2018 and GA4 only to 2023, but the board cares about 2024 onward (call 02 14:16). This bounds the Shipstation backfill to about 60,000 shipments (OQ-12, call 02 14:18).
**Source**: SOW §5 OQ-11, call 02 14:16.
**Acceptance criteria**:
- [ ] All sources backfilled from 2024-01-01.
- [ ] Shipstation backfill completes within the API rate limit (OQ-12).

## 5. Non-Functional Requirements

### NFR-1: Refresh cadence and operational SLA
**Description**: Daily refresh across all domains for v1. GA4 is ingested hourly at source; the other four sources are daily (call 02 14:10). Cathy wanted hourly refresh for subscription churn; she will accept daily for v1 rather than delay go-live, with hourly churn refresh carried as a v2 option (call 02 14:11, call 02 14:12). The executive dashboard refreshes daily (SOW §2.4).
**Source**: SOW §2.4, call 02 14:10, call 02 14:12.
**Measure**: All marts refresh at least daily; no mart is stale by more than 24 hours.

### NFR-2: Data quality and test coverage
**Description**: The pipeline must build green and pass Wire's checks. Named data quality concerns (DQ-1 to DQ-4, Section 6.2) each have a handling rule covered by a test.
**Source**: SOW §6, SOW §8.2, SOW §8.3.
**Measure**: `dbt build` runs with zero failures (AC-2); `dbt-validate` returns PASS (AC-3); each of DQ-1 to DQ-4 has a test.

### NFR-3: Access and security
**Description**: Source access for the discovery sprint is read-only service accounts for Shopify, Stripe, and Shipstation; Klaviyo and GA4 are read from the BigQuery `raw_` schema (call 02 14:25). Looker licences (OQ-10): edit licences for Becky, Steph, Jordan, and Tom; view licences for the rest of marketing and ops plus David, about 12 view licences; everyone else uses scheduled exports (call 03 10:23).
**Source**: call 02 14:25, call 03 10:23.
**Measure**: Access is read-only where specified; licence allocation matches the OQ-10 decision.

### NFR-4: Maintainability
**Description**: The dbt pattern must be conventional and documented so Acme's engineers can read and maintain the models without RA in the loop (call 01 10:11). This addresses the stated risk that three prior BI tools were abandoned for lack of maintainability (call 01 10:10).
**Source**: call 01 10:10, call 01 10:11, stakeholders.
**Measure**: Handover docs delivered (FR-13); dbt models follow the Wire 3-layer convention.

### NFR-5: Backfill performance and late-arrival handling
**Description**: The Shipstation API is limited to 40 requests per minute (call 02 14:15). With the 2024 cutoff, the backfill is about 60,000 shipments, pulled in chunks over roughly a couple of hours (call 02 14:18). GA4 timestamps can arrive out of order by several hours and need late-arrival handling (DQ-4, SOW §6).
**Source**: call 02 14:15, call 02 14:18, SOW §6.
**Measure**: Shipstation backfill completes within the rate limit; GA4 late-arriving events are handled without double-counting.

## 6. Data Requirements

### 6.1 Data Sources

| Source | Type | Refresh (current) | Volume | Owner |
|--------|------|-------------------|--------|-------|
| Shopify | Orders, customers, subscriptions app | Daily | ~22,000 subscribers | Priya |
| Stripe | Payments, subscriptions (system of record for money) | Daily | Tied to subscriber base | Priya |
| Klaviyo | Marketing events | Daily | 40+ event types | Jordan |
| Shipstation | Fulfilment / shipments | Daily | ~280,000 all-time, ~60,000 from 2024 | Anya / Priya |
| GA4 | Web analytics | Hourly | `user_id` from 2024 only | Jordan |

Source notes: Shopify is the system of record for orders and customers; Stripe for money (call 02 14:02). Shopify customers are pushed to Klaviyo with the Shopify ID as the external ID, so that join is clean (call 02 14:08). All five land in a BigQuery `raw_` schema today with no transformation (call 02 14:10).

### 6.2 Data Quality Requirements

Four named concerns from SOW §6, each with a handling rule.

| ID | Concern | Scale | Handling rule | Source |
|----|---------|-------|---------------|--------|
| DQ-1 | Stripe customer email mismatches Shopify email on joined records | ~4% (~800 pre-2023 customers) | Link on email plus Shopify ID in Stripe metadata from 2023. Re-link ~800 pre-2023 records by a documented rule. Some mismatches are deliberate (staff accounts). | SOW §6, call 02 14:05 |
| DQ-2 | Klaviyo events missing `user_id` for pre-2024 events | ~12% | Pre-identity-resolution events have no join key; treat historical gap explicitly in attribution. Relates to OQ-4. | SOW §6, call 02 14:08 |
| DQ-3 | Shipstation duplicate shipment records (same `tracking_number`, different `created_at`) | ~0.5% (~1,400 records) | Deduplicate on `tracking_number`, keep the earliest `created_at`, in the shipment staging model. Cause is Shipstation retrying on label-provider timeouts. | SOW §6, call 02 14:20 |
| DQ-4 | GA4 timestamps arrive out of order by several hours | Occasional | Late-arrival handling so events are not dropped or double-counted. | SOW §6, call 02 (GA4 ingestion) |

### 6.3 Data Governance

No specific compliance regime is stated in the SOW. Access is read-only where specified (NFR-3). Finance ERP (Xero) data is out of scope (Section 11.2).

## 7. Technical Requirements

### 7.1 Platform

- Warehouse: BigQuery (SOW §3).
- Transformation: Wire 3-layer dbt (staging / integration / warehouse) (SOW §3).
- Semantic layer: Looker, 1 model file, about 20 view files, 6 explores (SOW §3).
- Dashboards: four (SOW §3).

### 7.2 Integrations

- Ingestion: Fivetran-equivalent via dbt seeds for the demo; Cloud Functions in production (SOW §3). Current state is Fivetran into a BigQuery `raw_` schema (call 02 14:10).
- Five sources: Shopify, Stripe, Klaviyo, Shipstation, GA4 (SOW §2.1).

### 7.3 Tools and Technologies

BigQuery, dbt, Looker. Fivetran (current) or Cloud Functions (production) for ingestion. Orchestration runs daily (NFR-1).

## 8. User Requirements

### 8.1 User Personas

| Persona | Who | Need |
|---------|-----|------|
| Executive | David Wu (CEO) | A weekly, single-page view he can trust; judges the project on it |
| Finance | Tom Vickers | Net MRR, refunds netted |
| Marketing | Jordan Park and team | Self-serve CAC and attribution by channel without waiting on engineering |
| Analyst | Steph Owens | Cohort retention, churn, full LTV |
| Customer Success | Cathy Marsh | Churn monitoring; owns the cancellation taxonomy |
| Operations | Anya Petrov | Fulfilment and on-time-delivery reporting |

### 8.2 Use Cases

- The CEO reviews the executive dashboard each Monday (call 03 10:03).
- The marketing team answers the five named questions by slicing the marketing fact on campaign, channel, product, market, and date, without engineering help (call 03 10:15, AC-5).
- Finance reports net MRR to the board (call 03 10:07).
- Customer Success monitors churn against the canonical cancellation taxonomy (FR-9).

## 9. Deliverables

The ID column mints the deliverable codes. These map to the five SOW §3 layer deliverables.

| ID | Deliverable | Description | Acceptance criteria |
|----|-------------|-------------|---------------------|
| D1 | Ingestion pipelines | Fivetran-equivalent ingestion via dbt seeds (demo) or Cloud Functions (production), five sources, backfilled from 2024-01-01 | Sources land in BigQuery; backfill from 2024 (FR-1, FR-14) |
| D2 | BigQuery warehouse (3-layer dbt) | Wire staging / integration / warehouse dbt models for all six domains, with the subscription retention marts | `dbt build` green (AC-2); `dbt-validate` PASS (AC-3); DQ-1 to DQ-4 handled (NFR-2) |
| D3 | Looker semantic layer | 1 model file, about 20 view files, 6 explores, five self-serve dimensions on the marketing fact | LookML compiles (AC-4); five questions answerable (AC-5) |
| D4 | Four dashboards | Exec, Subscriptions, Marketing, Fulfilment | Every dashboard renders non-empty on the seed dataset (AC-1) |
| D5 | Enablement | Two marketing training sessions and technical handover documentation | Sessions delivered; handover docs let Acme maintain the models (FR-13) |

### Deliverable to Wire artifact mapping

| Deliverable | Wire artifacts required |
|-------------|-------------------------|
| D1: Ingestion pipelines | pipeline_design, pipeline, orchestration |
| D2: BigQuery warehouse (3-layer dbt) | conceptual_model, data_model, seed_data, dbt, data_quality |
| D3: Looker semantic layer | semantic_layer |
| D4: Four dashboards | mockups, dashboards |
| D5: Enablement | training, documentation |

## 10. Timeline and Milestones

Duration 12 weeks, 27 January 2026 to 17 April 2026 (SOW §9). Discovery sprint is the first two weeks: week one workshops to agree the entity model, week two the physical data model and high-level pipeline design, with a sign-off pack at the end (call 01 10:14).

| Milestone | Date | Deliverables / event |
|-----------|------|----------------------|
| Signature | 20 Jan 2026 | Invoice 25% (SOW §9) |
| Discovery sprint | 27 Jan – 6 Feb 2026 (weeks 1-2) | Entity model, data model, pipeline design; close build-blockers OQ-3, OQ-7 |
| Exec dashboard mockup | By end of week 3 (~13 Feb 2026) | Non-interactive HTML mockup to David (call 01 10:23, call 03 10:27) |
| Week 4 milestone | ~20 Feb 2026 | Invoice 25% (SOW §9) |
| Build | Weeks 5-9 | Pipelines, dbt models, retention marts, attribution |
| Live exec dashboard | Weeks 8-9 (~20-27 Mar 2026) | Live dashboard on real data to David (call 03 10:27) |
| Week 8 milestone | ~23 Mar 2026 | Invoice 25% (SOW §9) |
| Semantic layer, dashboards, QA, UAT | Weeks 10-11 | Looker, four dashboards, data quality, UAT |
| Final delivery | By 17 Apr 2026 (week 12) | Training, handover, final acceptance; invoice 25% (SOW §9) |

## 11. Scope Management

### 11.1 In Scope

The six data domains and five layer deliverables in SOW §3: Customers, Orders, Subscriptions, Payments, Marketing, Fulfilment; ingestion pipelines, BigQuery warehouse, Looker semantic layer, four dashboards, and enablement.

### 11.2 Out of Scope

From SOW §4:

- Finance ERP (Xero): already covered by the client's existing reporting.
- Web personalisation, A/B testing platforms, and recommendation engines.

### 11.3 Not This Engagement (Future Goals)

| Goal | Why deferred | Suggested future release |
|------|--------------|--------------------------|
| Customer support tickets (Zendesk) | Deferred to a future engagement (SOW §4) | A support-analytics release (full_platform extension), TBD |

### 11.4 Assumptions

| # | Assumption | Source |
|---|------------|--------|
| 1 | Daily refresh is acceptable for v1 across all domains; hourly churn refresh is a v2 option | call 02 14:12 |
| 2 | 2024-01-01 is the backfill cutoff; pre-2024 data is out of scope for v1 | call 02 14:16 |
| 3 | Source access is read-only service accounts (Shopify, Stripe, Shipstation) and `raw_` schema reads (Klaviyo, GA4) | call 02 14:25 |
| 4 | Four markets (UK, Ireland, France, Germany) are modelled on country code; finance gets a UK+Ireland rollup | call 03 10:21 |

### 11.5 Dependencies

| # | Dependency | Owner | Source |
|---|------------|-------|--------|
| 1 | OQ-3 cancellation taxonomy confirmed by Cathy before the churn mart is built | Becky / Cathy | SOW §5, call 01 10:16 |
| 2 | Source-system credentials ready before build | Priya | call 01 10:25, call 02 14:25 |
| 3 | OQ-2 state-machine precedence rule agreed before the subscription model is finalised | Steph / ops | SOW §5 OQ-2 |
| 4 | OQ-4 GA4-to-Stripe join key agreed before the attribution mart is finalised | Marketing / data | SOW §5 OQ-4 |

### 11.6 Open Questions

All 12 open questions from SOW §5. Positions reached in the call transcripts are recorded as agreed only where the transcript shows the owning stakeholder confirming; otherwise they are recorded as proposed.

| ID | Question | Owner | Status | Position reached |
|----|----------|-------|--------|------------------|
| OQ-1 | Are guest checkouts (no customer record) in scope for revenue reporting? | Becky / Mark | Open | Not discussed in calls |
| OQ-2 | Which subscription state machine takes precedence, Shopify or Stripe? (~3% disagree) | Steph / ops | Open | Context only: Stripe is system of record for money, Shopify for orders; mismatch concentrates on pauses and trial conversions (call 02 14:02, call 01 10:06). No precedence rule agreed. |
| OQ-3 | Cancellation reason taxonomy (Shopify 8, Stripe 4, CS 14): one canonical list before the churn mart | Steph / Cathy | Open (blocks build) | Proposed: three top-level reasons (price, delivery, consumption) with 14 CS reasons as sub-tags. Relayed by Steph as acceptable to Cathy, not confirmed by Cathy directly (call 01 10:18, call 02 14:22). See Section 11.7. |
| OQ-4 | GA4 to Stripe identity resolution: canonical join key? | Marketing / data | Open | Klaviyo join is clean (Shopify ID as external ID); GA4 `user_id` only from 2024, 12% historical gap (call 02 14:08). No GA4-to-Stripe key chosen. |
| OQ-5 | How to treat wholesale (B2B) orders in the subscription marts? | Finance / Mark | Open | Flagged as a remaining smaller item (call 03 10:24). Not resolved. |
| OQ-6 | Refund treatment in MRR: net or gross? | Finance | Agreed | Net MRR, refunds netted on a rolling 30-day window. Confirmed by Tom Vickers (call 03 10:08). |
| OQ-7 | Which markets in scope for v1 vs phased? | Becky | Closed (was build-blocker) | Four markets in v1 on country code; finance gets a UK+Ireland rollup. Confirmed by Becky (call 03 10:21). |
| OQ-8 | Klaviyo event taxonomy: keep all 40+ event types or consolidate? | Marketing | Open | Listed as remaining open (call 03 10:24). Not resolved. |
| OQ-9 | Subscription pause vs cancel: same churn or different? | Steph / ops | Open | Linked to refresh frequency and state-change visibility (call 02 14:14). Not resolved. |
| OQ-10 | Looker user licences: who gets edit vs view? | IT / Becky | Agreed | Edit: Becky, Steph, Jordan, Tom. View: rest of marketing and ops plus David (~12). Others use scheduled exports. Confirmed by Becky (call 03 10:23). |
| OQ-11 | Historical backfill: how far back? | Mark / Becky | Agreed | 2024-01-01 cutoff. Confirmed by Steph and Mark (call 02 14:16); Becky to ratify as co-owner. |
| OQ-12 | Shipstation API rate limit on backfill: workable in one pass? | Engineering | Agreed | Workable with the 2024 cutoff: ~60,000 shipments, chunked, roughly a couple of hours. Confirmed by Priya (call 02 14:18). Depends on OQ-11. |

### 11.7 Clarifications Needed

The following conflicts and ambiguities between sources need resolution. The two build-blockers (OQ-3, OQ-7) are called out first.

1. **OQ-3 cancellation taxonomy (build-blocker, not yet closed).** Three source lists disagree: Shopify 8 reasons, Stripe 4, CS 14 (SOW §5). A canonical structure is proposed (three top-level: price, delivery, consumption; 14 sub-tags). The transcript records the engagement lead calling OQ-3 closed, but the confirming owner (Cathy) relayed her support through Steph rather than confirming it directly (call 02 14:22). Treat the taxonomy as proposed. Get Cathy's direct sign-off before the churn mart is built.
2. **OQ-7 market scope (build-blocker, resolved).** Finance treats UK and Ireland as one P&L; marketing treats them as four separate markets (call 03 10:18 to 10:20). Resolved: model on country code with a finance rollup for UK+Ireland. Confirmed by Becky (call 03 10:21).
3. **OQ-2 subscription state-machine precedence.** Shopify treats a paused subscription as active; Stripe does not; they disagree on about 3% of subscriptions (call 01 10:06). Stripe is the system of record for money and Shopify for orders (call 02 14:02), but no rule states which wins for subscription state. This affects active-subscription counts, the headline board number. Needs a precedence rule.
4. **OQ-4 GA4-to-Stripe identity resolution.** No canonical join key is agreed. GA4 `user_id` exists only from 2024, leaving a 12% historical gap (DQ-2). Needs a key before the attribution mart is finalised.
5. **Refresh cadence.** Cathy wanted hourly churn refresh; the team agreed daily for v1 with hourly as a v2 option (call 02 14:11 to 14:13). Recorded as resolved; confirm at review.
6. **MRR definition.** The current Stripe dashboard shows gross MRR; Tom and the board require net (call 03 10:07). Resolved as net on a rolling 30-day window (OQ-6).
7. **LTV scope.** First-month LTV sits on the Marketing dashboard; full LTV by cohort sits on the Subscriptions dashboard and is owned by Steph (call 03 10:12). Resolved; recorded for the design phase.

## 12. Risks and Mitigation

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Platform abandoned after handover for lack of maintainability (three prior BI tools failed this way) | Medium | High | Conventional, documented dbt pattern; enablement from week one; handover docs (NFR-4, FR-13) |
| OQ-3 taxonomy not confirmed before build | Medium | High | Schedule Cathy's direct sign-off in week one; taxonomy is a build-blocker (FR-9) |
| OQ-2 state-machine precedence unresolved | Medium | High | Agree a precedence rule before finalising the subscription model; affects headline active-subscription counts |
| Identity-resolution gaps (DQ-1, DQ-2, OQ-4) weaken attribution and customer joins | Medium | Medium | Documented join keys; re-link ~800 pre-2023 records; treat the 12% GA4 gap explicitly |
| Low stakeholder trust after a prior abandoned BI project | Medium | Medium | Deliver a tangible exec dashboard mockup by week three (call 01 10:22, call 03 10:27) |
| Shipstation backfill rate limit | Low | Low | Bounded by the 2024 cutoff to ~60,000 shipments, chunked pulls (OQ-12, NFR-5) |

## 13. Appendices

### Appendix A: Glossary

- **MRR**: Monthly recurring revenue. Here, net of refunds on a rolling 30-day window.
- **CAC**: Customer acquisition cost.
- **LTV**: Lifetime value. First-month LTV on the Marketing dashboard; full LTV by cohort on the Subscriptions dashboard.
- **Cohort retention**: Retention measured by the period a subscriber joined.
- **System of record**: Stripe for money; Shopify for orders and customers (call 02 14:02).
- **Wire 3-layer**: dbt staging, integration, and warehouse layers.

### Appendix B: References

- Statement of Work: `.wire/engagement/sow.md`
- Kick-off call: `.wire/engagement/calls/01_kickoff_20260120.txt`
- Current-state call: `.wire/engagement/calls/02_current_state_20260127.txt`
- BI workshop call: `.wire/engagement/calls/03_bi_workshop_20260203.txt`
- Stakeholder register: `.wire/engagement/org/stakeholders.md`
- Engagement context: `.wire/engagement/context.md`

## Reference key

Codes used in this document that are defined in other artifacts. The FR-n, NFR-n, and D-n codes are minted in this document (Sections 4, 5, and 9) and are not listed here. The OQ and DQ codes are defined in the SOW.

| Code | Meaning | Defined in |
|------|---------|------------|
| OQ-1 | Guest checkouts in scope for revenue reporting? | `.wire/engagement/sow.md` |
| OQ-2 | Which subscription state machine takes precedence, Shopify or Stripe? | `.wire/engagement/sow.md` |
| OQ-3 | Cancellation reason taxonomy: one canonical list | `.wire/engagement/sow.md` |
| OQ-4 | GA4 to Stripe identity resolution join key | `.wire/engagement/sow.md` |
| OQ-5 | Treatment of wholesale (B2B) orders in subscription marts | `.wire/engagement/sow.md` |
| OQ-6 | Refund treatment in MRR: net or gross | `.wire/engagement/sow.md` |
| OQ-7 | Which markets are in scope for v1 vs phased | `.wire/engagement/sow.md` |
| OQ-8 | Klaviyo event taxonomy: keep all or consolidate | `.wire/engagement/sow.md` |
| OQ-9 | Subscription pause vs cancel: same churn or different | `.wire/engagement/sow.md` |
| OQ-10 | Looker user licences: edit vs view | `.wire/engagement/sow.md` |
| OQ-11 | Historical backfill depth | `.wire/engagement/sow.md` |
| OQ-12 | Shipstation API rate limit on backfill | `.wire/engagement/sow.md` |
| DQ-1 | Stripe/Shopify customer email mismatch (~4%) | `.wire/engagement/sow.md` |
| DQ-2 | Klaviyo events missing user_id pre-2024 (~12%) | `.wire/engagement/sow.md` |
| DQ-3 | Shipstation duplicate shipment records (~0.5%) | `.wire/engagement/sow.md` |
| DQ-4 | GA4 out-of-order timestamps | `.wire/engagement/sow.md` |
