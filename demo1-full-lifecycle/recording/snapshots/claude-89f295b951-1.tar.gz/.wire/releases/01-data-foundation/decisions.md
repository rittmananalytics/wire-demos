# Decisions and Discoveries — 01-data-foundation

Append-only log of decisions reached and notable discoveries during this release.

## 2026-10-06 — Requirements synthesis (discovery-analyst)

Source: SOW and call transcripts 01-03. Recorded during requirements_specification.md generation.

Agreed in calls (owning stakeholder confirmed directly in the transcript):
- OQ-6 (refund treatment): MRR is net, refunds netted on a rolling 30-day window. Confirmed by Tom Vickers (call 03 10:08).
- OQ-7 (market scope, build-blocker): four markets in v1 (UK, IE, FR, DE) modelled on country code; finance gets a UK+IE rollup. Confirmed by Becky Hartmann (call 03 10:21).
- OQ-10 (Looker licences): edit for Becky, Steph, Jordan, Tom; ~12 view licences (rest of marketing/ops plus David); others use scheduled exports. Confirmed by Becky (call 03 10:23).
- OQ-11 (backfill depth): 2024-01-01 cutoff. Confirmed by Steph and Mark (call 02 14:16); Becky to ratify as co-owner.
- OQ-12 (Shipstation rate limit): workable with the 2024 cutoff (~60k shipments, chunked, ~2 hours). Confirmed by Priya (call 02 14:18).
- Refresh cadence: daily across all domains for v1; hourly churn refresh deferred to v2. Cathy accepts daily for v1 (relayed by Steph, call 02 14:12).
- DQ-3 dedupe rule: dedupe Shipstation shipments on tracking_number, keep earliest created_at, in the staging model (call 02 14:20).

Proposed, not yet agreed (confirming owner has not confirmed directly):
- OQ-3 (cancellation taxonomy, build-blocker): proposed three top-level reasons (price, delivery, consumption) with the 14 CS reasons as sub-tags. Relayed by Steph as acceptable to Cathy Marsh; Cathy has not confirmed directly. Remains a build-blocker until Cathy signs off (call 01 10:18, call 02 14:22).

Still open:
- OQ-1 (guest checkouts), OQ-2 (state-machine precedence), OQ-4 (GA4-to-Stripe join key), OQ-5 (B2B treatment), OQ-8 (Klaviyo event taxonomy), OQ-9 (pause vs cancel).

Notable discoveries:
- Stripe is the system of record for money; Shopify for orders and customers (call 02 14:02).
- DQ-1: ~800 pre-2023 customer records need manual re-linking; some email mismatches are deliberate (staff accounts) (call 02 14:05).
- Maintenance burden is the engineering lead's main concern after three prior abandoned BI tools; enablement runs from week one (call 01 10:10).
- Goal hierarchy was inferred from the SOW (all five objectives Primary); confirm at requirements review.

## 2026-10-06 — Pipeline design (data-designer)

Source: approved requirements and conceptual model, engagement source DDL (17 tables), seed generator row counts. Recorded during pipeline_architecture.md generation and validation.

Decisions raised (need input):
- PD-1 (production ingestion tool): SOW §3 names Cloud Functions for production, but all five sources land through Fivetran into the raw_ schema today (call 02 14:10). The two conflict. Presented three scenarios (retain Fivetran / Cloud Functions / hybrid) with the trade-off between licence cost (Priya's concern) and maintenance burden (NFR-4, three prior abandoned tools). Not decided here. Recorded pipeline_tool: custom to match the stated SOW direction, pending PD-1. Owners: Priya Sharma, Becky Hartmann.
- PD-2 (Klaviyo and GA4 source path): read from the existing raw_ schema per NFR-3. Downstream of PD-1: if Fivetran is retired, the raw_ population path for these two sources must be replaced. Needs Priya to confirm raw_ stays populated. 
- PD-3 (GA4 late-arrival window, DQ-4): recommended a 3-day rolling lookback reprocess on each daily GA4 build, dedupe on event id. Consultant default; needs data-team confirmation at review.

Settled in the design:
- Demo ingestion is dbt seeds (Fivetran-equivalent), independent of the PD-1 outcome.
- Transformation is Wire 3-layer dbt: 16 staging models (one per in-scope raw table), integration models for the cross-source work, 20 warehouse facts/dims and aggregate marts.
- DQ-3 dedupe applied in stg_shipstation__shipments; DQ-4 late-arrival in the two GA4 staging models.
- Shipstation backfill: ~60k shipments from the 2024 cutoff, paced under 40 req/min, restartable (OQ-12, confirmed by Priya).
- Daily refresh for all domains in v1; GA4 lands hourly at source but is built daily; hourly churn deferred to v2 (NFR-1).
- Storage: BigQuery, EU dataset location recommended (no stated compliance regime); confirm at review.

Data gaps flagged (do not block design, must resolve before the affected models build):
- Address: no dedicated address source table; only shopify_customers.country_code and shopify_orders.market exist.
- No key links a Stripe charge to an invoice, which affects MRR refund netting.
- GA4-to-Stripe join key unresolved; user_id NULL for ~12% pre-2024 (OQ-4, DQ-2).
- No single Campaign key across Klaviyo and GA4 (GA4 campaign is free text).
- Cancellation taxonomy proposed, not confirmed by Cathy (OQ-3, build-blocker).
- Subscription state precedence unresolved (OQ-2).

Discoveries:
- Fivetran connectors were not verified against live tooling: no Fivetran MCP tools are available in this session. Connectors that would need confirming before build: Shopify, Stripe, Shipstation (connector existence and config fields), and the raw_ population path for Klaviyo and GA4. The 17 source tables and their columns were confirmed against ddl.sql at the schema level.

## 2026-10-06 — Data model (data-designer)

Source: approved requirements, conceptual model, pipeline architecture; engagement source DDL (17 tables); Wire data model registry (~/.wire/data-model-registry/). Recorded during data_model_specification.md generation and validation.

Registry outcome (user instruction: adapt the confident match, use other matches loosely, carry on without asking):
- Confident match: subscription-commerce vertical, subscription_lifecycle schema. Taken as "adapt". Recorded data_model_registry.vertical: subscription-commerce in engagement/context.md.
- Cross-vertical, used loosely (recorded in context.md cross_vertical_schemas): crm_identity_resolution (customer identity resolution + manual merge-list seed for DQ-1), ga4_ecommerce (web-session fact), multi_touch_attribution (attribution fact).
- Considered, not adopted: subscription-commerce/fulfillment_and_delivery (curated-box line/component grain Acme lacks), event_tracking_and_sessionization (GA4 pre-sessionized), finance_revenue_recognition (PSA/ASC-606, out of scope), product_analytics (software-product usage, n/a).

Design decisions (minted DM-1 to DM-5 in data_model_specification.md):
- DM-1: added int_subscriptions__retention__monthly, a registry-informed integration model not in the pipeline architecture. The churn, cohort-retention, MRR, and LTV marts all need the new/retained/reactivated/churn classification; computing it once avoids four copies. Integration count is 7 (6 from pipeline design + 1).
- DM-2: wh_customers__address_dim built at country/market grain, not postal grain, because no street-address source exists (G1, conceptual §5, OQ-7). Doubles as the conformed market dimension with the finance UK+IE rollup.
- DM-3: subscription grain is one row per reconciled Shopify/Stripe subscription. Dropped the registry's migration-safe retention key (no billing-platform migration at Acme); kept the multi-platform union pattern, reused for Shopify/Stripe reconciliation (OQ-2).
- DM-4: wh_subscriptions__mrr_fact is net of refunds on a rolling 30-day window at (month, market) grain, beyond the registry subscription_revenue entity's committed-only scope (FR-5, OQ-6).
- DM-5: fulfilment modelled as shipment_fact + tracking_event_fact (Shipstation has no line/component structure), not the registry's three-level delivery grain.
- Integration-model names given the three-segment int_<group>__<subject>__<description> form for validate-convention compliance; each is a one-token split of its pipeline-architecture name (mapping in Section 3).

Counts: 16 staging, 7 integration, 20 warehouse (6 dims, 8 facts, 6 aggregates), 4 configuration seeds; ERD 20 entities / 27 relationships; 9 cross-system joins (5 high-risk).

New gap surfaced (G7): no ad-spend/cost source in the five systems, so CAC cannot be computed from in-scope sources. attribution_fact produces customers acquired and first-month LTV by channel; a spend feed is needed or CAC drops from v1. Decision needed before the Marketing dashboard.

Open questions carried forward unchanged (still block the affected models, not the design): OQ-1 (guest orders), OQ-2 (state precedence), OQ-3 (cancellation taxonomy, build-blocker), OQ-4 (GA4-to-Stripe key), OQ-5 (B2B), OQ-9 (pause vs cancel); plus conceptual §5 gaps (address source, charge-to-invoice key, campaign reconciliation).
