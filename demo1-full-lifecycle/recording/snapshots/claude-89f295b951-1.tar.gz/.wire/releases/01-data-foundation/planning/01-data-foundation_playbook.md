**Playbook generated at template level. Re-run after requirements to incorporate open questions, dates, and team context.**

# Acme Coffee Roasters, 01-data-foundation: Wire Framework Playbook

- **Release type**: full_platform
- **Sprint window**: 27 January 2026 to 17 April 2026 (12 weeks, per SOW)
- **End deliverable**: unified BigQuery warehouse, dbt 3-layer models (staging, integration, warehouse), Looker semantic layer (1 model, about 20 views, 6 explores), 4 dashboards (Exec, Subscriptions, Marketing, Fulfilment), marketing training (2 sessions) and technical handover docs
- **Engagement lead**: Mark Rittman (Rittman Analytics)
- **Sponsor**: Becky Hartmann, Head of Data (Acme)
- **Phases**: Requirements, Design, Development, Testing, Deployment, Enablement (linear)

This playbook was generated before any artifact was produced. Dates, open questions and team names below come from the Statement of Work and engagement context, which are engagement-level documents, not release artifacts. Re-run `/wire:playbook-generate 01-data-foundation` after requirements is complete to refresh the diagram and steps with release-level detail.

---

## Sprint Control Flow

```mermaid
flowchart TD
    s(["Start: SOW signed, source access granted"])

    subgraph REQ["Requirements"]
        req_gen["/wire:requirements-generate"]
        req_vr["/wire:requirements-validate<br/>/wire:requirements-review"]
        req_dec{"requirements approved?"}
        ws_gen["/wire:workshops-generate"]
        ws_rev["/wire:workshops-review"]
        ws_dec{"workshops approved?"}
    end

    subgraph DES["Design"]
        cm_gen["/wire:conceptual_model-generate"]
        cm_vr["/wire:conceptual_model-validate<br/>/wire:conceptual_model-review"]
        cm_dec{"conceptual model approved?"}
        pd_gen["/wire:pipeline_design-generate"]
        pd_vr["/wire:pipeline_design-validate<br/>/wire:pipeline_design-review"]
        pd_dec{"pipeline design approved?"}
        lm_gen["/wire:logical_model-generate [optional]"]
        lm_vr["/wire:logical_model-validate<br/>/wire:logical_model-review"]
        lm_dec{"logical model approved?"}
        dm_gen["/wire:data_model-generate"]
        dm_vr["/wire:data_model-validate<br/>/wire:data_model-review"]
        dm_dec{"data model approved?"}
        mu_gen["/wire:mockups-generate"]
        mu_rev["/wire:mockups-review"]
        mu_dec{"mockups approved?"}
    end

    oq7{"OQ-7 v1 market scope resolved?"}
    chase_oq7["Chase Becky: confirm v1 vs phased markets"]

    subgraph DEV["Development"]
        pl_gen["/wire:pipeline-generate"]
        pl_vr["/wire:pipeline-validate<br/>/wire:pipeline-review"]
        pl_dec{"pipeline approved?"}
        orc_gen["/wire:orchestration-generate"]
        orc_vr["/wire:orchestration-validate<br/>/wire:orchestration-review"]
        orc_dec{"orchestration approved?"}
        oq3{"OQ-3 cancel-reason taxonomy agreed?"}
        chase_oq3["Chase Steph and Cathy: canonical cancel reasons"]
        dbt_gen["/wire:dbt-generate"]
        dbt_vr["/wire:dbt-validate<br/>/wire:dbt-review"]
        dbt_dec{"dbt models approved?"}
        sl_gen["/wire:semantic_layer-generate"]
        sl_vr["/wire:semantic_layer-validate<br/>/wire:semantic_layer-review"]
        sl_dec{"semantic layer approved?"}
        dsh_gen["/wire:dashboards-generate"]
        dsh_vr["/wire:dashboards-validate<br/>/wire:dashboards-review"]
        dsh_dec{"dashboards approved?"}
    end

    subgraph TEST["Testing"]
        dq_gen["/wire:data_quality-generate"]
        dq_vr["/wire:data_quality-validate<br/>/wire:data_quality-review"]
        dq_dec{"data quality approved?"}
        uat_gen["/wire:uat-generate"]
        uat_rev["/wire:uat-review"]
        uat_dec{"UAT approved?"}
    end

    subgraph DEP["Deployment"]
        dep_gen["/wire:deployment-generate"]
        dep_vr["/wire:deployment-validate<br/>/wire:deployment-review"]
        dep_dec{"deployment approved?"}
    end

    subgraph ENA["Enablement"]
        tr_gen["/wire:training-generate"]
        tr_vr["/wire:training-validate<br/>/wire:training-review"]
        tr_dec{"training approved?"}
        doc_gen["/wire:documentation-generate"]
        doc_vr["/wire:documentation-validate<br/>/wire:documentation-review"]
        doc_dec{"documentation approved?"}
    end

    e(["End: platform live, team enabled, docs handed over"])

    s --> req_gen
    req_gen --> req_vr --> req_dec
    req_dec -->|changes requested| req_gen
    req_dec -->|approved| ws_gen
    ws_gen --> ws_rev --> ws_dec
    ws_dec -->|changes requested| ws_gen
    ws_dec -->|approved| cm_gen

    cm_gen --> cm_vr --> cm_dec
    cm_dec -->|changes requested| cm_gen
    cm_dec -->|approved| pd_gen
    pd_gen --> pd_vr --> pd_dec
    pd_dec -->|changes requested| pd_gen
    pd_dec -->|approved| lm_gen
    lm_gen --> lm_vr --> lm_dec
    lm_dec -->|changes requested| lm_gen
    lm_dec -->|approved| dm_gen
    dm_gen --> dm_vr --> dm_dec
    dm_dec -->|changes requested| dm_gen
    dm_dec -->|approved| mu_gen
    mu_gen --> mu_rev --> mu_dec
    mu_dec -->|changes requested| mu_gen
    mu_dec -->|approved| oq7

    oq7 -->|not yet| chase_oq7
    chase_oq7 --> oq7
    oq7 -->|resolved| pl_gen

    pl_gen --> pl_vr --> pl_dec
    pl_dec -->|changes requested| pl_gen
    pl_dec -->|approved| orc_gen
    orc_gen --> orc_vr --> orc_dec
    orc_dec -->|changes requested| orc_gen
    orc_dec -->|approved| oq3
    oq3 -->|not yet| chase_oq3
    chase_oq3 --> oq3
    oq3 -->|resolved| dbt_gen
    dbt_gen --> dbt_vr --> dbt_dec
    dbt_dec -->|changes requested| dbt_gen
    dbt_dec -->|approved| sl_gen
    sl_gen --> sl_vr --> sl_dec
    sl_dec -->|changes requested| sl_gen
    sl_dec -->|approved| dsh_gen
    dsh_gen --> dsh_vr --> dsh_dec
    dsh_dec -->|changes requested| dsh_gen
    dsh_dec -->|approved| dq_gen

    dq_gen --> dq_vr --> dq_dec
    dq_dec -->|changes requested| dq_gen
    dq_dec -->|approved| uat_gen
    uat_gen --> uat_rev --> uat_dec
    uat_dec -->|changes requested| uat_gen
    uat_dec -->|approved| dep_gen

    dep_gen --> dep_vr --> dep_dec
    dep_dec -->|changes requested| dep_gen
    dep_dec -->|approved| tr_gen

    tr_gen --> tr_vr --> tr_dec
    tr_dec -->|changes requested| tr_gen
    tr_dec -->|approved| doc_gen
    doc_gen --> doc_vr --> doc_dec
    doc_dec -->|changes requested| doc_gen
    doc_dec -->|approved| e

    classDef wireCmd fill:#1a3a5c,stroke:#4a90d9,color:#fff
    classDef offline fill:#2d4a1e,stroke:#6abf4b,color:#fff
    classDef decision fill:#5c3a00,stroke:#d98c1a,color:#fff
    classDef gate fill:#4a1a5c,stroke:#a04ad9,color:#fff
    classDef event fill:#1a1a1a,stroke:#888,color:#fff

    class s,e event
    class req_gen,req_vr,ws_gen,ws_rev,cm_gen,cm_vr,pd_gen,pd_vr,lm_gen,lm_vr,dm_gen,dm_vr,mu_gen,mu_rev,pl_gen,pl_vr,orc_gen,orc_vr,dbt_gen,dbt_vr,sl_gen,sl_vr,dsh_gen,dsh_vr,dq_gen,dq_vr,uat_gen,uat_rev,dep_gen,dep_vr,tr_gen,tr_vr,doc_gen,doc_vr wireCmd
    class req_dec,ws_dec,cm_dec,pd_dec,lm_dec,dm_dec,mu_dec,oq7,oq3,pl_dec,orc_dec,dbt_dec,sl_dec,dsh_dec,dq_dec,uat_dec,dep_dec,tr_dec,doc_dec decision
    class chase_oq7,chase_oq3 offline
```

Two build-blocker open questions sit on the critical path. OQ-7 (which markets are in v1) must close before Development starts. OQ-3 (one canonical cancel-reason list) must close before the subscription churn models are built. Each has a chase loop in the diagram: the work does not advance until the owner resolves the question.

---

## How the Framework Works for This Full Platform Release

| Phase | Artifact | Wire commands | Produces |
|---|---|---|---|
| Requirements | requirements | generate, validate, review | Requirements specification from the SOW and source notes |
| Requirements | workshops | generate, review | Workshop agendas and recorded decisions |
| Design | conceptual_model | generate, validate, review | Business entity model (customers, orders, subscriptions, payments, marketing, fulfilment) |
| Design | pipeline_design | generate, validate, review | Ingestion architecture and data-flow diagram for the 5 sources |
| Design | logical_model (optional) | generate, validate, review | Keys, cardinality and identity-resolution rules where contested |
| Design | data_model | generate, validate, review | Physical dbt model plan across staging, integration, warehouse |
| Design | mockups | generate, review | Dashboard mockups for the 4 target dashboards |
| Development | pipeline | generate, validate, review | Ingestion code (dbt seeds for demo, Cloud Functions for production) |
| Development | orchestration | generate, validate, review | Schedules for the daily refresh |
| Development | dbt | generate, validate, review | Staging, integration and warehouse models including MRR and churn marts |
| Development | semantic_layer | generate, validate, review | LookML: 1 model, about 20 views, 6 explores |
| Development | dashboards | generate, validate, review | Exec, Subscriptions, Marketing, Fulfilment dashboards |
| Testing | data_quality | generate, validate, review | Tests covering the 4 known data-quality concerns |
| Testing | uat | generate, review | UAT script and recorded sponsor sign-off |
| Deployment | deployment | generate, validate, review | Deployment runbook, checklist and rollback steps |
| Enablement | training | generate, validate, review | Marketing training materials (2 sessions) |
| Enablement | documentation | generate, validate, review | Technical handover documentation |

Out of scope for this release and left out of the sequence: business rules (not applicable), seed data, viz catalog and data refactor (dashboard-first only), dbtcharts and agents schema (the SOW does not call for them).

---

## Step-by-step Playbook

### Step 1 - Requirements → requirements

- **Offline prerequisites**: place the signed SOW and source-system access notes (Shopify, Stripe, Klaviyo, Shipstation, GA4) in `.wire/releases/01-data-foundation/requirements/`. Mark Rittman owns staging these.
- **Wire commands**:
  - `/wire:requirements-generate 01-data-foundation`
  - `/wire:requirements-validate 01-data-foundation`
  - `/wire:requirements-review 01-data-foundation`
- **OQ/DQ checkpoint**: capture scope decisions on OQ-1 (guest checkouts in revenue scope, owner Becky/Mark), OQ-5 (wholesale B2B in subscription marts, owner Finance/Mark) and OQ-11 (historical backfill depth, owner Mark/Becky). Escalate any still open to Becky at the weekly status call.
- **Done when**: the requirements spec passes validation and Becky Hartmann approves it at review.

### Step 2 - Workshops → workshops

- **Offline prerequisites**: draft requirements available; workshop agenda and invite list in `requirements/` or `workshops/`. Facilitated by RA with Acme stakeholders.
- **Wire commands**:
  - `/wire:workshops-generate 01-data-foundation`
  - `/wire:workshops-review 01-data-foundation`
- **OQ/DQ checkpoint**: use workshops to work OQ-2 (which subscription state machine wins, Shopify or Stripe, owner Steph/ops), OQ-8 (keep or consolidate Klaviyo event types, owner Marketing) and OQ-9 (pause vs cancel as churn, owner Steph/ops). Record decisions in the workshop notes.
- **Done when**: workshop notes are recorded, reviewed, and fed back into the requirements.

### Step 3 - Conceptual model → conceptual_model

- **Offline prerequisites**: approved requirements. No extra files needed.
- **Wire commands**:
  - `/wire:conceptual_model-generate 01-data-foundation`
  - `/wire:conceptual_model-validate 01-data-foundation`
  - `/wire:conceptual_model-review 01-data-foundation`
- **OQ/DQ checkpoint**: resolve how OQ-1 (guest customers) and OQ-5 (wholesale) appear as entities, and reflect the OQ-2 subscription-source decision in the subscription entity. Owners as above.
- **Done when**: the entity model validates and stakeholders approve the entities and relationships.

### Step 4 - Pipeline design → pipeline_design

- **Offline prerequisites**: approved conceptual model; source API and volume notes for the 5 systems.
- **Wire commands**:
  - `/wire:pipeline_design-generate 01-data-foundation`
  - `/wire:pipeline_design-validate 01-data-foundation`
  - `/wire:pipeline_design-review 01-data-foundation`
- **OQ/DQ checkpoint**: settle OQ-11 (backfill depth: Shopify to 2018, GA4 only to 2023, owner Mark/Becky), OQ-12 (Shipstation API rate limit on backfill, owner Engineering), OQ-8 (Klaviyo event taxonomy, owner Marketing) and DQ-4 (GA4 out-of-order timestamps need late-arrival handling).
- **Done when**: the data-flow design validates and is approved, with the backfill approach agreed.

### Step 5 - Logical model → logical_model (optional)

Run this step. Identity resolution and subscription cardinality are contested on this engagement, so these decisions are worth a reviewed artifact before they arrive as dbt code.

- **Offline prerequisites**: approved conceptual model; the OQ-2, OQ-4 and DQ-1 context from earlier steps.
- **Wire commands**:
  - `/wire:logical_model-generate 01-data-foundation`
  - `/wire:logical_model-validate 01-data-foundation`
  - `/wire:logical_model-review 01-data-foundation`
- **OQ/DQ checkpoint**: resolve OQ-2 (subscription state-machine precedence, ~3% disagree, owner Steph/ops), OQ-4 (canonical GA4 to Stripe join key, owner Marketing/data), OQ-9 (pause vs cancel, owner Steph/ops) and DQ-1 (Stripe/Shopify email mismatch on ~4% of joins). Agree the match keys here.
- **Done when**: keys, cardinality and identity rules validate and are approved. If the team chooses to skip this optional step, carry these decisions into the data model step instead.

### Step 6 - Data model → data_model

- **Offline prerequisites**: approved conceptual model (and logical model if run).
- **Wire commands**:
  - `/wire:data_model-generate 01-data-foundation`
  - `/wire:data_model-validate 01-data-foundation`
  - `/wire:data_model-review 01-data-foundation`
- **OQ/DQ checkpoint**: resolve OQ-5 (wholesale treatment in subscription marts, owner Finance/Mark) and OQ-6 (refunds net or gross in MRR, owner Finance). Flag OQ-3 now: the churn mart cannot be finalised until the cancel-reason taxonomy is agreed (see Step 10).
- **Done when**: the physical model plan passes convention checks and is approved.

### Step 7 - Mockups → mockups

- **Offline prerequisites**: approved data model; the 4 target dashboards named in the SOW (Exec, Subscriptions, Marketing, Fulfilment).
- **Wire commands**:
  - `/wire:mockups-generate 01-data-foundation`
  - `/wire:mockups-review 01-data-foundation`
- **OQ/DQ checkpoint**: start OQ-10 (Looker edit vs view licences, owner IT/Becky) so access is settled before training.
- **Done when**: mockups for all 4 dashboards are reviewed and signed off by the CEO and head of finance as the primary audience.

### Phase gate - OQ-7 before Development

Do not start Development until OQ-7 is resolved. The v1 vs phased market scope (UK, Ireland, France, Germany) sets how much gets built, and pricing differs across markets. Owner: Becky. If it is still open, chase Becky and hold the build. This gate is shown as a decision diamond in the diagram.

### Step 8 - Pipeline → pipeline

- **Offline prerequisites**: approved pipeline design; source credentials provisioned; OQ-7 resolved.
- **Wire commands**:
  - `/wire:pipeline-generate 01-data-foundation`
  - `/wire:pipeline-validate 01-data-foundation`
  - `/wire:pipeline-review 01-data-foundation`
- **OQ/DQ checkpoint**: apply the OQ-11 backfill decision and the OQ-12 Shipstation rate-limit approach. Handle DQ-2 (Klaviyo events missing user_id for ~12% of pre-2024 events) and DQ-4 (GA4 late arrivals) in ingestion.
- **Done when**: ingestion loads all 5 sources, validates, and is approved.

### Step 9 - Orchestration → orchestration

- **Offline prerequisites**: working pipeline code.
- **Wire commands**:
  - `/wire:orchestration-generate 01-data-foundation`
  - `/wire:orchestration-validate 01-data-foundation`
  - `/wire:orchestration-review 01-data-foundation`
- **OQ/DQ checkpoint**: confirm the daily-refresh requirement for the executive dashboard drives the schedule.
- **Done when**: schedules validate and a daily refresh is confirmed.

### Phase gate - OQ-3 before dbt churn marts

Do not build the subscription churn mart until OQ-3 is resolved. Shopify has 8 cancel reasons, Stripe has 4, the CS team uses 14. One canonical list is needed. Owners: Steph and Cathy. If it is still open, chase them and hold the churn mart. This gate is shown as a decision diamond in the diagram.

### Step 10 - dbt models → dbt

- **Offline prerequisites**: loaded source data; OQ-3 resolved before the churn mart.
- **Wire commands**:
  - `/wire:dbt-generate 01-data-foundation`
  - `/wire:dbt-validate 01-data-foundation`
  - `/wire:dbt-review 01-data-foundation`
- **OQ/DQ checkpoint**: apply OQ-6 (refund treatment in MRR) and OQ-3 (cancel-reason taxonomy) in the marts. Add the DQ-3 dedup rule for Shipstation duplicate shipments (same tracking number, different created_at) and the DQ-1 email-mismatch join logic.
- **Done when**: `dbt build` runs green with zero failures and the models are approved.

### Step 11 - Semantic layer → semantic_layer

- **Offline prerequisites**: approved warehouse models.
- **Wire commands**:
  - `/wire:semantic_layer-generate 01-data-foundation`
  - `/wire:semantic_layer-validate 01-data-foundation`
  - `/wire:semantic_layer-review 01-data-foundation`
- **OQ/DQ checkpoint**: confirm OQ-10 (Looker licences) so the right people can query and edit.
- **Done when**: the LookML (1 model, about 20 views, 6 explores) compiles and is approved.

### Step 12 - Dashboards → dashboards

- **Offline prerequisites**: working semantic layer.
- **Wire commands**:
  - `/wire:dashboards-generate 01-data-foundation`
  - `/wire:dashboards-validate 01-data-foundation`
  - `/wire:dashboards-review 01-data-foundation`
- **OQ/DQ checkpoint**: none new. Check each of the 4 dashboards renders with non-empty data.
- **Done when**: all 4 dashboards (Exec, Subscriptions, Marketing, Fulfilment) render and are approved.

### Step 13 - Data quality → data_quality

- **Offline prerequisites**: built models and dashboards.
- **Wire commands**:
  - `/wire:data_quality-generate 01-data-foundation`
  - `/wire:data_quality-validate 01-data-foundation`
  - `/wire:data_quality-review 01-data-foundation`
- **OQ/DQ checkpoint**: cover all four concerns: DQ-1 (email mismatch), DQ-2 (missing Klaviyo user_id), DQ-3 (Shipstation duplicates), DQ-4 (GA4 late arrivals). Each needs a test or a documented handling rule.
- **Done when**: the test suite validates and is approved, with the four concerns covered.

### Step 14 - UAT → uat

- **Offline prerequisites**: dashboards and data-quality tests in place; UAT participants lined up.
- **Wire commands**:
  - `/wire:uat-generate 01-data-foundation`
  - `/wire:uat-review 01-data-foundation`
- **OQ/DQ checkpoint**: test against the acceptance criteria, including the five named questions the marketing team must answer from the Looker explores without engineering help.
- **Done when**: UAT passes and the sponsor signs off. Sign-off is a human gate, not a Wire output.

### Step 15 - Deployment → deployment

- **Offline prerequisites**: passed UAT; production BigQuery project and credentials ready.
- **Wire commands**:
  - `/wire:deployment-generate 01-data-foundation`
  - `/wire:deployment-validate 01-data-foundation`
  - `/wire:deployment-review 01-data-foundation`
- **OQ/DQ checkpoint**: confirm production access and the daily-refresh schedule are in place.
- **Done when**: the runbook covers pre-deployment checks, step-by-step execution, post-deployment validation and rollback; a standalone `deployment-checklist.md` exists; and the deployment is approved.

### Step 16 - Training → training

- **Offline prerequisites**: live dashboards and semantic layer; marketing team scheduled for 2 sessions.
- **Wire commands**:
  - `/wire:training-generate 01-data-foundation`
  - `/wire:training-validate 01-data-foundation`
  - `/wire:training-review 01-data-foundation`
- **OQ/DQ checkpoint**: confirm OQ-10 (who has edit vs view) so training matches real access.
- **Done when**: training materials for the 2 marketing sessions have a stated audience, learning objectives and worked examples, and are approved.

### Step 17 - Documentation → documentation

- **Offline prerequisites**: deployed platform and training materials.
- **Wire commands**:
  - `/wire:documentation-generate 01-data-foundation`
  - `/wire:documentation-validate 01-data-foundation`
  - `/wire:documentation-review 01-data-foundation`
- **OQ/DQ checkpoint**: none new. Confirm the docs let an engineer unfamiliar with the build own it.
- **Done when**: technical handover docs validate and are approved, closing the engagement.

---

## Daily Rhythm

Start each working session with `/wire:session-plan 01-data-foundation` to set a focused 3 to 5 step plan for the session. Scope each session to one artifact where possible: generate, then validate, then take the review to the named human owner.

Workshops and interviews are time-boxed and run by people, not by Wire. Book them ahead. Carry each open question to its owner at the weekly status call, and record the decision in the relevant artifact before the build step that depends on it. Keep the two build-blockers (OQ-3, OQ-7) on the standing agenda until they close.

---

## What Wire Does and Does Not Do

Wire writes the artifacts. For this release that means the requirements spec, the conceptual and physical data models, the pipeline design and pipeline code, the dbt staging, integration and warehouse models (including the MRR and churn marts), the LookML views and explores, the 4 dashboards, the data-quality tests, the deployment runbook and checklist, the marketing training materials and the handover documentation. Wire also runs the mechanical validations: naming conventions, structural checks, test coverage, referential integrity and `dbt build`.

Wire does not take decisions for the team or the sponsor. Workshops and interviews are run by people. Open questions such as the market scope (OQ-7), the cancel-reason taxonomy (OQ-3), refund treatment (OQ-6) and the subscription source of truth (OQ-2) are resolved in conversation, not by a Wire command. Sponsor sign-off, UAT approval and client communication stay human-owned. Every `-generate` is followed by a `-validate` and a `-review`, and the review is the human gate.

---

## Wire Command Reference

| Command | What it does |
|---|---|
| `/wire:requirements-generate` | Build the requirements spec from the SOW and source notes |
| `/wire:requirements-validate` | Check the requirements spec for completeness |
| `/wire:requirements-review` | Record stakeholder review of the requirements |
| `/wire:workshops-generate` | Produce workshop agendas and structure |
| `/wire:workshops-review` | Record workshop outcomes and decisions |
| `/wire:conceptual_model-generate` | Build the business entity model from requirements |
| `/wire:conceptual_model-validate` | Check the entity model for completeness and correctness |
| `/wire:conceptual_model-review` | Review the entity model with stakeholders |
| `/wire:pipeline_design-generate` | Design the ingestion architecture and data flow |
| `/wire:pipeline_design-validate` | Validate the pipeline design |
| `/wire:pipeline_design-review` | Review the pipeline design |
| `/wire:logical_model-generate` | Define keys, cardinality and identity-resolution rules (optional) |
| `/wire:logical_model-validate` | Validate the logical model |
| `/wire:logical_model-review` | Review the logical model |
| `/wire:data_model-generate` | Plan the physical dbt model structure |
| `/wire:data_model-validate` | Validate data model conventions |
| `/wire:data_model-review` | Review the data model with the team |
| `/wire:mockups-generate` | Produce dashboard mockups |
| `/wire:mockups-review` | Review mockups with stakeholders |
| `/wire:pipeline-generate` | Generate the ingestion pipeline code |
| `/wire:pipeline-validate` | Validate the pipeline code |
| `/wire:pipeline-review` | Review the pipeline code |
| `/wire:orchestration-generate` | Generate schedules and the orchestration DAG |
| `/wire:orchestration-validate` | Validate the orchestration configuration |
| `/wire:orchestration-review` | Review the orchestration setup |
| `/wire:dbt-generate` | Generate the dbt staging, integration and warehouse models |
| `/wire:dbt-validate` | Run dbt tests and validation |
| `/wire:dbt-review` | Review the dbt code |
| `/wire:semantic_layer-generate` | Generate the LookML model, views and explores |
| `/wire:semantic_layer-validate` | Validate the semantic layer |
| `/wire:semantic_layer-review` | Review the semantic layer |
| `/wire:dashboards-generate` | Generate the dashboards |
| `/wire:dashboards-validate` | Validate the dashboards |
| `/wire:dashboards-review` | Review the dashboards |
| `/wire:data_quality-generate` | Generate data-quality tests |
| `/wire:data_quality-validate` | Validate the test suite |
| `/wire:data_quality-review` | Review the data-quality coverage |
| `/wire:uat-generate` | Produce the UAT script |
| `/wire:uat-review` | Record UAT results and sponsor sign-off |
| `/wire:deployment-generate` | Produce the deployment runbook, checklist and rollback |
| `/wire:deployment-validate` | Validate the deployment guide |
| `/wire:deployment-review` | Review the deployment plan |
| `/wire:training-generate` | Produce marketing training materials |
| `/wire:training-validate` | Validate the training materials |
| `/wire:training-review` | Review the training materials |
| `/wire:documentation-generate` | Produce technical handover documentation |
| `/wire:documentation-validate` | Validate the documentation |
| `/wire:documentation-review` | Review the documentation |
| `/wire:session-plan` | Set a focused plan for a working session |
