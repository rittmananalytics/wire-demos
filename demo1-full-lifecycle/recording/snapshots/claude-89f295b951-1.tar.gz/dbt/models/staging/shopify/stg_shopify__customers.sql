{{
    config(
        materialized='view',
        tags=['staging', 'shopify']
    )
}}

with

-- Source data lives as a dbt seed in this demo, so ref() replaces source()
s_shopify_customers as (
    select * from {{ ref('shopify_customers') }}
),

final as (
    select
        -- Keys
        {{ dbt_utils.generate_surrogate_key(['id']) }} as customer_pk,
        cast(id as bigint) as shopify_customer_natural_key,

        -- Attributes
        upper(trim(cast(country_code as varchar))) as customer_country_code,
        lower(trim(cast(email as varchar))) as customer_email,
        trim(cast(first_name as varchar)) as customer_first_name,
        trim(cast(last_name as varchar)) as customer_last_name,

        -- Booleans
        coalesce(cast(accepts_marketing as boolean), false)
            as has_marketing_consent,

        -- Temporal data types
        cast(created_at as timestamp) as customer_created_ts,
        cast(updated_at as timestamp) as customer_updated_ts

    from s_shopify_customers
)

select * from final
