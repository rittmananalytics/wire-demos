{{
    config(
        materialized='view',
        tags=['staging', 'shopify']
    )
}}

with

-- Source data lives as a dbt seed in this demo, so ref() replaces source()
s_shopify_orders as (
    select * from {{ ref('shopify_orders') }}
),

final as (
    select
        -- Keys
        {{ dbt_utils.generate_surrogate_key(['id']) }} as order_pk,
        -- Guest orders have no customer, so the foreign key is left null
        -- rather than hashing a null id into a key that matches nothing
        case
            when customer_id is not null
            then {{ dbt_utils.generate_surrogate_key(['customer_id']) }}
        end as customer_fk,
        cast(id as bigint) as shopify_order_natural_key,
        cast(customer_id as bigint) as shopify_customer_natural_key,

        -- Attributes
        upper(trim(cast(currency as varchar))) as order_currency_code,
        lower(trim(cast(email as varchar))) as order_email,
        lower(trim(cast(financial_status as varchar)))
            as order_financial_status,
        lower(trim(cast(market as varchar))) as order_market,
        trim(cast(order_number as varchar)) as order_number,

        -- Metrics
        cast(total_price as double) as order_total_amount,

        -- Booleans
        customer_id is null as is_guest_order,

        -- Temporal data types
        cast(created_at as timestamp) as order_placed_ts,
        cast(updated_at as timestamp) as order_updated_ts

    from s_shopify_orders
)

select * from final
