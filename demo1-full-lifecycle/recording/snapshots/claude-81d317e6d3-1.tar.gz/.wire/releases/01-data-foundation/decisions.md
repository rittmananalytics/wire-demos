# Decisions and Discoveries — 01-data-foundation

Append-only log of decisions reached and notable discoveries during this release.

## 2026-10-06 — Requirements synthesis (discovery-analyst)

Source: SOW and call transcripts 01-03. Recorded during requirements_specification.md generation.

Agreed in calls (owning stakeholder confirmed directly in the transcript):
- OQ-6 (refund treatment): MRR is net, refunds netted on a rolling 30-day window. Confirmed by Tom Vickers (call 03 10:08).
- OQ-7 (market scope, build-blocker): four markets in v1 (UK, IE, FR, DE) modelled on country code; finance gets a UK+IE rollup. Confirmed by Becky Hartmann (call 03 10:21).
- OQ-10 (Looker licences): edit for Becky, Steph, Jordan, Tom; ~12 view licences (rest of marketing/ops plus David); others use scheduled exports. Confirmed by Becky (call 03 10:23).
- OQ-11 (backfill depth): 2024-01-01 cutoff. Confirmed by Steph and Mark (call 02 14:16); Becky to ratify as co-owner.
- OQ-12 (Shipstation rate limit): workable with the 2024 cutoff (~60k shipments, chunked, ~2 hours). Confirmed by Priya (call 02 14:18).
- Refresh cadence: daily across all domains for v1; hourly churn refresh deferred to v2. Cathy accepts daily for v1 (relayed by Steph, call 02 14:12).
- DQ-3 dedupe rule: dedupe Shipstation shipments on tracking_number, keep earliest created_at, in the staging model (call 02 14:20).

Proposed, not yet agreed (confirming owner has not confirmed directly):
- OQ-3 (cancellation taxonomy, build-blocker): proposed three top-level reasons (price, delivery, consumption) with the 14 CS reasons as sub-tags. Relayed by Steph as acceptable to Cathy Marsh; Cathy has not confirmed directly. Remains a build-blocker until Cathy signs off (call 01 10:18, call 02 14:22).

Still open:
- OQ-1 (guest checkouts), OQ-2 (state-machine precedence), OQ-4 (GA4-to-Stripe join key), OQ-5 (B2B treatment), OQ-8 (Klaviyo event taxonomy), OQ-9 (pause vs cancel).

Notable discoveries:
- Stripe is the system of record for money; Shopify for orders and customers (call 02 14:02).
- DQ-1: ~800 pre-2023 customer records need manual re-linking; some email mismatches are deliberate (staff accounts) (call 02 14:05).
- Maintenance burden is the engineering lead's main concern after three prior abandoned BI tools; enablement runs from week one (call 01 10:10).
- Goal hierarchy was inferred from the SOW (all five objectives Primary); confirm at requirements review.
