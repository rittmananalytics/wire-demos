---
engagement_name: "acme_coffee_data_platform"
client_name: "Acme Coffee Roasters"
created_date: "2026-05-31"
engagement_lead: "Mark Rittman (demo)"
repo_mode: "combined"  # combined | dedicated_delivery

# If repo_mode is dedicated_delivery, provide client repo details:
client_repo:
  github_url: null
  local_path: null
  default_branch: "main"

docstore:
  provider: null  # confluence | notion | both | null
  confluence:
    space_key: null
    parent_page_url: null
  notion:
    parent_page_url: null

data_model_registry:
  vertical: null  # any directory name under the registry's verticals/ (13 at the time
                  # of writing). Run `ls ~/.wire/data-model-registry/verticals/` for
                  # the current set, or leave null.
                  # May be a confident match, or the closest adjacent match when no vertical is an
                  # exact industry fit (e.g. subscription-commerce for a SaaS client's MRR/NRR model).
                  # Advisory only — see wire/schemas/data-model-registry.md. null (the default)
                  # means data_model-generate/validate behave exactly as if this didn't exist.
  cross_vertical_schemas: []  # e.g. [crm_identity_resolution, finance_revenue_recognition] — accepted independently
                  # of any vertical match; a client can need these whether or not `vertical` above is set.

# How Wire is driven on this engagement (specs/utils/director_operating_model.md).
#   orchestrated — the release-director skill turns your direction into Wire
#                  command runs, dispatches lanes, and stops at decisions. The
#                  default on Claude Code. Typed commands keep working.
#   manual       — today's behaviour: /wire:start prints the next action and
#                  stops, you type the commands. Use it for client-side teams
#                  and regulated engagements.
# Per-session override: say "you drive" to hand control back for that session.
# Gemini CLI resolves to manual regardless: it has no skills or agents.
orchestration:
  mode: orchestrated  # orchestrated | manual

fathom_sync:
  enabled: false  # true | false — resolved at /wire:new Step 2 from the client domain given;
                  # false if no domain was given, or if the domain/client_name looked like an internal RA
                  # engagement (Fathom Sync refuses to enable itself in that case — see fathom_sync.md).
  client_domain: null  # required for enabled: true — matches calendar invitees on each
                  # call, so only meetings this specific client attended get pulled in. Never rittmananalytics.com.
  last_synced: null    # ISO date; updated automatically after each sync, drives the incremental --after window
---

# Engagement Context: acme_coffee_data_platform

**Client**: Acme Coffee Roasters
**Engagement Lead**: Mark Rittman (demo)
**Created**: 2026-05-31
**Repo mode**: combined

---

## Engagement Overview

Acme Coffee Roasters is a direct-to-consumer subscription coffee business based in Hove, with £8M annual recurring revenue across three product lines and four markets (UK, Ireland, France, Germany). Data sits in five systems (Shopify, Stripe, Klaviyo, Shipstation, GA4) with no central reporting.

This engagement builds a unified BigQuery warehouse, dbt models, a Looker semantic layer and four dashboards, so the board can trust subscription retention and revenue figures.

## Business Objectives

1. Unified analytics warehouse covering Shopify, Stripe, Klaviyo, Shipstation and GA4.
2. Subscription metrics the board can trust: MRR, gross and net churn, cohort retention, LTV.
3. Marketing attribution joining Klaviyo and GA4 events to Stripe revenue.
4. Daily-refreshed executive dashboard for the CEO and head of finance.
5. Looker semantic layer for marketing self-service.

## Key Stakeholders

| Name | Role | Responsibilities | Contact |
|------|------|------------------|---------|
| [name] | [role] | [what they are accountable for] | [email or Slack] |
| [name] | [role] | [what they are accountable for] | [email or Slack] |

## Current State Architecture

[Brief description of the client's current data infrastructure — what they have today. Include key systems, data volumes, and any known constraints.]

**Key systems**:
- [System 1]: [brief description]
- [System 2]: [brief description]

## Engagement Releases

| # | Release Name | Type | Status | Start | End |
|---|-------------|------|--------|-------|-----|
| 01 | 01-data-foundation | full_platform | In progress | 2026-05-31 | |

## SOW Reference

Statement of Work: `engagement/sow.md` (if available)

[Note any key contract terms, budget ceiling, payment milestones, or compliance requirements.]

## Working Agreements

[Any working patterns, meeting cadence, communication preferences, or team norms agreed with the client.]

- **Meeting cadence**: [e.g. Weekly status call, Tuesday 10am]
- **Primary contact**: [who to reach for decisions]
- **Code review**: [process for reviewing and approving deliverables]
- **Access provisioning**: [how the team gets access to client systems]

## Client Repo Details

This engagement uses the combined client + delivery repo. The `.wire/` folder lives directly in the client's code repo.

## Notes

[Any other context relevant to the engagement that doesn't fit the sections above.]
